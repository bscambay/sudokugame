'use strict';

/**
 * Cache in which values expire over time (defaults to 24 hours)
 */
class TimedCache
{
    /**
     * Constructor
     * @param expirationHours Number of hours after which cache
     * entries are stale
     */
    constructor(expirationHours)
    {
        if (!expirationHours)
        {
            this.expirationHours = 24;
        }
        else
        {
            this.expirationHours = expirationHours;
        }
        this.cache = {};
    }

    /**
     * Adds a value to the cache
     * @param key
     * @param value
     * @throws Error if no key provided
     */
    put(key, value)
    {
        if (key !== null && key !== undefined)
        {
            var expires = new Date();
            expires = new Date(expires.getTime() + (this.expirationHours * 3600000));

            var entry = this.cache[key];

            if (entry)
            {
                entry.expires = expires;
                entry.value = value;
            }
            else
            {
                this.cache[key] = {
                    expires: expires,
                    value: value
                };
            }
        }
        else
        {
            throw new Error("Cannot add value to cache without a key");
        }
    }

    /**
     * Retrieves the value from the cache
     * @param key
     * @returns value or undefined if the value is not found or has expired
     */
    value(key)
    {
        if (key !== null && key !== undefined)
        {
            var entry = this.cache[key];

            if (entry)
            {
                if ((new Date()).getTime() - entry.expires.getTime() < 0)
                {
                    return entry.value;
                }
                else
                {
                    delete this.cache[key];
                }
            }
        }

        return undefined;
    }
}

module.exports = TimedCache;