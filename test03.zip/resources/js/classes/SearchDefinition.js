/**
 * SearchDefinition class
 */

function SearchDefinition() {
    this.title = title;
    this.terms = [];
    this.documents = [];
    this.synonyms = [];
    this.dates = [];
    this.logicals = [];
    this.annTypes = [];
    this.blueBookLocations = blueBookLocations;
    this.bodySystem = bodySystem;
}