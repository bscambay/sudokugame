/**
 * Allegation class
 */
function Allegation(text) {
    this.text = text;
    this.terms = [];
    this.matchingRules = [];
}

Allegation.prototype.getConcepts = function(){
    return Allegation.getConceptsForAllegation(this);
};

/**
 * Parse allegations from a case
 * @param _case (Case from Mongo)
 * @returns [Array] of allegation objects
 */
Allegation.parseAllegations = function (_case) {

    var allegations = [];
    var allegation = null;

    // Make sure you have allegations to parse
    if (_case && _case.caseDetails && _case.caseDetails.allegations) {
        var ca = _case.caseDetails.allegations;

        // First, parse the text
        if (ca.text) {
            var parts = ca.text.split(';');

            var start = 0;
            var end = 0;
            var txt = "";

            for (var i = 0; i < parts.length; i++) {
                var txt = parts[i].trim();

                if (txt) {
                    allegation = new Allegation(txt);

                    end = start + parts[i].length;

                    if (ca.annotations && ca.annotations.length) {
                        for (var n = 0; n < ca.annotations.length; n++) {
                            if (ca.annotations[n].begin >= start &&
                                ca.annotations[n].end <= end) {
                                allegation.terms.push({
                                    key: ca.text.substring(ca.annotations[n].begin, ca.annotations[n].end),
                                    text: (ca.annotations[n].displayName ? ca.annotations[n].displayName : ca.text.substring(ca.annotations[n].begin, ca.annotations[n].end)),
                                    concepts: ca.annotations[n].concepts
                                });
                            }
                        }
                    }

                    allegations.push(allegation);

                    start += parts[i].length + 1;
                }
            }
        }
    }

    return allegations;
};

// findConceptsForAllegation is working but only finds concepts for the first allegation
Allegation.getConceptsForAllegation = function(allegation) {

    var allegationConcepts = [];

    if(allegation && allegation.terms){
        
        var terms = allegation.terms;

        // Returns common concept objects for allegation
        terms.forEach(function(term, index){
            term.concepts.forEach(function(concept, index){
                allegationConcepts.push(concept);
            })

            
            // allegationConcepts.push.apply(term.concepts);
        });
    }
  return allegationConcepts;
 };




