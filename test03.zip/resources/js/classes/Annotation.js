function Annotation() {

}
/**
 * Static method to read an annotation's display name
 */
Annotation.getDisplayName = function(annotation) {

    if (annotation)
    {
        if (annotation.displayName)
        {
            return annotation.displayName;
        }
        else if (annotation.snippet && annotation.snippet.text && annotation.snippet.offset &&
                 annotation.begin && annotation.end)
        {
            return annotation.snippet.text.substr(
                annotation.snippet.offset, annotation.end - annotation.begin);
        }
        else
        {
            return annotation.type + " Annotation";
        }
    }
};