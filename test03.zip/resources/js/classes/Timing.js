function Timing(description) {
    this.description = description;
    this.start = new Date();
    this.end = null;
}
Timing.prototype.display = function() {
    this.end = new Date();
    console.log("Start " + this.description + " at " + this.start.toLocaleTimeString());
    console.log("End " + this.description + " at " + this.end.toLocaleTimeString());
    console.log("Elapsed Time for " + this.description + " = " + (this.end.getTime() - this.start.getTime()) + " milliseconds.");
};