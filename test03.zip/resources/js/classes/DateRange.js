//add a getQuarter function the the Date class
Date.prototype.getQuarter = function(){

    if(this.getMonth() >= 0 && this.getMonth() < 3){
        return 1;
    } else if(this.getMonth() >= 3 && this.getMonth() < 6){
        return 2;
    } else if(this.getMonth() >= 6 && this.getMonth() < 9){
        return 3;
    } else if(this.getMonth() >= 9 && this.getMonth() < 12){
        return 4;
    } else {//invalid date
        return -1;
    }
};


var months = ["January", "Febuary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var quarters = ["", "January - March", "April - June", "July - September", "October - December"];

//creates a DateRange object
function DateRange(start, end, type){
    var r = {};
    r.start = start;
    r.end = end;
    r.type = type;
    r.label = DateRange.determineLabel(r.type, r.start);
    return r;
}

//create DateRange based on label
DateRange.getRangeFromLabel = function(type, label){
    var range = null;
    label = label.toString().split(" ");

    switch(type){
        case "Year":
        case "year":
            range = DateRange.getRangeForYear(new Date('01/01/' + label[0]));
            break;
        case "Month":
        case "month":
            range = DateRange.getRangeForMonth(new Date((months.indexOf(label[0]) + 1) + '/01/' + label[1] ));
            break;
        case "Quarter":
        case "quarter":
            range = DateRange.getRangeForQuarter(new Date((months.indexOf(label[0]) + 1) + "/01/" + label[3]));
            break;
        default:
            //deal with invalid type
    }
    return range;
};

//create DateRange based on the period name
DateRange.getRangeFromName = function(type, name){
    var range = null;
    label = name.toString().split(" ");

    switch(type){
        case "Year":
        case "year":
            range = DateRange.getRangeForYear(new Date('01/01/' + label[0]));
            break;
        case "Month":
        case "month":
            //months start at 0 so need to add 1
            range = DateRange.getRangeForMonth(new Date((months.indexOf(label[0]) + 1) + '/01/' + label[1]));
            break;
        case "Quarter":
        case "quarter":
            var month;
            if(label[0] == "January"){
                month = "01";
            } else if(label[0] == "April"){
                month = "04";
            } else if(label[0] == "July"){
                month = "07";
            } else if(label[0] == "October"){
                month = "10";
            }
            range = DateRange.getRangeForQuarter(new Date(month + "/01/" + label[3]));
            break;
        default:
            //deal with invalid type
    }
    return range;
};

/**creates a Range object for the year the date pased would be in
 * @params dt - a valid date
 * returns a Range
 */
DateRange.getRangeForYear = function(dt){
    if(dt){
        dt = new Date(dt);
        return DateRange(new Date('01/01/' + dt.getFullYear()), new Date('01/01/' + (dt.getFullYear() + 1)), "Year");
    } else {
        //handle if no date was passed
    }
};

DateRange.getRangeForMonth = function(dt){
    if(dt){
        dt = new Date(dt);
        var endDate = null;
        if(dt.getMonth() == 11){//it is December, end date should be the first day of the next year
            endDate = "01/01/" + (dt.getFullYear() + 1);
        }else {//it should be the first day of the next month
            endDate = (dt.getMonth() + 2) + '/01/' + dt.getFullYear();
        }
        return new DateRange(new Date((dt.getMonth() + 1) + '/01/' + dt.getFullYear()), new Date(endDate), "Month");
    } else {
        //handle if no date was passed
    }
};

DateRange.getRangeForQuarter = function(dt){
    if(dt){
        dt = new Date(dt);
        var startDate;
        var endDate;
        if(dt.getQuarter() == 1){
            startDate = "01/01/" + dt.getFullYear();
            endDate = "04/01/" + dt.getFullYear();
        }else if(dt.getQuarter() == 2){
            startDate = "04/01/" + dt.getFullYear();
            endDate = "07/01/" + dt.getFullYear();
        }else if(dt.getQuarter() == 3){
            startDate = "07/01/" + dt.getFullYear();
            endDate = "10/01/" + dt.getFullYear();
        }else if(dt.getQuarter() == 4){
            startDate = "10/01/" + dt.getFullYear();
            endDate = "01/01/" + (dt.getFullYear() + 1);
        }
        return DateRange(new Date(startDate), new Date(endDate), "Quarter");
    }else {
        //handle if no date was passed
    }


};

DateRange.getRangeForDate = function(dt, rangeType){
    switch(rangeType){
        case "Year":
        case "year":
            return DateRange.getRangeForYear(dt);
        case "Month":
        case "month":
            return DateRange.getRangeForMonth(dt);
        case "Quarter":
        case "quarter":
            return DateRange.getRangeForQuarter(dt);
        default:
            console.log("Invalid range type.")
    }
}

DateRange.getNameForQuarter = function(dt){
    dt = new Date(dt);
    //return dt.toString('yyyy-') + dt.getQuarter();
    return dt.getFullYear() + "-" + dt.getQuarter();
};
DateRange.getNameForYear = function(dt){
    dt = new Date(dt);
    return "" + dt.getFullYear();
};

DateRange.getNameForMonth = function(dt){
    dt = new Date(dt);
    //return dt.toString('yyyy-MM');
    return dt.getFullYear() + '-' + dt.getMonth();
};

// DateRange.prototype.isDateWithin = function(dt){
//     if(dt){
//         return (dt >= this.start && dt < this.end);
//     } else {
//         return false;
//     }
// };

DateRange.isDateWithinRange = function(dt, range){
    if(dt){
        return (dt >= range.start && dt < range.end);
    } else {
        return false;
    }
};

DateRange.determineLabel = function(type, start){
    var label = "";
    start = new Date(start);

    switch(type){
        case "Year":
        case "year":
            label = start.getFullYear();
            break;
        case "Month":
        case "month":
            label = months[start.getMonth()] + " " + start.getFullYear();
            break;
        case "Quarter":
        case "quarter":
            label = quarters[start.getQuarter()] + " " + start.getFullYear();
            break;
        default:
            label = "invalid";
            //invalid range type
    }

    return label;
};