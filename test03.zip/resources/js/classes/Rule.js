/**
 * Rule class
 */
function Rule(ruleName) {
    this.name = ruleName;
    this.terms = [];
}

Rule.prototype.getConcepts = function(){
    return Rule.getConceptsForRule(this);
};

/**
 * Parse rules from a case
 * @param _case (Case from Mongo)
 * @returns [Array] of ruleResultsList objects
 */
Rule.parseRules = function (_case) {

    var rules = [];
    var rule = null;

    // Make sure you have allegations to parse
    if (_case && _case.analysisResults && _case.analysisResults.ruleResultsList) {
        var rl = _case.analysisResults.ruleResultsList;
        for (var i = 0; i < rl.length; i++) {
            var r = rl[i];
            rule = new Rule(r.ruleName);
            rules.push(rule);
            for (var n = 0; n < r.impairmentGroupingLevelList.length; n++) {
                var igl = r.impairmentGroupingLevelList[n];
                for (var s = 0; s < igl.medicalEvidenceStatementList.length; s++) {
                    var mes = igl.medicalEvidenceStatementList[s];
                    rule.terms.push({
                        key: mes.conceptDescriptor.displayName,
                        text: mes.conceptDescriptor.displayName,
                        concepts: [{
                            codeSystem: mes.conceptDescriptor.codeSystem,
                            code: mes.conceptDescriptor.code
                        }]
                    });
                }
            }
        }
    }

    return rules;
};

/**
 * Returns all concepts for the rule
 */
Rule.getConceptsForRule = function(rule) {

    var ruleConcepts = [];

    if(rule && rule.terms){
        
        var terms = rule.terms;

        // Returns common concept objects for allegation
        terms.forEach(function(term, index) {
            term.concepts.forEach(function(concept, index){
                ruleConcepts.push(concept);
            })

        
        });
    }
  
    return ruleConcepts;
 };








