/**
 * Represents a concept
 */
function Concept(codeSystem, code)
{
    this.codeSystem = codeSystem;
    this.code = code;
}
/**
 * Returns the concept as a string.
 */
Concept.prototype.toString = function() {
    return Concept.toString(this);
};
/**
 * Tests whether this concept equals another.
 */
Concept.prototype.equals = function(concept) {
    return Concept.equals(this, concept);
}
/**
 * Tests whether an object is ostensibly a concept
 * (contains a codeSystem and a code field)
 */
Concept.isConcept = function(candidate) {

    return (candidate &&
            candidate.codeSystem &&
            candidate.code);
};
/**
 * Tests whether two concept objects are for the same
 * codeSystem and code
 */
Concept.equals = function(concept1, concept2) {

    return (Concept.isConcept(concept1) &&
            Concept.isConcept(concept2) &&
            concept1.codeSystem == concept2.codeSystem &&
            concept1.code == concept2.code);
};
/**
 * Returns the concept as a string
 */
Concept.toString = function(concept) {

    if (Concept.isConcept(concept)) 
    {
        return concept.codeSystem + " - " + concept.code;
    }
    else
    {
        throw new Error("Object is not a valid concept");
    }
};