/**
 * Social Security Number
 */
function SSN()
{

}
/**
 * Format a string as a Social Security Number
 */
SSN.format = function(value) {
    
    if (value)
    {
        var regEx = /^\d{3}-?\d{2}-?\d{4}$/;

        if (value.match(regEx))
        {
            if (value.length == 9)
            {
                return value.substring(0, 3) + '-' +
                    value.substring(3, 5) + '-' +
                    value.substring(5);
            }
            else if (value.length == 10)
            {
                if (value.charAt(3) == '-')
                {
                    return value.substring(0, 6) + '-' +
                        value.substring(6);
                }
                else
                {
                    return value.substring(0, 3) + '-' +
                        value.substring(3);
                }
            }
            else
            {
                return value;
            }
        }
        else
        {
            return value;
        }
    }
    else
    {
        return "";
    }
};