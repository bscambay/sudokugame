/**
 * String Utilities
 */
function StringUtil()
{

}

/**
 * Converts text to title case (initial caps)
 */
StringUtil.toTitleCase = function(str) {

    if (str)
    {
        str = str.replace(/\w*\S*/g, function(txt) {
            return txt.charAt(0).toUpperCase() + 
                txt.substr(1).toLowerCase();
        });

        return str;
    }
    else
    {
        return str;
    }
};