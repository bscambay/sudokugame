
function AnnotationFormatter(){

}

var mapURL = function(location){
    var updated_location = location;
    var link_begin = "https://www.ssa.gov/disability/professionals/bluebook/";
    var link_adult_end = "-Adult.htm";
    var link_child_end= "-Childhood.htm";

    var chapters = {
        1: "1.00-Musculoskeletal",
        2: "2.00-SpecialSensesandSpeech",
        3: "3.00-Respiratory",
        4: "4.00-Cardiovascular",
        5: "5.00-Digestive",
        6: "6.00-Genitourinary",
        7: "7.00-HemicandLymphatic",
        8: "8.00-Skin",
        9: "9.00-Endocrine",
        10: "10.00-MultipleBody",
        11: "11.00-Neurological",
        12: "12.00-MentalDisorders",
        13: "13.00-NeoplasticDiseases-Malignant",
        14: "14.00-Immune",
        100: "100.00-GrowthImpairment",
        101: "101.00-Musculoskeletal",
        102: "102.00-SpecialSensesandSpeech",
        103: "103.00-Respiratory",
        104: "104.00-Cardiovascular",
        105: "105.00-Digestive",
        106: "106.00-Genito-Urinary",
        107: "107.00-HemicandLymphatic",
        108: "108.00-Skin",
        109: "109.00-Endocrine",
        110: "110.00-MultipleBody",
        111: "111.00-Neurological",
        112: "112.00-MentalDisorders",
        113: "113.00-NeoplasticDiseases",
        114: "114.00-Immune"
    };

    if(chapters[location.chapter] != undefined && location.chapter < 15){
        updated_location.url = link_begin + chapters[location.chapter] + link_adult_end;
    }else if(chapters[location.chapter] != undefined && location.chapter >= 100){
        updated_location.url = link_begin + chapters[location.chapter] + link_child_end;
    }else {
        updated_location.url = "https://www.ssa.gov/disability/professionals/bluebook/AdultListings.htm";
    }

    return updated_location.url;

}


//takes a single annotation and converts in into a standard annotation format
//can take either a viewerAnnotation or a medicalEvidenceStatementList from disabilityCase
AnnotationFormatter.convertToStandardFormat = function(ann, annotations){
    var formattedAnn = null;
    if(ann._class == "formattedAnnotation"){
        formattedAnn = ann;
    }else if(ann._class == "gov.ssa.hit.med.data.megahit.rules.AnnotationIdentifier"){//from disabilityCase
        formattedAnn = formatAnnotationIdentifier(ann, annotations);
    }else if(ann._class == "gov.ssa.hit.med.data.megahit.rules.AdditionalClinicalStatementInfo"){//from disabilityCase
        formattedAnn = formatAnnotationIdentifier(ann, annotations);
    }else if(ann._class == "gov.ssa.hit.med.data.viewer.ViewerAnnotation"){//from viewerAnnotation
        formattedAnn = formatViewerAnnotation(ann);
    }else{
        //invaid format
    }
    return formattedAnn;
}

//formats a annotation from medicalEvidenceStatementList in disabilityCase
var formatAnnotationIdentifier = function(ann, annotations){
    var formattedAnn = ann;
    formatSharedFields(ann, formattedAnn);

    //find the annotation that matches
    var viewerAnnotation = null;
    var numMatches = 0;
    for(var a = 0; a < annotations.length; a++){
        if(annotations[a].documentId == formattedAnn.documentId){
            if(annotations[a].begin == formattedAnn.begin){
                if(annotations[a].end == formattedAnn.end){
                    if(annotations[a].sectionId == formattedAnn.sectionId){
                        //it is a match
                        viewerAnnotation = annotations[a];
                        numMatches++;
                    }
                }
            }
        }
    }
    if(numMatches > 1){
        console.log("Found more then 1 match. - " + numMatches);
    }
    if(viewerAnnotation != null){
        formattedAnn = {};
        for(var a in viewerAnnotation){
            formattedAnn[a] = viewerAnnotation[a];
        }
        formattedAnn = formatViewerAnnotation(formattedAnn);
    }

     if(ann.ruleName != undefined){
        formattedAnn.ruleName = ann.ruleName;
     }

    formattedAnn._class = "formattedAnnotation";

    return formattedAnn;
};

//formats an annotation from viewerAnnotation
var formatViewerAnnotation = function(ann){
    var formattedAnn = ann;
    formatSharedFields(ann, formattedAnn);

    if(ann.type != undefined){
        formattedAnn.type = ann.type;
    }else {
        //is there a default?
    }

    if(ann.bodyPart != undefined){
        formattedAnn.bodyPart = ann.bodyPart;
    }else {

    }

    if(ann.bodySystem != undefined){
        formattedAnn.bodySystem = ann.bodySystem;
    }else {

    }

    if(ann.displayName != undefined){
        formattedAnn.displayName = ann.displayName;
    }else {

    }



    if(ann.concepts != undefined){
        var concepts = [];//is it ok to end up with an empty array?
        for(var index = 0; index < ann.concepts.length; index++){
            var concept = ann.concepts[index];
            if(Concept.isConcept(concept)) {
                concepts.push(concept);
            }else {
                //ignore it for now
                //does it have value if there is only scheme or only code?
                // No - codeSystem (was scheme) and code are required
            }
        }
        formattedAnn.concepts = concepts;
    }else {
        //is it ok to have no concepts?
        //should it be set to an empty array or just left out?
    }

    if(ann.blueBookLocations != undefined){
        var locations = []
        for(loc in ann.blueBookLocations){
            var location = ann.blueBookLocations[loc];
            if(location.chapter != undefined && location.section != undefined){
                locations.push({
                    chapter: location.chapter,
                    section: location.section,
                    url: mapURL(location) + "#" + location.chapter + "_" + location.section.substring(0,2),
                    bodySystem: location.bodySystem
                });
            }
        }
        formattedAnn.blueBookLocations = locations;
    }

    if(ann.date != undefined){
        formattedAnn.date = new Date(ann.date);
    }else {

    }

    if(ann.bodySubsystem != undefined){
        formattedAnn.bodySubsystem = ann.bodySubsystem;
    }else {

    }


    formattedAnn._class = "formattedAnnotation";

    return formattedAnn;
};

//formats fields that are in both medicalEvidenceStatementList and viewerAnnotation
var formatSharedFields = function(ann, formattedAnn){

    formattedAnn = ann;

    if(ann._id != undefined){
        formattedAnn._id = ann._id;
    }

    if(ann.snippet != undefined){
        //formattedAnn.snippet = {};
        if(ann.snippet.text != undefined){
            formattedAnn.snippet.text = ann.snippet.text;
        }else{
            formattedAnn.snippet.text = "Snippet Not Found";
        }

        if(ann.snippet.offset != undefined){
            formattedAnn.snippet.offset = ann.snippet.offset;
        }else {
            //not sure what to do without an offset
        }
    }else{
        //Is there any value in the snippet if this is missing?
        formattedAnn.snippet = {
            text: "Snippet Not Found",
            offset: 0//not sure what this should be
        }
    }

    if(ann.documentId != undefined){
        formattedAnn.documentId = ann.documentId;
    }else {
        //what should the default be?
    }

    if(ann.sectionId != undefined){
        formattedAnn.sectionId = ann.sectionId;
    }else {
        //what should the default be?
    }

    if(ann.begin != undefined){
        formattedAnn.begin = ann.begin;
    }else {
        //what should the default be?
    }

    if(ann.end != undefined){
        formattedAnn.end = ann.end;
    }else {
        //what should the default be?
    }

    //name - not sure if we need to check for all these values or if setting defaults is better
    if(formattedAnn.snippet.text != undefined && formattedAnn.snippet.offset != undefined && formattedAnn.begin != undefined && formattedAnn.end != undefined){
        formattedAnn.name = formattedAnn.snippet.text.substring(formattedAnn.snippet.offset,
                                                (formattedAnn.snippet.offset + formattedAnn.end - formattedAnn.begin));
    }else {
        //?
    }

};

AnnotationFormatter.formatArrayOfAnnotations = function(arrayOfAnnotations, annotations){
    //for(s in arrayOfAnnotations){
    for(var s = 0; s < arrayOfAnnotations.length; s++){
        arrayOfAnnotations[s] = AnnotationFormatter.convertToStandardFormat(arrayOfAnnotations[s], annotations);
    }
    return arrayOfAnnotations;
};