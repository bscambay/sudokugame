//Viewer Annotation Type Property Constants
//Note: color must be a hex value for it to work with the bubble chart
const DISEASEDISORDER = {
    icon: "heartbeat",
    color: "#EEB6B7",//"#e59393",//"#EEB6B7",
    highlightColor: "rgba(186, 44, 46, 1)", //#FF99CC",//"#f9dede",
    text: "Disease/Disorder",
    dbName: "DiseaseDisorder"
}
const SIGNSYMPTOM = {
    icon: "ambulance",
    color: "#98dafc",//"#8ba6ca",//"#98dafc",
    highlightColor: "rgba(4, 94, 139, 1)", //#00FFFF",//"#dce4ef",
    text: "Sign/Symptom",
    dbName: "SignSymptom"
}
const ANATOMICSITE = {
    icon: "child",
    color: "#A1EDE0", //"#94bfa2",//"rgba(161, 237, 224, 1)",
    highlightColor: "rgba(23, 120, 104, 1)", //#99FF99",//"#e7f4e4",
    text: "Anatomic Site",
    dbName: "AnatomicSite"
}
const PROCEDURE = {
    icon: "stethoscope",
    color: "#F8E2B0", //"#fad980",//"rgba(248, 226, 176, 1)",
    highlightColor: "rgba(136, 99, 12, 1)", //#FFCC33",//"#fff1d2",
    text: "Procedure",
    dbName: "Procedure"
}
const MEDICATION = {
    icon: "medkit",
    color: "#BDCBFF", //"#B292F8",//"rgba(189, 203, 255, 1)",
    highlightColor: "rgba(0, 48, 219, 1)", //#CC99FF",//"#E5C5FF",
    text: "Medication",
    dbName: "Medication"
}

const DEFAULT = {
    icon: "calendar",
    color: "#A9E7A7", //"#a9e7a7",//"rgba(169, 231, 167, 1)"",
    highlightColor: "#FFFF99",//"yellow",
    text: "Unknown",
    dbName: ""
}

const MULTIPLEANNOTATIONS = {
    icon: "files-o",
    color: "#00FF00", // Lime HIghlight
    highlightColor: "rgba(0, 255, 0, 1)", //Lime Highlight
    text: "Multipe Annotations",
    dbName: ""
}


function AnnotationsUtil() {

    this.annotationTypes = {
        DiseaseDisorder: DISEASEDISORDER,
        SignSymptom: SIGNSYMPTOM,
        AnatomicSite: ANATOMICSITE,
        Procedure: PROCEDURE,
        Medication: MEDICATION
    };

    return this;
};

AnnotationsUtil.prototype.getAnnotationTypes = function () {
    var names = [];

    for (type in this.annotationTypes) {
        names.push(this.annotationTypes[type].text);
    }

    return names;
};

AnnotationsUtil.prototype.getAnnotationTypesDBValues = function () {
    var dbNames = [];

    for (type in this.annotationTypes) {
        dbNames.push(this.annotationTypes[type].dbName);
    }

    return dbNames;
};

//Return appropriate constant properties object based on annotationType
AnnotationsUtil.prototype.getAnnotationProps = function (annotationType) {
    if (this.annotationTypes[annotationType]) {
        return this.annotationTypes[annotationType];
        //dealing with this here instead of in annotationTypes so 'multipleAnnotations' doesn't show up in filter
    } else if (annotationType === "MultipleAnnotations") {
        return MULTIPLEANNOTATIONS;
    } else {
        return DEFAULT;
    }
};

//Return appropriate color based on annotationType
AnnotationsUtil.prototype.getColor = function (annotationType) {
    if (this.annotationTypes[annotationType]) {
        return this.annotationTypes[annotationType].color;
    } else {
        return DEFAULT.color;
    }
};

//Return appropriate text to display based on annotationType
AnnotationsUtil.prototype.getText = function (annotationType) {
    if (this.annotationTypes[annotationType]) {
        return this.annotationTypes[annotationType].text;
    } else {
        return DEFAULT.text;
    }
};

//Return appropriate highlight color based on annotationType
AnnotationsUtil.prototype.getHighlightColor = function (annotationType) {
    if (this.annotationTypes[annotationType]) {
        return this.annotationTypes[annotationType].highlightColor;
    } else {
        return DEFAULT.highlightColor;
    }
};

//Return appropriate icon based on annotationType
AnnotationsUtil.prototype.getIcon = function (annotationType) {
    if (this.annotationTypes[annotationType]) {
        return this.annotationTypes[annotationType].icon;
    } else {
        return DEFAULT.icon;
    }
};

//Return appropriate database name based on annotation display text
AnnotationsUtil.prototype.getDBNameFromDisplayText = function (annotationDisplayText) {
    for(a in this.annotationTypes){
        if(this.annotationTypes[a].text == annotationDisplayText){
            return this.annotationTypes[a].dbName;
        }
    }

    return "";
};

/*
 * Combine multiple overlapping annotations into single annotation with sub-annotations.
 * @param annotations - array of overlapping annotations
 * @param begin - beginning offset of combinedAnnotation
 * @param end - ending offset of combinedAnnotation
 * @returns combinedAnnotation -  single annotation with all overlapping annotations as sub-annotations and a
 * begin and end offset to encompass all sub-Annotations
 */
function combineAnnotations(annotations, begin, end) {
    var combinedAnnotation = {
        'begin': begin,
        'end': end,
        'type': "MultipleAnnotations",
        'moreAnnotations': []
    };

    //add the overlapping annotations to combinedAnnotation
    for (var i = 0; i < annotations.length; i++) {
        combinedAnnotation.moreAnnotations.push(annotations[i]);
    }
    return combinedAnnotation;
}

/*
 * builds the text to be displayed in the tooltip for annotations that
 * contain sub-annotations.
 * @param annotations - list of annotations being combined.
 * @returns text - formatted string of annotation type and display name
 * MAY NOT NEED THIS AFTER APPLYING COMPILE DIRECTIVE TO DOC TEXT
 */
AnnotationsUtil.prototype.buildText = function (annotations) {

    var text = "";

    //first pull out the nested annotations
    while(this.containsMultiples(annotations)) {
        annotations = this.getAllAnnotations(annotations);
    }

    for (var i = 0; i < annotations.length; i++) {
        var annotation = annotations[i];
        var props = this.getAnnotationProps(annotation.type);
        var highlight = annotation.snippet.text.substring(annotation.snippet.offset, annotation.snippet.offset + annotation.end - annotation.begin)

        if (i === 0) {
            text += highlight + " (" + props.text + ") ";
        } else {
            text += ", " + highlight + " (" + props.text + ") ";
        }
    }
    return text;
}

/* Group annotations with offsets that fall within the same range. These will be a new annotation with the subAnnotations
 * that fall in the same offset range.
 *  @param array of annotations to be combined based on range
 *  @returns array of annotations where overlapping offsets have been combined
 *  DESIGNED TO BE USED IN A WHILE LOOP IN CONJUNTION WITH checkForOverlap()
 */
AnnotationsUtil.prototype.processAnnotations = function (annotations) {

    var processedAnnotations = [];

    for (var i = 0; i < annotations.length; i++) {
        var annotation1 = annotations[i];
        var rangeBegin = annotation1.begin;
        var rangeEnd = annotation1.end;
        var matches = [];
        for (var j = (i + 1); j < annotations.length; j++) {
            var annotation2 = annotations[j];
            if ((annotation2.begin >= rangeBegin && annotation2.begin <= rangeEnd) ||
                (annotation2.end >= rangeBegin && annotation2.end <= rangeEnd)) {
                //if begin or end falls withing range, add to matches
                matches.push(annotation2);
                //updated ranges if needed
                if (annotation2.begin < rangeBegin) {
                    rangeBegin = annotation2.begin;
                }
                if (annotation2.end > rangeEnd) {
                    rangeEnd = annotation2.end;
                }
                //once matched, remove from array to prevent duplicates
                annotations.splice(j, 1);
            }
        }
        //If matches were found, add the annotation being compared as well
        if (matches.length > 0) {
            matches.push(annotation1);
        }
        /* if no matches were found just add annotation1
         * right to processedAnnotations. Else combine overlapping annotations
         * using the range to highlight the combination.
         */
        if (matches.length === 0) {
            processedAnnotations.push(annotation1);
        } else {
            processedAnnotations.push(combineAnnotations(matches, rangeBegin, rangeEnd));
        }
    }
    return processedAnnotations;
}

/* Check for annotations that fall within the same range,
 * @returns true if annotations overlap and false if no annotations overlap
 * @param array of annotations to check for overlapping offsets
 */
AnnotationsUtil.prototype.checkForOverlap = function (annotations) {
    for (var i = 0; i < annotations.length; i++) {
        var annotation1 = annotations[i];
        var rangeBegin = annotation1.begin;
        var rangeEnd = annotation1.end;
        for (var j = (i + 1); j < annotations.length; j++) {
            var annotation2 = annotations[j];
            if ((annotation2.begin >= rangeBegin && annotation2.begin <= rangeEnd) ||
                (annotation2.end >= rangeBegin && annotation2.end <= rangeEnd)) {
                //if begin or end falls withing range, return true
                return true;
            }
        }
    }
    //if no annotation offsets overlap, return false
    return false;
}

/*
 * Method always keeps an unaltered version of the page text and all
 * annotations found on the page so we can continuously apply different
 * filter settings without losing data.
 * @param page - array of page objects
 * @param filteredAnnotations - the actual annotations we wish to display to
 * the user (highlight).
 */
AnnotationsUtil.prototype.resetHighlights = function (page, filteredAnnotations) {

    if (page.unhighlightedText == undefined) {
        //first time highlighting - keep a copy of the unhighlighted text
        page.unhighlightedText = page.text
        page.allAnnotations = page.annotations.slice(0);
    } else {
        //page was already highlighted need to remove highlights before redoing
        page.text = page.unhighlightedText;
        page.annotations = page.allAnnotations.slice(0);
    }

    var keep;

    for (var i = 0; i < page.annotations.length; i++) {
        keep = false;
        var pageAnnId = page.annotations[i]._id;
        for (var j = 0; j < filteredAnnotations.length; j++) {
            var filteredAnnId = filteredAnnotations[j]._id;
            if (pageAnnId == filteredAnnId) {
                keep = true;
            }
        }
        if (keep == false) {
            //remove annotation
            page.annotations.splice(i, 1);
            i--;
        }
    }
}

/*
 * Format a string of html list items to populate the dropdown button where multiple
 * annotations are found on the same word/phrase.
 * @param annotations - array of annotation objects
 * @returns listItems - string of html code
 */
AnnotationsUtil.prototype.populateDropdown = function (annotations) {

    var listItems = "";
    var annProps;

    while (this.containsMultiples(annotations)) {
        annotations = this.getAllAnnotations(annotations);
    }

    for (var i = 0; i < annotations.length; i++) {
        var annotation = annotations[i];
        var dropdownText = annotation.snippet.text.substring(annotation.snippet.offset, annotation.snippet.offset + annotation.end - annotation.begin)
        annProps = this.getAnnotationProps(annotation.type);

        listItems += '<li class="xsDropdown cursor-pointer" role = "presentation" style="background-color : ' + annProps.color + ';" ng-click="toggleInfo(\'' + annotation._id + '\')"><a role = "menuitem" tabindex = "-1">'
            + dropdownText
            + '</a></li>';
    }

    return listItems;
}

/*
 * Check to see if the array contains any nested annotations (annotationType = "MultipleAnnotations)
 * @param annotations - array of annotation objects
 * @ returns true or false boolean value
 */
AnnotationsUtil.prototype.containsMultiples = function (annotations) {

    for (var i = 0; i < annotations.length; i++) {
        if (annotations[i].type === "MultipleAnnotations") {
            return true;
        }
    }

    return false;
}

/*
 * Unwrap nexted annotation objects to get  a list of all the overlapping
 * annotations that had been combined previously.
 * @param annotations - array of annotations, some nested
 * @returns allAnnotations - un-nested list of annotations
 * DESIGNED TO BE USED IN A WHILE LOOP  IN CONJUNCTION WITH containsMultiples()
 */
AnnotationsUtil.prototype.getAllAnnotations = function (annotations) {

    var allAnnotations = [];

    for (var i = 0; i < annotations.length; i++) {
        var annotation = annotations[i];
        //if annotations are nested, add each individual annotation
        if (annotation.hasOwnProperty("moreAnnotations")) {
            for (var j = 0; j < annotation.moreAnnotations.length; j++) {
                allAnnotations.push(annotation.moreAnnotations[j]);
            }
        } else {
            allAnnotations.push(annotation);
        }
    }

    return allAnnotations;
}
