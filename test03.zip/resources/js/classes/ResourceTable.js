/*
Instructions for use:

1.  Add replacement for hardcoded value below following "KEY:'Value'" format seen below

2.  Replace actual hardcode with call to resource table and key EG: {{pageData.resourceTable.GENDER}}

3.  Be sure that pageData is exposed on directive/controller for HTML with $scope.pageData = pageService.pageData; 

4.  See patient-info.html for further examples of replaced hardcode
    See patient-controller.js and/or chart-directive.js for placement of $scope.pageData = pageService.pageData;
*/


function ResourceTable() 
{
}

/**
 * "EN" String resource table
 */
ResourceTable.en = {

    CASE_SEARCH: 'New Case Search',
    NAME:'Name',
    SEARCH: 'Search',
    RESET: 'Reset',
    SEARCH_CRITERIA:'Search Criteria',
    SEARCH_RESULTS:'Search Results',
    FIRST_NAME:"First Name",
    LAST_NAME:"Last Name",
    CS_COLUMN_HEADERS: {
        DOC_COUNT: "# Docs"
    },
    SSN: 'SSN',
    STATUS:'Status',
    FOLDER_NUMBER:'Folder Number',
    CASE_NUMBER:'Case Number',
    EVIEW: 'eView',
    REFRESH: 'Refresh',
    LOGOUT:'Logout',
    GENDER:'Gender:',
    HEIGHT: 'Height:',
    WEIGHT: 'Weight',
    DATE_OF_BIRTH:'Date of Birth:',
    CLAIMANT_SUMMARY:'Claimant Summary',
    IMPAIRMENT_RULES: 'Impairment Rules',
    ALLEGATIONS: 'Allegations',
    DOCUMENTS: 'Documents',
    ANNOTATIONS: 'Annotations',
    ANNOTATION_TYPES: 'Annotation Type',
    ADVANCED_SEARCH: 'Advanced Search',
    CASE_TIMELINE: 'Case Timeline',
    GROUP_BY: 'Group By',
    CHART_TYPE: 'Chart Type',
    PERIOD: 'Period',
};