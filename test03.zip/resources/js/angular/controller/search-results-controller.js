app.config(function($routeProvider) {
    $routeProvider.when("/searchResults/:searchTerm", {
        templateUrl: "searchResults",
        controller: "searchResultsController",
        activeTab: "searchResults"
    });
});

app.controller('searchResultsController', function($scope, $http, $routeParams, $location, $sce, caseService, documentService, pageService, stateService) {

     if (pageService.ensureCaseSelected())
    {
            pageService.setPageTitleIcon("search");
            pageService.setPageTitle("Search Results");


            $scope.initialterms = []

            if ($routeParams.searchTerm) {
                var str = $routeParams.searchTerm;
                var array = str.split(',')
                array.forEach(function(element) {
                    $scope.initialterms.push(element)
                })
            }


            var conceptButtonsOn = false;

            $scope.results = [];
            $scope.filteredAnnotations = [];
            $scope.expandedDocument = false;
            $scope.documentSourceIcon = "fa fa-plus";
            $scope.openSave = false;
            var filteredResultsStash = [];
            var tempFacet = "";
            var allDocuments = true;
            var allSynonyms = true;
            var allTerms = true;
            var allAssertions = true;
            var allBluebooks = true;
            var allBodysystems = true;

            $scope.documents = [];
            $scope.synonyms = [{
                'name': 'MS'
            }, {
                'name': 'Melancholy'
            }, {
                'name': 'Doctor'
            }, {
                'name': 'Radiation'
            }, {
                'name': 'Distressed'
            }];
            $scope.dates = [{
                'name': 'Past Year', 'range' : ['2017']
            }, {
                'name': 'Past 3 Years', 'range' : ['2017', '2016', '2015']
            }, {
                'name': 'Past 5 Years', 'range' : ['2017', '2016', '2015', '2014', '2013']
            }];
            $scope.savedsearches = [{
                'name': 'MySearch1'
            }, {
                'name': 'Adenotyphus results'
            }];
            $scope.assertionoptions = [{
                'name': 'Negative'
            }, {
                'name': 'Conditional'
            }, {
                'name': 'Uncertain'
            }, {
                'name': 'Subjective'
            }, {
                'name': 'Generic'
            }, {
                'name': 'History'
            }];

            $scope.assertions = [];
            $scope.bluebooks = [];
            $scope.bluebooks1 = [];
            $scope.bodysystems = [];
            $scope.selectedFacets = [];
            $scope.terms = [];
            $scope.allFacets = [$scope.documents, $scope.terms, $scope.synonyms, $scope.dates, $scope.assertions, $scope.bluebooks, $scope.bodysystems, $scope.assertions];
            $scope.searchtitle = stateService.getState('searchTitle');
            $scope.alldocuments = {}
            $scope.allsynonyms = {}
            $scope.allTerms = {}
            $scope.allAssertions = {};
            $scope.allbluebooks = {}
            $scope.allbodysystems = {}
            $scope.titleTerms = [];
            $scope.resultsLength = 0;

            function includes(container, value) {
                return container.indexOf(value) != -1;
            }


            $scope.selectAllFacets = function() {
                $scope.alldocuments.selected = true;
                $scope.allsynonyms.selected = true;
                $scope.allTerms.selected = true;
                $scope.allAssertions.selected = true;
                $scope.allbluebooks.selected = true;
                $scope.allbodysystems.selected = true;
            }



            $scope.selectAllFacets();

            $scope.unselectDates = function(dateIn) {
                $scope.dates.forEach(function(date){
                    if (dateIn != date) {
                        date.selected = false;
                    }
                })
            }

            $scope.showAll = function() {
                $scope.selectAllFacets();
                $scope.allFacets.forEach(function(facetArray) {
                    facetArray.forEach(function(arrayItem) {
                        arrayItem.selected = false;
                        if (arrayItem.name == "All Dates") {
                            arrayItem.selected = true;
                        }
                    })
                })
                allDocuments = true;
                allSynonyms = true;
                allTerms = true;
                allAssertions = true;
                allBluebooks = true;
                allBodysystems = true;
                $scope.applyFilters();
                $scope.selectedFacets = [];
                $scope.selectedFacets.push("All Documents");
                $scope.selectedFacets.push("All Synonyms");
                $scope.selectedFacets.push("All Terms");
                $scope.selectedFacets.push("All Assertions");
                $scope.selectedFacets.push("All Bluebooks");
                $scope.selectedFacets.push("All Body Systems");
                $scope.selectedFacets.push("All Dates");

                if (conceptButtonsOn) {
                $scope.terms.forEach(function(term){
                    var alreadyPushed = false;
                    $scope.selectedFacets.forEach(function(sf){
                        if (sf == term.name){
                            alreadyPushed = true;
                        }
                    })
                    if (alreadyPushed == false){
                        $scope.selectedFacets.push(term.name)
                    }
                })
                }

                $scope.titleTerms.forEach(function(titleTerm){
                    titleTerm.shown = true;
                })
            }


            $scope.closeAll = function() {
                $scope.showDocumentFacet = false;
                $scope.showSynonymFacet = false;
                $scope.showTermFacet = false;
                $scope.showDateFacet = false;
                $scope.showSavedFacet = false;
                $scope.showAssertionFacet = false;
                $scope.showBlueBookFacet = false;
                $scope.showBodySystemFacet = false;
                $scope.showAssertionsFacet = false;
            }

            $scope.selectAll = function(facet) {
                if (facet == 'documents') {
                    $scope.documents.forEach(function(document){
                        document.selected = false;
                    })
                allDocuments = true;
                }
                if (facet == 'terms') {
                    $scope.terms.forEach(function(term){
                        term.selected = false;
                    })
                allTerms = true;
                }
                if (facet == 'assertions') {
                    $scope.assertions.forEach(function(assertion){
                        assertion.selected = false;
                    })
                allAssertions = true;
                }
                if (facet == 'bluebooks') {
                    $scope.bluebooks.forEach(function(bluebook){
                        bluebook.selected = false;
                    })
                allBluebooks = true;
                }
                if (facet == 'bodysystems') {
                    $scope.bodysystems.forEach(function(bodysystem){
                        bodysystem.selected = false;
                    })
                allBodysystems = true;
                }
            }

            $scope.unselectAll = function(facet) {
                if (facet == 'documents') {
                    allDocuments = false;
                }
                if (facet == 'terms') {
                    allTerms = false;
                }
                if (facet == 'dates') {
                    allDates = false;
                }
                if (facet == 'assertions') {
                    allAssertions = false;
                }
                if (facet == 'bluebooks') {
                    allBluebooks = false;
                }
                if (facet == 'bodysystems') {
                    allBodysystems = false;
                }
            }

            $scope.allFacetsButton = function(selectedFacet) {
                if (selectedFacet == 'All Documents' || selectedFacet == 'All Synonyms' || selectedFacet == 'All Terms' || selectedFacet == 'All Dates' || selectedFacet == 'All Assertions' || selectedFacet == 'All Bluebooks' || selectedFacet == 'All Body Systems') {
                    return true;
                }
                else {
                    return false;
                }
            }

            $scope.filterCheck = function(filteredResult) {
                return (filteredResult.docReady && filteredResult.termReady && filteredResult.dateReady && filteredResult.bluebookReady && filteredResult.bodysystemReady && filteredResult.assertionReady);
            }

            $scope.selectAllWhenNoneAreSelected = function(){
                var stillGoing = false;
                $scope.documents.forEach(function(document){
                    if (document.selected == true){
                        stillGoing = true;
                    }
                })
                if (stillGoing == false){
                    allDocuments = true;
                }

                stillGoing = false;
                $scope.terms.forEach(function(term){
                    if (term.selected == true){
                        stillGoing = true;
                    }
                })
                if (stillGoing == false){
                    allTerms = true;
                }

                stillGoing = false;
                $scope.dates.forEach(function(date){
                    if (date.selected == true){
                        stillGoing = true;
                    }
                })
                if (stillGoing == false){
                    allDates = true;
                }

                stillGoing = false;
                $scope.assertions.forEach(function(assertion){
                    if (assertion.selected == true){
                        stillGoing = true;
                    }
                })
                if (stillGoing == false){
                    allAssertions = true;
                }

                stillGoing = false;
                $scope.bluebooks.forEach(function(bluebook){
                    if (bluebook.selected == true){
                        stillGoing = true;
                    }
                })
                if (stillGoing == false){
                    allBluebooks = true;
                }

                stillGoing = false;
                $scope.bodysystems.forEach(function(bodysystem){
                    if (bodysystem.selected == true){
                        stillGoing = true;
                    }
                })
                if (stillGoing == false){
                    allBodysystems = true;
                }
            }


        $scope.getResultYear = function(filteredResultDate){
            var resultYear = filteredResultDate.substr(0,4);
            return resultYear;
        }

        $scope.resultsLengthFunction = function(){
            var lengthCounter = 0;
            filteredResultsStash.forEach(function(frs){
                if ($scope.filterCheck(frs)){
                    lengthCounter++;
                }
            })
            $scope.resultsLength = lengthCounter;
        }


            $scope.applyFilters = function() {
                $scope.selectAllWhenNoneAreSelected();
                var selectedDocs =[];
                    $scope.documents.forEach(function(document){
                        if (document.selected){
                            selectedDocs.push(document.documentId);
                        }
                    })
                filteredResultsStash.forEach(function(frs) {
                    frs.docReady = true;
                    frs.termReady = true;
                    frs.dateReady = true;
                    frs.assertionReady = true;
                    frs.bluebookReady = true;
                    frs.bodysystemReady = true;

// Documents
                    if (allDocuments != true) {
                    $scope.selectedFacets.forEach(function(sf) {
                        if (sf == "All Documents") {
                            var index = $scope.selectedFacets.indexOf(sf);
                            if (index > -1) {
                                $scope.selectedFacets.splice(index, 1);
                            }
                        }
                    })


                    $scope.documents.forEach(function(document){
                        if (!document.selected) {
                            if (document.documentId == frs.documentId) {
                                frs.docReady = false;
                            }
                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == document.name) {
                                    var index = $scope.selectedFacets.indexOf(sf);
                                    if (index > -1) {
                                        $scope.selectedFacets.splice(index, 1);
                                    }
                                }
                            })
                        }
                        if (document.selected) {
                            var alreadySelected = false;
                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == document.name) {
                                    alreadySelected = true;
                                }
                            })
                            if (!alreadySelected) {
                            $scope.selectedFacets.push(document.name)
                            }
                        }
                    })
                    if (!includes(selectedDocs, frs.documentId)){
                        frs.docReady = false;
                    }
                }

                if (allDocuments) {
                    $scope.documents.forEach(function(document){
                        $scope.selectedFacets.forEach(function(sf){
                            if (sf == document.name){
                                var index = $scope.selectedFacets.indexOf(sf);
                                if (index > -1) {
                                    $scope.selectedFacets.splice(index, 1);
                                }
                            }
                        })
                    })
                    var alreadySelected = false;
                    $scope.selectedFacets.forEach(function(sf){
                        if (sf == 'All Documents') {
                            alreadySelected = true;
                        }
                    })
                    if (alreadySelected == false) {
                        $scope.selectedFacets.push("All Documents")
                    }
                }






// terms
                    if (allTerms != true) {
                        $scope.selectedFacets.forEach(function(sf) {
                        if (sf == "All Terms") {
                            var index = $scope.selectedFacets.indexOf(sf);
                            if (index > -1) {
                                $scope.selectedFacets.splice(index, 1);
                            }
                        }
                    })
                    $scope.terms.forEach(function(term){
                        if (!term.selected) {
                            if (includes(frs.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase())) {
                                frs.termReady = false;
                            }
                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == term.name) {
                                    var index = $scope.selectedFacets.indexOf(sf);
                                    if (index > -1) {
                                        $scope.selectedFacets.splice(index, 1);
                                    }
                                }
                            })
                        }
                        if (term.selected) {
                            var alreadySelected = false;
                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == term.name) {
                                    alreadySelected = true;
                                }
                            })
                            if (!alreadySelected) {
                                $scope.selectedFacets.push(term.name)
                            }
                        }

                    })
                }
                var noTerms = true;
                $scope.terms.forEach(function(term){
                    $scope.selectedFacets.forEach(function(sf){
                        if (term.name == sf) {
                            noTerms = false;
                        }
                    })
                })

                if (allTerms || noTerms) {
                    var alreadyPushed = false;
                    $scope.terms.forEach(function(term){
                        if (conceptButtonsOn) {
                            term.selected = true;
                        }
                        var alreadyPushed = false;
                        if (!conceptButtonsOn) {
                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == term.name) {
                                    var index = $scope.selectedFacets.indexOf(sf);
                                    if (index > -1) {
                                        $scope.selectedFacets.splice(index, 1);
                                    }
                                }
                            })
                        }

                        if (conceptButtonsOn) {
                            $scope.selectedFacets.forEach(function(sf){
                                    if (term.name == sf){
                                        alreadyPushed = true;
                                    }
                            })
                            if (alreadyPushed == false){
                                $scope.selectedFacets.push(term.name);
                            }
                        }
                    })


                    var alreadySelected = false;
                    $scope.selectedFacets.forEach(function(sf){
                        if (sf == 'All Terms') {
                            alreadySelected = true;
                        }
                    })
                    if (alreadySelected == false) {
                        $scope.selectedFacets.push("All Terms")
                    }
                }


// Dates
                    $scope.selectedFacets.forEach(function(sf) {
                        if (sf == "All Dates") {
                            var index = $scope.selectedFacets.indexOf(sf);
                            if (index > -1) {
                                $scope.selectedFacets.splice(index, 1);
                            }
                        }
                    })
                    $scope.dates.forEach(function(date){
                        if (!date.selected) {
                            $scope.selectedFacets.forEach(function(sf){
                                if (sf == date.name){
                                    var index = $scope.selectedFacets.indexOf(sf);
                                    if (index > -1) {
                                        $scope.selectedFacets.splice(index, 1);
                                    }
                                }
                            })
                        }
                        if (date.selected) {
                            var resultYear = $scope.getResultYear(frs.date);
                            if (!date.range || includes(date.range, (resultYear))) {
                                frs.dateReady = true;
                            }
                            else {
                                frs.dateReady = false;
                            }
                            var alreadySelected = false;
                            $scope.selectedFacets.forEach(function(sf){
                                if (sf == date.name) {
                                    alreadySelected = true;
                                }
                            })
                            if (alreadySelected == false) {
                                $scope.selectedFacets.push(date.name)
                            }
                        }
                    })

// Assertions
                    if (allAssertions != true) {
                        $scope.selectedFacets.forEach(function(sf) {
                        if (sf == "All Assertions") {
                            var index = $scope.selectedFacets.indexOf(sf);
                            if (index > -1) {
                                $scope.selectedFacets.splice(index, 1);
                            }
                        }
                    })
                    var assertionCounter = 0;
                    var assertionCounter2 = 0;
                    frs.assertionReady = false;
                    $scope.assertions.forEach(function(assertion){
                        if (!assertion.selected) {
                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == assertion.name) {
                                    var index = $scope.selectedFacets.indexOf(sf);
                                    if (index > -1) {
                                        $scope.selectedFacets.splice(index, 1);
                                    }
                                }
                            })
                        }

                        if (assertion.selected) {
                            var assertionProperty = assertion.name.toLowerCase();
                            if(frs[assertionProperty]){
                                assertionCounter++;
                            }
                            var alreadySelected = false;
                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == assertion.name) {
                                    alreadySelected = true;
                                }
                            })
                            if (!alreadySelected) {
                                $scope.selectedFacets.push(assertion.name)
                            }
                        }

                    })
                     if (assertionCounter > 0){
                        frs.assertionReady = true;
                        }
                }

                if (allAssertions) {
                    $scope.assertions.forEach(function(assertion){
                        $scope.selectedFacets.forEach(function(sf){
                            if (sf == assertion.name){
                                var index = $scope.selectedFacets.indexOf(sf);
                                if (index > -1) {
                                    $scope.selectedFacets.splice(index, 1);
                                }
                            }
                        })
                    })
                    var alreadySelected = false;
                    $scope.selectedFacets.forEach(function(sf){
                        if (sf == 'All Assertions') {
                            alreadySelected = true;
                        }
                    })
                    if (alreadySelected == false) {
                        $scope.selectedFacets.push("All Assertions")
                    }
                }

//Bluebooks
                    if (allBluebooks != true) {
                    $scope.selectedFacets.forEach(function(sf) {
                        if (sf == "All Bluebooks") {
                            var index = $scope.selectedFacets.indexOf(sf);
                            if (index > -1) {
                                $scope.selectedFacets.splice(index, 1);
                            }
                        }
                    })
                    var matchCounter = 0;
                    $scope.bluebooks.forEach(function(bluebook){
                        if (!bluebook.selected && frs.bluebookLocations) {
                            frs.bluebookLocations.forEach(function(bluebookLocation) {
                                if (bluebook.name == bluebookLocation.toString()) {
                                    matchCounter++;
                                }
                            })

                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == bluebook.name) {
                                    var index = $scope.selectedFacets.indexOf(sf);
                                    if (index > -1) {
                                        $scope.selectedFacets.splice(index, 1);
                                    }
                                }
                            })
                        }
                        if (bluebook.selected) {
                            var alreadySelected = false;
                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == bluebook.name) {
                                    alreadySelected = true;
                                }
                            })
                            if (!alreadySelected) {
                                $scope.selectedFacets.push(bluebook.name)
                            }
                        }
                    })


                    if(frs.bluebookLocations && matchCounter == frs.bluebookLocations.length) {
                        frs.bluebookReady = false;
                    }
                    if(!frs.bluebookLocations){
                        frs.bluebookReady = false;
                    }

                }

                if (allBluebooks) {
                    $scope.bluebooks.forEach(function(bluebook){
                        $scope.selectedFacets.forEach(function(sf){
                            if (sf == bluebook.name){
                                var index = $scope.selectedFacets.indexOf(sf);
                                if (index > -1) {
                                    $scope.selectedFacets.splice(index, 1);
                                }
                            }
                        })
                    })
                    var alreadySelected = false;
                    $scope.selectedFacets.forEach(function(sf){
                        if (sf == 'All Bluebooks') {
                            alreadySelected = true;
                        }
                    })
                    if (alreadySelected == false) {
                        $scope.selectedFacets.push("All Bluebooks")
                    }
                }

//Body Systems
                    if (allBodysystems != true) {
                    $scope.selectedFacets.forEach(function(sf) {
                        if (sf == "All Body Systems") {
                            var index = $scope.selectedFacets.indexOf(sf);
                            if (index > -1) {
                                $scope.selectedFacets.splice(index, 1);
                            }
                        }
                    })
                    var frsTaken = false;
                   $scope.bodysystems.forEach(function(bodysystem){

                        if (!bodysystem.selected) {
                            if (frs.bluebookLocations) {
                                frs.bluebookLocations.forEach(function(bluebookLocation){
                                    if (bluebookLocation.bodySystem == bodysystem.name && frsTaken == false) {
                                        frs.bodysystemReady = false;
                                    }
                                })
                             }
                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == bodysystem.name) {
                                    var index = $scope.selectedFacets.indexOf(sf);
                                    if (index > -1) {
                                        $scope.selectedFacets.splice(index, 1);
                                    }
                                }
                            })
                            
                           
                        }
                        if (bodysystem.selected) {
                            if (frs.bluebookLocations){
                                frs.bluebookLocations.forEach(function(bluebookLocation){
                                    if (bluebookLocation.bodySystem == bodysystem.name) {
                                        frs.bodysystemReady = true;
                                        frsTaken = true;
                                    }
                                })
                            }
                            if (!frs.bluebookLocations){
                                frs.bodysystemReady = false;
                            }
                            var alreadySelected = false;
                            $scope.selectedFacets.forEach(function(sf) {
                                if (sf == bodysystem.name) {
                                    alreadySelected = true;
                                }
                            })
                            if (!alreadySelected) {
                                $scope.selectedFacets.push(bodysystem.name)
                            }
                        }
                    })
                }

                if (allBodysystems) {
                    $scope.bodysystems.forEach(function(bodysystem){
                        $scope.selectedFacets.forEach(function(sf){
                            if (sf == bodysystem.name){
                                var index = $scope.selectedFacets.indexOf(sf);
                                if (index > -1) {
                                    $scope.selectedFacets.splice(index, 1);
                                }
                            }
                        })
                    })
                    var alreadySelected = false;
                    $scope.selectedFacets.forEach(function(sf){
                        if (sf == 'All Body Systems') {
                            alreadySelected = true;
                        }
                    })
                    if (alreadySelected == false) {
                        $scope.selectedFacets.push("All Body Systems")
                    }
                }

                })
                tempFacet = "";
                $scope.closeAll();




                //Adjust facet options
                $scope.documents.forEach(function(document){
                    document.shown = true;
                })
                $scope.terms.forEach(function(term){
                    term.shown = true;
                })
                $scope.assertions.forEach(function(assertion){
                    assertion.shown = true;
                })
                $scope.bluebooks.forEach(function(bluebook){
                    bluebook.shown = true;
                })
                $scope.bodysystems.forEach(function(bodysystem){
                    bodysystem.shown = true;
                })
                var documentStashT = [];
                var documentStashL = [];
                var documentStashBB = [];
                var documentStashBS = [];
                var documentStashDate = [];
                var termStashD = [];
                var termStashL = [];
                var termStashBB = [];
                var termStashBS = [];
                var termStashDate = [];
                var assertionStashD = [];
                var assertionStashC = [];
                var assertionStashBB = [];
                var assertionStashBS = [];
                var bluebookStashD = [];
                var bluebookStashC = [];
                var bluebookStashL = [];
                var bluebookStashBS = [];
                var bodysystemStashD = [];
                var bodysystemStashC = [];
                var bodysystemStashL = [];
                var bodysystemStashBB = [];
                var bodysystemStashDate = [];


                //Stash the safe facets from being hidden
               filteredResultsStash.forEach(function(fr){
                    if (fr.docReady){
                        $scope.terms.forEach(function(term){
                            if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase())) {
                                termStashD.push(term.name);
                            }
                        })
                        $scope.assertions.forEach(function(assertion){
                            var assertionProperty = assertion.name.toLowerCase();
                            if (fr[assertionProperty]) {
                                assertionStashD.push(assertion.name);
                            }
                        })
                        $scope.bluebooks.forEach(function(bluebook){
                            if (fr.bluebooklocations && includes(fr.bluebookLocations, bluebook.name)) {
                                bluebookStashD.push(bluebook.name)
                            }
                        })
                        $scope.bodysystems.forEach(function(bodysystem){
                            if (fr.bluebookLocations){
                                fr.bluebookLocations.forEach(function(bluebookLocation){
                                    if (bluebookLocation.bodySystem == bodysystem.name) {
                                        bodysystemStashD.push(bodysystem.name)
                                    }
                                })
                            }
                        })
                    }

                    if (fr.termReady) {
                        $scope.terms.forEach(function(term){
                            if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase())) {
                                $scope.documents.forEach(function(document){
                                    if (document.documentId == fr.documentId){
                                        documentStashT.push(document.name);
                                    }
                                })
                                $scope.assertions.forEach(function(assertion){
                                    var assertionProperty = assertion.name.toLowerCase();
                                    if (fr[assertionProperty]) {
                                        assertionStashC.push(assertion.name);
                                    }
                                })
                                $scope.bluebooks.forEach(function(bluebook){
                                    if(fr.bluebookLocations){
                                        fr.bluebookLocations.forEach(function(bluebookLocation){
                                            if (bluebookLocation.bodySystem == bodysystem.name) {
                                                bodysystemStashC.push(bodysystem.name)
                                            }
                                        })
                                    }
                                })
                                $scope.bodysystems.forEach(function(bodysystem){
                                    if(fr.bluebookLocations){
                                        fr.bluebookLocations.forEach(function(bluebookLocation){
                                            if (bluebookLocation.bodySystem == bodysystem.name) {
                                                bodysystemStashC.push(bodysystem.name)
                                            }
                                        })
                                    }
                                })
                            }
                        })
                    }


                    if (fr.assertionReady){
                        $scope.assertions.forEach(function(assertion){
                            var assertionProperty = assertion.name.toLowerCase();
                            if (fr[assertionProperty]) {
                                $scope.documents.forEach(function(document){
                                    if (document.documentId == fr.documentId){
                                        documentStashL.push(document.name);
                                    }
                                })
                                $scope.terms.forEach(function(term){
                                    if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase())) {
                                        termStashL.push(term.name)
                                    }
                                })
                                $scope.bluebooks.forEach(function(bluebook){
                                        if (includes(fr.bluebookLocations && fr.bluebookLocations, bluebook.name)) {
                                        bluebookStashL.push(bluebook.name)
                                    }
                                })
                                $scope.bodysystems.forEach(function(bodysystem){
                                    if (fr.bluebookLocations){
                                        fr.bluebookLocations.forEach(function(bluebookLocation){
                                            if (bluebookLocation.bodySystem == bodysystem.name) {
                                                bodysystemStashL.push(bodysystem.name)
                                            }
                                        })
                                    }
                                })
                            }
                        })
                    }

                     if (fr.bluebookReady){
                        $scope.bluebooks.forEach(function(bluebook){
                            if (fr.bluebookLocations && includes(fr.bluebookLocations, bluebook.name)) {
                                $scope.documents.forEach(function(document){
                                    if (document.documentId == fr.documentId){
                                        documentStashBB.push(document.name);
                                    }
                                })
                                $scope.terms.forEach(function(term){
                                    if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase())) {
                                        termStashBB.push(term.name);
                                    }
                                })
                                $scope.assertions.forEach(function(assertion){
                                    var assertionProperty = assertion.name.toLowerCase();
                                    if (fr[assertionProperty]) {
                                        assertionStashBB.push(assertion.name);
                                    }
                                })
                                $scope.bodysystems.forEach(function(bodysystem){
                                    if (fr.bluebookLocations){
                                        fr.bluebookLocations.forEach(function(bluebookLocation){
                                            if (bluebookLocation.bodySystem == bodysystem.name) {
                                                bodysystemStashBB.push(bodysystem.name)
                                            }
                                        })
                                    }
                                })
                            }
                        })
                    }

                    if (fr.dateReady){
                        $scope.dates.forEach(function(date){
                            if (date.selected){
                                var resultYear = $scope.getResultYear(fr.date);

                                $scope.terms.forEach(function(term){
                                    if (includes(date.range, resultYear)){
                                        if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase())) {
                                            termStashDate.push(term.name)
                                        }
                                    }
                                })
                                $scope.documents.forEach(function(document){
                                    if (includes(date.range, resultYear)){
                                        if (document.documentId == fr.documentId){
                                            documentStashDate.push(document.name);
                                        }
                                    }
                                })
                                $scope.bodysystems.forEach(function(bodysystem){
                                    if (includes(date.range, resultYear)){
                                        if(fr.bluebookLocations){
                                            fr.bluebookLocations.forEach(function(bluebookLocation){
                                                if (bluebookLocation.bodySystem == bodysystem.name) {
                                                    bodysystemStashDate.push(bodysystem.name)
                                                }
                                            })
                                        }
                                    }
                                })
                            }
                        })
                    }

                    if (fr.bodysystemReady){
                        if (fr.bluebookLocations){
                            fr.bluebookLocations.forEach(function(bluebookLocation){
                                $scope.bodysystems.forEach(function(bodysystem){
                                    if (bluebookLocation.bodySystem == bodysystem.name) {
                                        $scope.documents.forEach(function(document){
                                            if (document.documentId == fr.documentId){
                                                documentStashBS.push(document.name);
                                            }
                                        })
                                        $scope.terms.forEach(function(term){
                                            if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase())) {
                                                termStashBS.push(term.name)
                                            }
                                        })
                                        $scope.assertions.forEach(function(assertion){
                                            var assertionProperty = assertion.name.toLowerCase();
                                            if (fr[assertionProperty]) {
                                                assertionStashBS.push(assertion.name);
                                            }
                                        })
                                        $scope.bluebooks.forEach(function(bluebook){
                                            if (fr.bluebookLocations && includes(fr.bluebookLocations, bluebook.name)) {
                                                bluebookStashBS.push(bluebook.name)
                                            }
                                        })
                                    }
                                })
                            })
                        }
                    }
               })


               //Update Facet Lists
               filteredResultsStash.forEach(function(fr){
                    if(!fr.docReady){
                        $scope.terms.forEach(function(term){
                            if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase()) && !includes(termStashD, term.name)) {
                                term.shown = false;
                            }
                        });
                        $scope.assertions.forEach(function(assertion){
                            var assertionProperty = assertion.name.toLowerCase();
                            if (fr[assertionProperty] && !includes(assertionStashD, assertion.name)) {
                                assertion.shown = false;
                            }
                        })
                        $scope.bluebooks.forEach(function(bluebook){
                            if (fr.bluebookLocations && includes(fr.bluebookLocations, bluebook.name) && !includes(bluebookStashD, bluebook.name)) {
                                bluebook.shown = false;
                            }
                        })
                        $scope.bodysystems.forEach(function(bodysystem){
                            if(fr.bluebookLocations){
                                fr.bluebookLocations.forEach(function(bluebookLocation){
                                if (bluebookLocation.bodySystem == bodysystem.name && !includes(bodysystemStashD, bodysystem.name)) {
                                        bodysystem.shown = false;
                                    }
                                })
                            }
                        })
                    }

                    if (!fr.termReady){
                        $scope.terms.forEach(function(term){
                            if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase())) {
                                $scope.documents.forEach(function(document){
                                    if (fr.documentId == document.documentId && !includes(documentStashT,document.name)){
                                        document.shown = false;
                                    }
                                })
                                $scope.assertions.forEach(function(assertion){
                                    var assertionProperty = assertion.name.toLowerCase();
                                    if (fr[assertionProperty] && !includes(assertionStashC, assertion.name)) {
                                        assertion.shown = false;
                                    }
                                })
                                $scope.bluebooks.forEach(function(bluebook){
                                    if (fr.bluebookLocations &&  includes(fr.bluebookLocations, bluebook.name) && !includes(bluebookStashC, bluebook.name)) {
                                        bluebook.shown = false;
                                    }
                                })
                                $scope.bodysystems.forEach(function(bodysystem){
                                    if(fr.bluebookLocations){
                                        fr.bluebookLocations.forEach(function(bluebookLocation){
                                            if (bluebookLocation.bodySystem == bodysystem.name && !includes(bodysystemStashC, bodysystem.name)) {
                                                bodysystem.shown = false;
                                            }
                                        })
                                    }
                                })
                            }
                        })
                    }

                    if(!fr.dateReady){
                        $scope.dates.forEach(function(date){
                            if (date.selected && date.range) {
                                var resultYear = $scope.getResultYear(fr.date);
                                if (!includes(date.range, resultYear)){
                                    $scope.documents.forEach(function(document){
                                        if (fr.documentId == document.documentId && !includes(documentStashDate, document.name)){
                                            document.shown = false;
                                        }
                                    })
                                    $scope.terms.forEach(function(term){
                                        if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase()) && !includes(termStashDate, term.name)) {
                                            term.shown = false;
                                        }
                                    })
                                    $scope.assertions.forEach(function(assertion){
                                        var assertionProperty = assertion.name.toLowerCase();
                                        if (fr[assertionProperty]) {
                                            assertion.shown = false;
                                        }
                                    })
                                    $scope.bluebooks.forEach(function(bluebook){
                                        if (fr.bluebookLocations &&  includes(fr.bluebookLocations, bluebook.name)) {
                                            bluebook.shown = false;
                                        }
                                    })
                                    $scope.bodysystems.forEach(function(bodysystem){
                                        if(fr.bluebookLocations){
                                            fr.bluebookLocations.forEach(function(bluebookLocation){
                                                if (bluebookLocation.bodySystem == bodysystem.name && !includes(bodysystemStashDate, bodysystem.name)) {
                                                    bodysystem.shown = false;
                                                }
                                            })
                                        }
                                    })
                                }
                            }
                            if (date.selected && !date.range) {
                                $scope.documents.forEach(function(document){
                                    document.shown = false;
                                })
                                $scope.terms.forEach(function(term){
                                    term.shown = false;
                                })
                                $scope.assertions.forEach(function(assertion){
                                    assertion.shown = false;
                                })
                                $scope.bluebooks.forEach(function(bluebook){
                                    bluebook.shown = false;
                                })
                                $scope.bodysystems.forEach(function(bodysystem){
                                    bodysystem.shown = false;
                                })
                            }
                        })
                    }

                    if (!fr.assertionReady){
                        $scope.assertions.forEach(function(assertion){
                            var assertionProperty = assertion.name.toLowerCase();
                            if (fr[assertionProperty]) {
                                $scope.documents.forEach(function(document){
                                    if (fr.documentId == document.documentId && !includes(documentStashL, document.name)){
                                        document.shown = false;
                                    }
                                })
                                $scope.terms.forEach(function(term){
                                    if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase()) && !includes(termStashL, term.name)) {
                                        term.shown = false;
                                    }
                                })
                                $scope.bluebooks.forEach(function(bluebook){
                                    if (fr.bluebookLocations && includes(fr.bluebookLocations, bluebook.name) && !includes(bluebookStashL,bluebook.name)) {
                                        bluebook.shown = false;
                                    }
                                })
                                $scope.bodysystems.forEach(function(bodysystem){
                                    if(fr.bluebookLocations){
                                        fr.bluebookLocations.forEach(function(bluebookLocation){
                                            if (bluebookLocation.bodySystem == bodysystem.name && !includes(bodysystemStashL, bodysystem.name)) {
                                                bodysystem.shown = false;
                                            }
                                        })
                                    }
                                })
                            }

                            if (!fr[assertionProperty]){
                                $scope.documents.forEach(function(document){
                                    if (document.documentId == fr.documentId && !includes(documentStashL, document.name)){
                                        document.shown = false;
                                    }
                                })
                                $scope.terms.forEach(function(term){
                                    if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase()) && !includes(termStashL, term.name)) {
                                        term.shown = false;
                                    }
                                })
                                $scope.bluebooks.forEach(function(bluebook){
                                    if (fr.bluebookLocations &&  includes(fr.bluebookLocations, bluebook.name) && !includes(bluebookStashL, bluebook.name)) {
                                        bluebook.shown = false;
                                    }
                                })
                                $scope.bodysystems.forEach(function(bodysystem){
                                    if(fr.bluebookLocations){
                                        fr.bluebookLocations.forEach(function(bluebookLocation){
                                            if (bluebookLocation.bodySystem == bodysystem.name && !includes(bodysystemStashL, bodysystem.name)) {
                                                bodysystem.shown = false;
                                            }
                                        })
                                    }
                                })
                            }
                        })
                    }

                     if (!fr.bluebookReady){
                        $scope.bluebooks.forEach(function(bluebook){
                            if (fr.bluebookLocations && includes(fr.bluebookLocations, bluebook.name)) {
                                $scope.documents.forEach(function(document){
                                    if (fr.documentId == document.documentId && !includes(documentStashBB,document.name)){
                                        document.shown = false;
                                    }
                                })
                                $scope.terms.forEach(function(term){
                                    if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase()) && !includes(termStashBB, term.name)) {
                                        term.shown = false;
                                    }
                                })
                                $scope.assertions.forEach(function(assertion){
                                    var assertionProperty = assertion.name.toLowerCase();
                                    if (fr[assertionProperty] && !includes(assertionStashBB, assertion.name)) {
                                        assertion.shown = false;
                                    }
                                })
                                $scope.bodysystems.forEach(function(bodysystem){
                                    if(fr.bluebookLocations){
                                        fr.bluebookLocations.forEach(function(bluebookLocation){
                                            if (bluebookLocation.bodySystem == bodysystem.name && !includes(bodysystemStashBB, bodysystem.name)) {
                                                bodysystem.shown = false;
                                            }
                                        })
                                    }
                                })
                            }
                        })
                    }

                    if (!fr.bodysystemReady){
                        $scope.bodysystems.forEach(function(bodysystem){
                            if (fr.bluebookLocations){
                                fr.bluebookLocations.forEach(function(bluebookLocation){
                                    if (bluebookLocation.bodySystem == bodysystem.name) {
                                        $scope.documents.forEach(function(document){
                                            if (fr.documentId == document.documentId && !includes(documentStashBS, document.name)){
                                                document.shown = false;
                                            }
                                        })
                                        $scope.terms.forEach(function(term){
                                        if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase()) && !includes(termStashBS, term.name)) {
                                                term.shown = false;
                                            }
                                        })
                                        $scope.assertions.forEach(function(assertion){
                                            var assertionProperty = assertion.name.toLowerCase();
                                            if (fr[assertionProperty] && !includes(assertionStashBS, assertion.name)) {
                                                assertion.shown = false;
                                            }
                                        })
                                        $scope.bluebooks.forEach(function(bluebook){
                                            if (fr.bluebookLocations && includes(fr.bluebookLocations, bluebook.name) && !includes(bluebookStashBS, bluebook.name)) {
                                                bluebook.shown = false;
                                            }
                                        })
                                    }
                                })
                            }
                            if (!fr.bluebookLocations){
                                $scope.documents.forEach(function(document){
                                    if (fr.documentId == document.documentId && !includes(documentStashBS, document.name)){
                                        document.shown = false;
                                    }
                                })
                                $scope.terms.forEach(function(term){
                                if (includes(fr.concepts[0].displayName.toLowerCase().trim(), term.name.toLowerCase()) && !includes(termStashBS, term.name)) {
                                    term.shown = false;
                                }
                                })
                                $scope.assertions.forEach(function(assertion){
                                    var assertionProperty = assertion.name.toLowerCase();
                                    if (fr[assertionProperty] && !includes(assertionStashBS, assertion.name)) {
                                        assertion.shown = false;
                                    }
                               })
                            }
                            
                        })
                    }

                })

                $scope.titleTerms.forEach(function(titleterm){
                    titleterm.shown = false;
                })

                $scope.terms.forEach(function(term){
                    if (term.selected && term.name != 'All Terms'){
                        $scope.titleTerms.forEach(function(titleterm){
                            if (term.name == titleterm.name){
                                titleterm.shown = true;
                            }
                        })
                    }
                    if (term.selected && term.name == 'All Terms')
                        $scope.titleTerms.forEach(function(titleterm){
                                titleterm.shown = true;
                        })
                })

                if (allTerms){
                    $scope.titleTerms.forEach(function(titleTerm){
                        titleTerm.shown = true;
                    })
                }


            $scope.resultsLengthFunction();

            if (conceptButtonsOn) {
                if(allTerms){
                    $scope.terms.forEach(function(term){
                        term.selected = false;
                    })
                }
            }

            }



            $scope.showAll();

            $scope.closeModal = function() {
                tempFacet = "";
                $scope.closeAll();
            }


            $scope.showFacets = function(facet) {
                $scope.closeAll();
                if (facet != tempFacet) {
                    if (facet == 'Document') {
                        $scope.showDocumentFacet = true;
                    }
                    if (facet == 'Synonym') {
                        $scope.showSynonymFacet = true;
                    }
                    if (facet == 'Term') {
                        $scope.showTermFacet = true;
                    }
                    if (facet == 'Date') {
                        $scope.showDateFacet = true;
                    }
                    if (facet == 'Saved') {
                        $scope.showSavedFacet = true;
                    }
                    if (facet == 'Assertion') {
                        $scope.showAssertionFacet = true;
                    }
                    if (facet == 'BlueBook') {
                        $scope.showBlueBookFacet = true;
                    }
                    if (facet == 'BodySystem') {
                        $scope.showBodySystemFacet = true;
                    }
                }
                if (facet == tempFacet) {
                    tempFacet = "";
                } else {
                    tempFacet = facet
                };

            }



            $scope.removeTerm = function(evt) {
                var str = $(event.target)[0].innerHTML;
                var buttonLabel = str.substring(2);
                var removeFlag = false;
                var stillGoing = false;

                if (conceptButtonsOn) {
                    var termClicked = false;
                    if (allTerms){
                        $scope.terms.forEach(function(term){
                            if (buttonLabel == term.name){
                                termClicked = true;
                            }
                        })
                        if (termClicked){
                            $scope.terms.forEach(function(term){
                                term.selected = true;
                            })
                        }
                    }
                }

                allDocuments = false;
                allTerms = false;
                allDates = false;
                allAssertions = false;
                allBluebooks = false;
                allBodysystems = false;
                // if (!$scope.allFacetsButton(str)) {
                //     removeFlag = true;
                //     var index = $scope.selectedFacets.indexOf(buttonLabel);
                //     if (index > -1) {
                //         $scope.selectedFacets.splice(index, 1);
                //     }
                // }

                $scope.documents.forEach(function(document){
                    if (buttonLabel == document.name) {
                        document.selected = false;
                    }
                })
                stillGoing = false;
                $scope.documents.forEach(function(document){
                    if (document.selected == true){
                        stillGoing = true;
                    }
                })
                if (stillGoing == false){
                    allDocuments = true;
                }

                $scope.terms.forEach(function(term) {
                    if (buttonLabel == term.name) {
                        term.selected = false;
                    }
                })
                stillGoing = false;
                $scope.terms.forEach(function(term){
                    if (term.selected == true){
                        stillGoing = true;
                    }
                })

                if (stillGoing == false){
                    allTerms = true;
                }


                var dateReset = false;
                $scope.dates.forEach(function(date){
                    if(buttonLabel == date.name) {
                        date.selected = false;
                        dateReset = true;
                    }
                })
                if (dateReset) {
                    $scope.dates.forEach(function(date){
                        if(date.name == 'All Dates') {
                            date.selected = true;
                            $scope.selectedFacets.push("All Dates");
                        }
                    })
                }

                $scope.assertions.forEach(function(assertion) {
                    if (buttonLabel.toString() == assertion.name.toString()) {
                        assertion.selected = false;
                    }
                })
                stillGoing = false;
                $scope.assertions.forEach(function(assertion){
                    if (assertion.selected == true){
                        stillGoing = true;
                    }
                })
                if (stillGoing == false){
                    allAssertions = true;
                }

                $scope.bluebooks.forEach(function(bluebook) {
                    if (buttonLabel.toString() == bluebook.name.toString()) {
                        bluebook.selected = false;
                    }
                })
                stillGoing = false;
                $scope.bluebooks.forEach(function(bluebook){
                    if (bluebook.selected == true){
                        stillGoing = true;
                    }
                })
                if (stillGoing == false){
                    allBluebooks = true;
                }

                $scope.bodysystems.forEach(function(bodysystem) {
                    if (buttonLabel.toString() == bodysystem.name.toString()) {
                        bodysystem.selected = false;
                    }
                })
                stillGoing = false;
                $scope.bodysystems.forEach(function(bodysystem){
                    if (bodysystem.selected == true){
                        stillGoing = true;
                    }
                })
                if (stillGoing == false){
                    allBodysystems = true;
                }

                if (conceptButtonsOn) {
                    if(allTerms){
                        $scope.terms.forEach(function(term){
                            term.selected = false;
                        })
                    }
                }

                $scope.applyFilters();



                if (removeFlag){
                    $(evt.currentTarget).remove()
                }
            }

            if ($routeParams.searchTerm) {
                $scope.searchTerm = $routeParams.searchTerm

                $http.get($('#virtualPath').val() + "/search-results", {
                    params: {
                        term: $routeParams.searchTerm
                    }
                }).then(function(resp) {

                    $scope.results = resp.data.response.docs

                    caseService.getDisabilityCaseId(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, caseId) {
                if (err) {
                    console.error(err);
                } else {
                    $scope.caseId = caseId;
                    documentService.getDocumentHeaders($scope.caseId, function(err, headers) {

                        if (err) {
                            console.error(err);
                        } else {
                            $scope.headers = headers;
                        }
                    });
                }
            });

                    $scope.results.forEach(function(result) {

                    //This part is only for our hard-coded json

                    var arr = $routeParams.searchTerm.split(",")
                    var flag;


                    $scope.filteredResults = [];
                    $scope.getSearchTitle = stateService.getState('searchTitle');
                    $scope.results.forEach(function(result) {
                        arr.forEach(function(searchWord) {
                            if (includes(result.concepts[0].displayName.toLowerCase().trim(), searchWord.toLowerCase().trim())) {
                                $scope.filteredResults.push(result);
                            }
                        })
                    })
                    arr.forEach(function(searchWord) {
                            if (includes(result.concepts[0].displayName.toLowerCase().trim(), searchWord.toLowerCase().trim())) {
                                 filteredResultsStash.push(result);
                            }
                        })
                    $scope.resultsLength = filteredResultsStash.length;

                    filteredResultsStash.forEach(function(frs){
                        frs.docReady = true;
                        frs.termReady = true;
                        frs.dateReady = true;
                        frs.assertionReady = true;
                        frs.bluebookReady = true;
                        frs.bodysystemReady = true;


                        // Build $scope.documents
                        $scope.headers.forEach(function(header) {
                            var nameCounter = 2;
                            if (header.documentId == frs.documentId) {
                                frs.documentName = header.displayName;
                                var docTaken = false;
                                var nameTaken = false;
                                $scope.documents.forEach(function(document) {
                                    if(document.documentId == header.documentId) {
                                        docTaken = true;
                                    }
                                    if(document.name == header.displayName) {
                                        nameTaken = true;
                                    }
                                })


                                if (docTaken == false){
                                    if (nameTaken == false ) {
                                        $scope.documents.push({"name":header.displayName, "documentId":header.documentId})
                                }
                                    if (nameTaken == true) {
                                        $scope.documents.push({"name":header.displayName + " (" + nameCounter + ")", "documentId":header.documentId})
                                        nameCounter++;
                                    }
                                }
                            }
                        })


                        $scope.dates.forEach(function(date){
                            if (date.name == "All Dates") {
                                date.selected = true;
                            }
                        })

                        //Build $scope.assertions

                        $scope.assertionoptions.forEach(function(assertionoption){
                            var alreadyAsserted = false;
                            var assertionProperty = assertionoption.name.toLowerCase();
                                $scope.assertions.forEach(function(assertion){
                                    if (assertion == assertionoption) {
                                        alreadyAsserted = true;
                                    }
                                })
                           if (alreadyAsserted == false && frs[assertionProperty]){
                                $scope.assertions.push(assertionoption)
                            }

                        })

                        if (frs.bluebookLocations){
                            frs.bluebookLocations.forEach(function(bluebookLocation){
                                var alreadySystemized = false;
                                $scope.bodysystems.forEach(function(bodysystem) {
                                    if (bodysystem.name == bluebookLocation.bodySystem ) {
                                        alreadySystemized = true;
                                    }
                                })
                                if (alreadySystemized == false && bluebookLocation.bodySystem.length > 0) {                        
                                    $scope.bodysystems.push({"name": bluebookLocation.bodySystem});
                                }
                            })
                        }

                        //Build $scope.bluebooks
                        if (frs.bluebookLocations){
                            frs.bluebookLocations.forEach(function(bluebookLocation){
                                 var alreadyBooked = false;
                                $scope.bluebooks1.forEach(function(bluebook) {
                                    if (bluebook == bluebookLocation) {
                                        alreadyBooked = true;
                                    }
                                })
                                if (alreadyBooked == false) {                       
                                    $scope.bluebooks1.push(bluebookLocation);
                                }
                            })
                        }
                    })


                        $scope.bluebooks1.forEach(function(bluebook) {
                            if (bluebook.length > 0) {
                                bluebook.forEach(function(bb) {
                                    var bluebookPushed = false;
                                    $scope.bluebooks.forEach(function(bbs) {
                                        if (bbs.name == bb) {
                                            bluebookPushed = true;
                                        }
                                    })
                                    if (bluebookPushed == false) {
                                        $scope.bluebooks.push({"name" : bb});
                                    }
                                })
                            }
                        })


                    for (var i = 0; i < $scope.documents.length; i++) {
                        for (var j = 0; j < $scope.documents.length; j++) {
                            if ($scope.documents[i].name == $scope.documents[j].name.substr(0, ($scope.documents[j].name.length - 4))) {
                                $scope.documents[i].name = $scope.documents[i].name + "(1)";
                            }
                        }
                    }
      })
                    $scope.documents.forEach(function(document) {
                        document.shown = true;
                    })
                    $scope.bluebooks.forEach(function(bluebook) {
                        bluebook.shown = true;
                    })
                    $scope.bodysystems.forEach(function(bodysystem) {
                        bodysystem.shown = true;
                    })
                    $scope.assertions.forEach(function(assertion) {
                        assertion.shown = true;
                    })
                    $scope.dates.forEach(function(date){
                        if (date.name == "All Records"){
                            date.selected = true;
                        }
                    })







                    $scope.getSearchSnippet();
        //            $scope.applyFilters();

                }, function(err) {
                    console.log(err);
                });


            }





            $scope.searchterms = [];

            if ($scope.searchTerm) {
                $scope.searchterms.push($scope.searchTerm)
                $scope.terms1 = $scope.searchterms[0].split(",");
                $scope.terms1.forEach(function(term) {
                    $scope.terms.push({
                        "name": term.trim()
                    });
                    $scope.titleTerms.push({
                        "name": term.trim()
                    });
                })
                $scope.terms.forEach(function(term) {
                    term.shown = true;
                    if (conceptButtonsOn) {
                   $scope.selectedFacets.push(term.name)
                    }
                });
                $scope.titleTerms.forEach(function(titleterm){
                    titleterm.shown = true;
                })
            }
            $scope.savedSearches = [];

            $scope.addterm = function() {
                if ($scope.term && $scope.term.trim().length) {
                    $scope.searchterms.push($scope.term);
                    $scope.term = "";
                }
            };

            $scope.runSearch = function(val) {
                $location.path("searchResults/" + val)
            };

            $scope.clearSearch = function() {
                $scope.searchterms = [];
            };

            $scope.editSavedSearch = function(name) {
                alert("This would open an editor to modify this saved search (may be unnecessary)");
            };

            $scope.deleteSavedSearch = function(name) {
                alert("This would verify the user wanted to delete this saved search and then delete it.");
            };

            $scope.saveSearch = function() {
                alert("This would prompt for a search name, then save the search for the user.");
            };

            $scope.openSavedSearch = function(name) {
                for (var i = 0; i < $scope.savedSearches.length; i++) {
                    if ($scope.savedSearches[i].name == name) {
                        $scope.searchterms = $scope.savedSearches[i].terms;
                        break;
                    }
                }
            };

            $scope.selected = undefined;
            $scope.getSearchTerms = function(val) {
                return $http.get($('#virtualPath').val() + "/search", {
                    params: {
                        term: val
                    }
                }).then(function(resp) {
                    return resp.data;
                }, function(err) {
                    console.log(err);
                });
            }

            $(document).keyup(function(e) {
                if (e.which == 27) {
                    $(".close").click();
                }
                // if (e.which == 13) {
                //     $(".applyButton").click();
                // }
            });

            $scope.searchtitlefunction = function() {
                if (stateService.getState('searchTitle')) {
                    return stateService.getState('searchTitle');
                }
                else {
                    var returnString = ""
                    for (var i=0; i <$scope.titleTerms.length; i++) {
                        if ($scope.titleTerms[i].shown == true){
                            if (i != $scope.titleTerms.length - 1){
                                returnString += $scope.titleTerms[i].name + ","
                            }
                            if ( i == $scope.titleTerms.length - 1){
                                if ($scope.titleTerms.length == 1) {
                                    returnString += $scope.titleTerms[i].name;
                                }
                                if ($scope.titleTerms.length > 1){
                                    returnString += " and" + $scope.titleTerms[i].name
                                }
                            }
                        }
                    }
                    return returnString;
                }
            }
        $scope.searchtitle = $scope.searchtitlefunction();


        $scope.resultsLengthFunction();


        $scope.showDocuments = function(){
            var facetShown = false;
            $scope.documents.forEach(function(document){
                if (document.shown == true){
                    facetShown = true;
                }
            })
            if (facetShown == false){
                return false;
            }
            else {
                return true;
            }
        }

        $scope.showTerms = function(){
            var facetShown = false;
            $scope.terms.forEach(function(term){
                if (term.shown == true){
                    facetShown = true;
                }
            })
            if (facetShown == false){
                return false;
            }
            else {
                return true;
            }
        }

        $scope.showAssertions = function(){
            var facetShown = false;
            $scope.assertions.forEach(function(assertion){
                if (assertion.shown == true){
                    facetShown = true;
                }
            })
            if (facetShown == false){
                return false;
            }
            else {
                return true;
            }
        }

        $scope.showBodysystems = function(){
            var facetShown = false;
            $scope.bodysystems.forEach(function(bodysystem){
                if (bodysystem.shown == true){
                    facetShown = true;
                }
            })
            if (facetShown == false){
                return false;
            }
            else {
                return true;
            }
        }



            /***************************************************************************************
             * Grabbing the Snippet from the Document based on begin/end of returned Search Object
             **************************************************************************************/

            $scope.headers = null;
            $scope.pagingInfo = [];
            var flag;
            $scope.getSearchSnippet = function() {

                if ($scope.filteredResults){
                $scope.filteredResults.forEach(function(result) {
                    flag = false

                    caseService.getAnnotations(pageService.getFolderNumber(),pageService.getCaseNumber(), function(err, annotations){
                        if(!err){
                            $scope.annotations =annotations.filter(function(annotation){
                        return annotation.documentId === result.documentId
                    });
                        }
                        else{
                            alert("Error getting annotations.")
                        }
                    })

                    $scope.annotations.forEach(function(annotation){
                        if(result.begin === annotation.begin && result.end === annotation.end && !result.isText){
                            result.annotation = annotation
                            result.annotation.snippet.text = result.annotation.snippet.text + "..."
                            result.text = $sce.trustAsHtml(result.annotation.snippet.text)
                            flag = true;
                        }
                    })

                    if(!flag){
                    caseService.getDocument(pageService.getFolderNumber(), pageService.getCaseNumber(), result.documentId, function(err, doc) {

                        if (!err) {
                            $scope.document = doc;

                            caseService.getDocumentSections(result.documentId, pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, sections) {

                                if (err) {
                                    alert("There was a problem getting the document: " + err);
                                    console.log(err);
                                } else {
                                    $scope.sections = sections;
                                    result.text = "";
                                    $scope.sections.forEach(function(section) {
                                        result.text = result.text + section.text
                                    })
                                    temp_text_begin = result.text.substring(0, result.begin);
                                    temp_text_begin = temp_text_begin.replace(/<(?:.|\n)*?>/gm, '');
                                    temp_text_middle = '<span style="background:#ffff99;">' + result.text.substring(result.begin, result.end) + "</span>";
                                    temp_text_end = result.text.substring(result.end);
                                    temp_text_end = temp_text_end.replace(/<(?:.|\n)*?>/gm, '');
                                    result.text = temp_text_middle + temp_text_end.substring(0,150) + "..." ;
                                    result.text = $sce.trustAsHtml(result.text);
                                }
                            });
                        } else {
                            alert("There was a problem getting the document: " + err);
                            console.log(err);
                        }
                    });
                }
                flag = false;
            })
                }
            };
    }
});

            // app.directive("scroll", function($window, $route) {
            //     return function(scope, element, attrs) {
            //         angular.element($window).bind("scroll", function() {
            //             if ($route.current.activeTab == "searchResults") {
            //                 var scrollTop = $window.pageYOffset;
            //                 if (scrollTop > 125) {
            //                     $('#searchIconBar').css({
            //                         position: 'fixed',
            //                         top: '60px'
            //                     });
            //                     $('#search-panel').css({
            //                         marginLeft: '100px'
            //                     });

            //                 }
            //                 if (scrollTop < 125) {
            //                     $('#searchIconBar').css({
            //                         position: 'static',
            //                         top: '115px'
            //                     });
            //                     $('#search-panel').css({
            //                         marginLeft: '0px'
            //                     });
            //                 }
            //                 scope.$apply();
            //             };
            //         });
            //     };
            // });
