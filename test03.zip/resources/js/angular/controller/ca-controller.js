/*
app.config(function($routeProvider) {
    $routeProvider.when("/newIssue", {
        templateUrl: "newIssue"
    });
});
*/
// DO NOT RENAME THIS FILE TO CAV-CONTROLLER
// It causes issues in IIS_Node (where the application is
// being deployed)
app.controller('cavController', function($scope, $route, $http, $location, pageService, caseService,$window) {

    $scope.pageData = pageService.pageData;
    $scope.getTitle = pageService.getTitle;
    $scope.getHeader = pageService.getHeader;
    $scope.getPatientInfoHeader = pageService.getPatientInfoHeader;
    $scope.reportIss = false;
    //exposing $route so it can be used to highlight the activeTab
    $scope.$route = $route;

    $scope.issue = null;
    $scope.issueErr = null;

$scope.reportIssue = function() {
       $scope.reportIss =true;
         $scope.issueErr="";

        $scope.issue = {
            viewName: null,
            caseId: null
        };
         if ($route.current)
        {
            $scope.issue.viewName = $route.current.originalPath;

        }
        //Focus on Description text box
        setTimeout(function(){
            $('#des').focus();
        }, 40);
         // If there's a case selected, get that
        if (pageService.ensureCaseSelected())
        {
            caseService.getDisabilityCaseId(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, disabilityCaseId) {
                $scope.issue.caseId = disabilityCaseId;

            });
        }

    };

    /**
     * Closes popup dialog for reporting issue
     */
    $scope.cancel = function() {
         $scope.reportIss = false;
    };

    /**
     * Sends issue to server for saving
     */
    $scope.submitIssue = function() {

        $scope.issueErr="";

        var txtValue =  $window.document.getElementById('des').value;

        if(txtValue.length === 0) {
             $scope.issueErr = "Description cannot be empty";
             $window.document.getElementById('des').focus();
        } else {
            $http.post($('#virtualPath').val() + '/saveNewIssue', { issue: $scope.issue }).then(function(res) {
                $scope.reportIss = false;
            }, function(err) {
                $scope.issueErr = "Unable to save issue: " + err.statusText;
                $scope.reportIss = true;
            });
         }
    };

    $scope.refresh = function() {
        $route.reload();
    };

    $scope.logout = function(event) {
        if (confirm("Are you sure you wish to end this session?"))
        {
            window.location = 'logout';
        }
        else{
            event.preventDefault();
        }
    };

    $scope.mongoUp = true;

    $scope.checkMongoResponsive = function(){

        $http.post($('#virtualPath').val() + '/checkMongo').then(function(response) {
            if(response.data.status == "available"){

                //if Mongo wasn't up the last time we checked remove warning and enable app
                if(!$scope.mongoUp){
                    $scope.mongoUp = true;
                }
            } else{
                //check if Mongo was up the last time we checked, if it was display warning and disable app
                if($scope.mongoUp){
                    $scope.mongoUp = false;
                }
            }

        }, function(err) {
            console.log(err);

            //check if Mongo was up the last time we checked, if it was display warning and disable app
            if($scope.mongoUp){
                $scope.mongoUp = false;
             }
        });

    }

    /**
     * Clears side bar and header, when user selects case search from inside a disability case
     */
    $scope.caseSearchButton = function(event){
        if (confirm("Are you sure you wish to return to Case Search?")){
            window.location.reload();
        }else{
            event.preventDefault();
        }
    }; 

    $scope.checkMongoResponsive();

    setInterval($scope.checkMongoResponsive, 30000);
});
