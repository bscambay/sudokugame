app.config(function ($routeProvider) {
    $routeProvider.when("/advancedSearch", {
        templateUrl: "advancedSearch",
        controller: "advancedSearchController",
        activeTab: "advancedSearch"
    });
});

app.controller('advancedSearchController', function ($scope, $http, $location, pageService, stateService, caseService, documentService) {

    if (pageService.ensureCaseSelected()) {
        pageService.setPageTitleIcon("search");
        pageService.setPageTitle("Advanced Search");


        $scope.searchConcepts = stateService.getState('searchConcepts');
        $scope.savedSearches = [];

        $scope.concept = "";

        $scope.snippets = stateService.getState('snippets');

        $scope.openSave = false;
        $scope.justOpenedSearch = false;
        $scope.saveButtonLabel = "Save";
        var tempTitle = "";

        $scope.addConcept = function () {
            var duplicateConcept = false;
            if ($scope.concept && $scope.concept.trim().length) {
                $scope.searchConcepts.forEach(function (concept) {
                    if ($scope.concept == concept) {
                        alert("Concept already added");
                        duplicateConcept = true;
                    }
                });
                if (duplicateConcept == false) {
                    $scope.searchConcepts.push($scope.concept);
                    $scope.concept = "";
                }
            };
        }

        $scope.removeConcept = function (concept) {


            //What the heck

            console.log($scope.savedSearches)
            console.log($scope.searchConcepts)


            var index = $scope.searchConcepts.indexOf(concept)
            $scope.searchConcepts.splice(index, 1);
            if ($scope.searchConcepts.length == 0) {
                $scope.clearSearch();
            }


            console.log($scope.savedSearches)
            console.log($scope.searchConcepts)
        }


        $scope.runSearch = function (val) {
            if ($scope.searchtitle) {
                val.searchtitle = $scope.searchtitle;
            }
            stateService.setState('searchTitle', $scope.searchtitle);
            stateService.setState('searchConcepts', val);
            console.log(stateService.getState('searchConcepts'));
            $location.path("searchResults/" + stateService.getState('searchConcepts'));
        };

        $scope.clearSearch = function () {
            $scope.searchConcepts = [];
            $scope.openSave = false;
            $scope.searchtitle = "";
        };

        $scope.editSavedSearch = function (name) {
            alert("This would open an editor to modify this saved search (may be unnecessary)");
        };

        $scope.deleteSavedSearch = function (name) {
            alert("This would verify the user wanted to delete this saved search and then delete it.");
        };

        $scope.saveSearch = function () {
            if ($scope.openSave == true) {
                var tempObject = {};
                if ($scope.searchTitle != tempTitle) {
                    $scope.justOpenedSearch = false;
                }
                tempTitle = $scope.searchTitle;
                if ($scope.searchtitle) {

                    var isTaken = false;
                    tempObject.name = $scope.searchtitle;
                    tempObject.concepts = $scope.searchConcepts;
                    $scope.savedSearches.forEach(function (ss) {
                        if (ss.name == tempObject.name && $scope.justOpenedSearch == false) {
                            alert("Name already in use")
                            isTaken = true;
                        }
                        if (ss.name == tempObject.name && $scope.justOpenedSearch == true) {
                            ss = tempObject;
                        }
                    })
                    if (!isTaken && $scope.justOpenedSearch == false) {
                        $scope.savedSearches.push(tempObject)
                        $scope.justOpenedSearch = true;
                        //                $scope.clearSearch();
                    }
                }
            } else {
                $scope.openSave = true;
            }
            //   $scope.justOpenedSearch = false;
        };


        $('#criteriainput').on("keyup", function (e) {
            if (e.keyCode == 13) {
                $("#addButton").click();
                $scope.noResults = false;
            }
        });

        $('#saveinput').on("keyup", function (e) {
            if (e.keyCode == 13) {
                $("#saveButton").click();
            }
        });


        $scope.saveAs = function () {
            $scope.justOpenedSearch = false;
        }

        $scope.openSavedSearch = function (name) {
            $scope.openSave = true;
            //        $scope.saveButtonLabel = "Save As"
            //        $('#saveButton')[0].style.width="102px"

            for (var i = 0; i < $scope.savedSearches.length; i++) {
                if ($scope.savedSearches[i].name == name) {
                    $scope.searchConcepts = $scope.savedSearches[i].concepts;
                    break;
                }
            }
            $scope.searchtitle = name;
            $scope.justOpenedSearch = true;
        };

        $http.post($('#virtualPath').val() + "/getSavedSearches", {}).then(function (resp) {
            $scope.savedSearches = resp.data;
        }, function (err) {
            alert(err);
        });


        //Type Ahead Implementation
        $scope.selected = undefined;
        $scope.getSearchTerms = function (val) {
            return $http.get($('#virtualPath').val() + "/search", {
                params: {
                    term: val
                }
            }).then(function (resp) {
                return resp.data;
            }, function (err) {
                console.log(err);
            });
        }
    }
});