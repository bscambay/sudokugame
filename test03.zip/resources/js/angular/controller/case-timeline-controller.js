app.config(function($routeProvider){
    $routeProvider.when("/case-timeline", {
        templateUrl: "case-timeline",
        controller: "caseTimelineController",
        activeTab: "case-timeline"
    }).when("/case-timeline/:key",{
        templateUrl: "case-timeline",
        controller: "caseTimelineController",
        activeTab: "case-timeline"
    });
});

app.controller('caseTimelineController',  function($scope, pageService, caseService) {
 
    if (pageService.ensureCaseSelected())
    {
        pageService.setPageTitleIcon("clock-o");
        pageService.setPageTitle("Case Timeline");

        $scope.annotations = [];

        //used to get annotation types, icons, and colors
        $scope.annUtil = new AnnotationsUtil();

        $scope.expanded = true;
        $scope.newestFirst = true;

        $scope.itemList = [];
        $scope.allTimeLineItems = [];
        
        //array of annotation types - used for checkboxes
        $scope.annotationTypes = $scope.annUtil.annotationTypes;

        //Enables the retrieval of SDR Dates
        caseService.getCase(pageService.getFolderNumber(),pageService.getCaseNumber(),function(err, _case){
            if(!err){
                $scope.case= _case;
            }else{
                alert("Error getting case")
            }
        })

        $scope.updateTimeline = function(){
            timelineItems = [];
        
            for( var i = 0; i < $scope.annotations.length; i++ ) {
                var item = $scope.annotations[i];

                if(item.date != null){
                    //var value =  $scope.formatDate(item.date);
                    //value = value.split(/\//);
                   // var year = value[value.length -1];
                   // var futureYear = new Date().getFullYear()+1;                    
                    //if(year <= futureYear){
                        timelineItems.push(item);
                        item.date = $scope.formatDate(item.date);
                        item.content = item.snippet.text;
                        //If no display is available on the record, the annotation type will be displayed.
                        if(item.displayName == null){
                            item.displayName = item.type;
                        }else if(item.displayName.length < 2){
                            item.displayName = item.type;
                        }else{
                            //has a good display name, don't do anything
                        }
                      //}

                }
            }
            
            //SDR dates 
            //AOD: Alleged Onset Date
            if($scope.case.allegedOnsetDate == null){
                var AOD= {date: 'No date available',   type: 'Alleged Onset Date',  displayName: 'Alleged Onset Date',     icon: 'fa-calendar'}; 
                timelineItems.push(AOD);
            }
            else{
                var AOD = {date: $scope.case.allegedOnsetDate,   type: 'Alleged Onset Date',    displayName: 'Alleged Onset Date',     icon: 'fa-calendar'};
                AOD.date = $scope.formatDate(AOD.date);
                timelineItems.push(AOD);
            }
            //DSW: Date Stopped Working
            if($scope.case.stoppedWorkDate == null){
                var DSW = {date: 'No date available',   type: 'Date Stopped Working',  displayName: 'Date Stopped Working',     icon: 'fa-calendar'}; 
                timelineItems.push(DSW);
            }
            else{
                var DSW = {date: $scope.case.stoppedWorkDate,   type: 'Date Stopped Working',  displayName: 'Date Stopped Working',     icon: 'fa-calendar'};
                DSW.date = $scope.formatDate(DSW.date);
                timelineItems.push(DSW);
            }

            $scope.allTimeLineItems = $scope.sortByDate(timelineItems);

            //display a copy so can add/remove annotation types based on checkbox selection
            $scope.itemList = $scope.allTimeLineItems.slice(0);   
        };

        //formats date to MM/DD/YYYY
        $scope.formatDate = function(date){
            var dateBefore = new Date(date);
            return dateBefore.getMonth()+1 + "/" + dateBefore.getDate() + "/" + dateBefore.getFullYear();
        };

        //Sorts the timeline items by date (ascending) 
        $scope.sortByDateDescending = function(a,b){
                if(a.date == b.date){
                    return a.type > b.type? 1 : -1;
                }
                return new Date(b.date) - new Date(a.date);
            }
        $scope.sortByDateAscending = function(a,b){
                if(a.date == b.date){
                    return a.type > b.type? 1 : -1;
                }
                return new Date(a.date) - new Date(b.date);
            }
        //sorts the array asc/desc based on if they selected Newest First or Oldest First
        $scope.sortByDate = function(arrayOfObjectsWithDates){
            if($scope.newestFirst){
                return arrayOfObjectsWithDates.sort($scope.sortByDateDescending);
            } else {
                return arrayOfObjectsWithDates.sort($scope.sortByDateAscending);
            }
        };

        //toggles display of annotation types when checkbox is selected
        $scope.hideShowAnnotationType = function($event, annotationType){
            if($event.target.checked == true){
                //add annotation type back to itemList
                for(var i = 0; i < $scope.allTimeLineItems.length; i++){
                    var item = $scope.allTimeLineItems[i];
                    if(item.type == annotationType){
                        $scope.itemList.push(item);
                    }
                }
                $scope.sortByDate($scope.itemList);
            } else {
                //remove annotation type from itemList
                for(var i = 0; i < $scope.itemList.length; i++){
                    var item = $scope.itemList[i];
                    if(item.type == annotationType){
                        $scope.itemList.splice(i, 1);
                        i--;
                    }
                }
            }
        };

        //expands and collapses the timeline items when the Expand All and Collapse All links are clicked
        $scope.expand = function(toExpand){
            $scope.expanded = toExpand;
        };

        $scope.sortArray = function(orderByNewestFirst){
            $scope.newestFirst = orderByNewestFirst;
            $scope.sortByDate($scope.itemList);
        };
        
        caseService.getAnnotations(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, annotations) {
                if (!err)
                {
                    $scope.annotations = annotations;
                    $scope.updateTimeline();

                }
                else
                {
                    console.log(err);
                }
        });
    }
});

app.directive('sTimeline', function() {
    return {
        restrict: 'AE',
        templateUrl: 'simpleTimeline.html'
    };
});