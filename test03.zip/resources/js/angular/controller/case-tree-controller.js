app.config(function($routeProvider) {
    $routeProvider.when("/case-tree", {
        templateUrl: "caseTree",
        controller: "caseTreeController",
        activeTab: "case-tree"
    });
});

app.controller('caseTreeController', function($scope, pageService, caseService) {

    if (pageService.ensureCaseSelected())
    {
        $scope.pageData = pageService.pageData;
        pageService.setPageTitleIcon("tree");
        pageService.setPageTitle("Case Tree");

        $scope.treeOptions = {
            nodeChildren: "children",
            dirSelectable: false,
            injectClasses: {
                ul: 'a1',
                li: 'a2',
                liSelected: 'a7',
                iExpanded: 'a3',
                iCollapsed: 'a4',
                iLeaf: 'a5',
                label: 'a6',
                labelSelected: 'a8'
            }
        };

        $scope.changeTreeStructure = function() {
            alert("This would give users the ability to change the types of information displayed in the tree, " +
                "as well as the order in which the information would be placed in the tree hierarchy.  For example, " +
                "the user might want to have the tree in snippet->rule->allegation order.");
        };

        $scope.addAllegation = function() {
            $scope.treeData.push({
                text: "This is a custom allegation",
                children: [{
                    text: "This is a term associated with the custom allegation (found through a Lucene lookup)",
                    children: [{
                        text: "This is a concept associated with the term",
                        children: [{
                            text: "And this is a snippet associated with the custom allegation's term's concept",
                            children: []
                        }]
                    }]
                }, {
                    text: "This is another term associated with the custom allegation (found through a Lucene lookup)",
                    children: [{
                        text: "This is a concept associated with the term",
                        children: [{
                            text: "And this is a snippet associated with the custom allegation's term's concept",
                            children: []
                        }, {
                            text: "And this is a snippet associated with the custom allegation's term's concept",
                            children: []
                        }, {
                            text: "And this is a snippet associated with the custom allegation's term's concept",
                            children: []
                        }]
                    }]
                }]
            });
        };

        $scope.onTreeControlNodeSelected = function(node, selected) {
            console.dir(node);
        };

        $scope.treeData = [];

        caseService.getCase(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, _case) {


            if (!err) {

                // Do this to make sure the annotations are loaded
                caseService.getAnnotations(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, vas) {

                    if (!err) {
                        $scope.treeStructure = "Allegation / Term / Concept / Finding"
                        // show all annotations for this case
                        //console.log(vas);
                        $scope.allegations = Allegation.parseAllegations(_case);


                        if (!$scope.allegations || !$scope.allegations.length) {
                            $scope.allegations = [{
                                text: 'No Allegations'
                            }];
                        }

                        // Build tree data
                        var node = null;

                        for (var i = 0; i < $scope.allegations.length; i++) {
                            node = {
                                text: $scope.allegations[i].text,
                                children: []
                            }

                            if ($scope.allegations[i].terms) {
                                for (var n = 0; n < $scope.allegations[i].terms.length; n++) {
                                    node.children.push({
                                        text: $scope.allegations[i].terms[n].text,
                                        children: []
                                    });

                                    if ($scope.allegations[i].terms[n].concepts) {
                                        for (var d = 0; d < $scope.allegations[i].terms[n].concepts.length; d++) {
                                            node.children[n].children.push({
                                                text: $scope.allegations[i].terms[n].concepts[d].codeSystem + " - " + $scope.allegations[i].terms[n].concepts[d].code,
                                                children: []
                                            });

                                            try {
                                                var annotations = caseService.getAnnotationsForConcepts(
                                                    pageService.getFolderNumber(), pageService.getCaseNumber(), [$scope.allegations[i].terms[n].concepts[d]]);

                                                for (var e = 0; e < annotations.length; e++) {
                                                    if (annotations[e].snippet && annotations[e].snippet.text) {
                                                        node.children[n].children[d].children.push({
                                                            text: annotations[e].snippet.text,
                                                            children: []
                                                        });
                                                    }
                                                }
                                            } catch (e) {
                                                console.error(err);
                                            }
                                        }
                                    }
                                }
                            }

                            $scope.treeData.push(node);
                        }

                        //This gets the allegations and rules from the Case 
                        $scope.allegations = Allegation.parseAllegations(_case);
                    

                  
                        $scope.aConcepts = Allegation.getConceptsForAllegation($scope.allegation);
                        
          
                        

                        $scope.rConcepts = Rule.getConceptsForRule($scope.rule);
     


                        // find concepts for all annotations
                        findConceptsForAnnotation = function (viewerAnnotations) {
                            var annotationConcepts = [];
                            // Returns common concept objects for allegation
                            for(var i = 0; i < viewerAnnotations.length; i++) {
                                if (viewerAnnotations[i].concepts != undefined) {
                                    for (concept in viewerAnnotations[i].concepts) {
                                        annotationConcepts.push(viewerAnnotations[i].concepts[concept]);
                                    }
                                }
                                } return annotationConcepts;
                            };

                        //$scope.annConcepts = findConceptsForAnnotation(vas);
                        console.dir(findConceptsForAnnotation(vas));


                        // Call rules service
                        for (var i = 0; i < $scope.allegations.length; i++) {
                            var a = $scope.allegations[i];

                        }
                        if (!$scope.allegations || !$scope.allegations.length) {
                            $scope.allegations = [{
                                text: 'No Allegations'
                            }];
                        }
                    } else {
                        console.error(err);
                    }

                });
            }
        });
    }
});