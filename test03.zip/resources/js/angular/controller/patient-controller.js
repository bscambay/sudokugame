app.config(function($routeProvider) {
    $routeProvider.when("/patient", {
        templateUrl: "patientInfo",
        controller: "patientController",
        activeTab: "patient"
    });
});

app.controller('patientController', function($scope, $location, pageService, caseService, documentService, stateService) {

    if (pageService.ensureCaseSelected())
    {
        $scope.pageData = pageService.pageData;

        pageService.setPageTitleIcon("male");
        pageService.setPageTitle("Claimant Summary");

        // Loading variables
        $scope.loadingCase = true;
        $scope.loadingDocuments = true;
        $scope.loadingRules = true;
        $scope.loadingAllegations = true;
        $scope.loadingFindings = true;
        
        $scope.headers = [];
        $scope.annotations = [];
        $scope.allegations = [];
        $scope.rules = [];

        caseService.getCase(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, _case) {
            
            $scope.loadingCase = false;

            if (!err)
            {
                $scope.case = _case;

                // Consider moving to getCase on case service
                pageService.setFirstName($scope.case.patient.firstName);
                pageService.setLastName($scope.case.patient.lastName);
                pageService.setSSN($scope.case.patient.identifier.extension);
                if ($scope.case.ruleProcessingTime && $scope.case.ruleProcessingTime.endTime)
                {
                    pageService.setLastProcessed(
                        new Date($scope.case.ruleProcessingTime.endTime));
                }
                else
                {
                    pageService.setLastProcessed(null);
                }

                /*
                 * Load documents
                 */
                documentService.getDocumentHeaders($scope.case._id, function(err, docs) {

                    $scope.loadingDocuments = false;

                    if (!err)
                    {
                        $scope.headers = docs;
                    }
                    else
                    {
                        console.error(err);
                    }
                });

                /*
                 * Load findings
                 */
                caseService.getAnnotations(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, annotations) {

                    $scope.loadingFindings = false;

                    if (!err)
                    {
                        $scope.annotations = annotations;

                        // IMPORTANT - Need to load annotations before the following processing can take place!


                        /*
                         * Load rules
                         */
                        $scope.rules = Rule.parseRules(_case);
                        $scope.loadingRules = false;

                        var allegationsFromState = stateService.getState("allegationsWithMatchedRules");
                        if(allegationsFromState){
                            $scope.allegations = allegationsFromState;
                            $scope.loadingAllegations = false;
                        } else {

                            /*
                            * Load allegations
                            */
                            $scope.allegations = Allegation.parseAllegations(_case);
                            $scope.loadingAllegations = false;


                            if ($scope.allegations && $scope.allegations.length)
                                {    
                                    if ($scope.rules && $scope.rules.length) 
                                    {
                                                    
                                        for (var i = 0; i < $scope.allegations.length; i++) {
                                            
                                            var aa = caseService.getAnnotationsForConcepts(
                                                        pageService.getFolderNumber(), pageService.getCaseNumber(), $scope.allegations[i].getConcepts());

                                            for (var n = 0; n < $scope.rules.length; n++) {
                                                            
                                                var ra = caseService.getAnnotationsForConcepts(
                                                            pageService.getFolderNumber(), pageService.getCaseNumber(), $scope.rules[n].getConcepts());
                                                            
                                                var matches = ra.filter(function(ann) {
                                                                            for (var d = 0; d < aa.length; d++)
                                                                            {
                                                                                if (ann._id === aa[d]._id)
                                                                                {
                                                                                    return true;
                                                                                }
                                                                            }
                                                                
                                                                            return false;
                                                                        });
                                                        
                                                if (matches && matches.length)
                                                {
                                                    $scope.allegations[i].matchingRules.push($scope.rules[n]);
                                                    $scope.allegations[i].matchingRuleIndex = n;
                                                }
                                            }
                                            // end for n
                                        }
                                        // end for i
                                    }
                                    // end if rules
                                }
                                // end if allegations

                                stateService.setState('allegationsWithMatchedRules', $scope.allegations);
                        }

                    }
                    else
                    {
                        console.error(err);
                    }
                })                
            }
            // end if !err
            else
            {
                console.error(err);
                $location.path('/casesearch');
            }
        });

        /**
         * Handle document selection on the documents list.
         */
        $scope.selectDocument = function(documentId, annotationType) {

            var path = "/document";

            if (documentId)
            {
                path += "/" + documentId;
            }

            if (annotationType)
            {
                path += "/" + annotationType;
            }

            $location.path(path);
        };

        $scope.quantity = 5;

        var getMonth = function(date){
            return date.substr(5,2);
        };

        var getTextMonth = function(month){
            var months = ["", "January", "Febuary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            return months[parseInt(month)];
        }

        $('#accordion').on('hide.bs.collapse', function () {
            $('.collapseDetails').tooltip('hide').attr('data-original-title',' Expand claimant details').tooltip('show');
        });

        $('#accordion').on('show.bs.collapse', function () {
            $('.collapseDetails').tooltip('hide').attr('data-original-title',' Collapse claimant details').tooltip('show');  
        });
    }    
});