app.config(function($routeProvider) {
    $routeProvider.when("/annotations", {
        templateUrl: "snippetsPage",
        controller: "snippetPageController",
        activeTab: "annotations"
    }).when("/annotations/:key", {
        templateUrl: "snippetsPage",
        controller: "snippetPageController",
        activeTab: "annotations"
    }).when("/annotations/:key/:annotationType", {
        templateUrl: "snippetsPage",
        controller: "snippetPageController",
        activeTab: "annotations"
    }).when("/allegations", {
        templateUrl: "snippetsPage",
        controller: "snippetPageController",
		controllerAs:"ac",
        activeTab: "allegations"
    }).when("/allegation/:allegation", {
        templateUrl: "snippetsPage",
        controller: "snippetPageController",
		controllerAs:"ac",
        activeTab: "allegations"
    }).when("/rules", {
        templateUrl: "snippetsPage",
        controller: "snippetPageController",
        activeTab: "rules"
    }).when("/rule/:ruleIndex", {
        // TODO Plug in ruleIndex
        templateUrl: "snippetsPage",
        controller: "snippetPageController",
        activeTab: "rules"
    }).when("/documents", {
        templateUrl: "snippetsPage",
        controller: "snippetPageController",
        activeTab: "documents"
    }).when("/document/:documentId", {
        templateUrl: "snippetsPage",
        controller: "snippetPageController",
        activeTab: "documents"
    }).when("/document/:documentId/:annotationType", {
        templateUrl: "snippetsPage",
        controller: "snippetPageController",
        activeTab: "documents"
    });
});

app.controller('snippetPageController', function($scope, $route, $routeParams, pageService, caseService, stateService) {

    if (pageService.ensureCaseSelected())
    {

        $scope.currentPage = $route.current.activeTab;

        $scope.annotationType = $routeParams.annotationType;

        $scope.pageData = pageService.pageData;
        $scope.groupBy;
        $scope.tooltipYes = true; 

        $scope.collapsePanels = function() {
            $('.toppanel').collapse('toggle');
            $('#divider').css({marginTop: '0px'});
            $scope.tooltipYes = !$scope.tooltipYes; 
        };

        switch($route.current.activeTab){
            case "annotations":
                pageService.setPageTitleIcon("tags");
                pageService.setPageTitle ($scope.pageData.resourceTable.ANNOTATIONS);
                //$scope.snippetsTitle = stateService.getState('snippetName');
                break;
            case "allegations":
                pageService.setPageTitleIcon('hand-o-right');
                pageService.setPageTitle($scope.pageData.resourceTable.ALLEGATIONS);
                $scope.snippetsTitle = "All Snippets";
                $scope.groupBy = "allegation";
                break;
            case "rules":
                pageService.setPageTitleIcon("bolt");
                pageService.setPageTitle($scope.pageData.resourceTable.IMPAIRMENT_RULES);
                $scope.snippetsTitle = "All Snippets";
                $scope.groupBy = "ruleName";
                break;
            case "documents":
                pageService.setPageTitle($scope.pageData.resourceTable.DOCUMENTS);
                pageService.setPageTitleIcon("file-o");
                break;
            default:
                console.log("need to handle this...")
        }


        $scope.backToTop = function(){
                $('html, body').animate({ scrollTop: 0 }, 'fast');
        };

        $scope.pinTopPanel = stateService.getState('pinned');

        $scope.pinPanels = function(){
            $scope.backToTop();
            $('#toppanel').css({position: 'static', top: '115px', width: '100%', borderStyle: 'none'});
            $('#divider').css({marginTop: '0px'});

            $scope.pinTopPanel = stateService.getState('pinned');
            $scope.pinTopPanel = !$scope.pinTopPanel
            stateService.setState('pinned', $scope.pinTopPanel);
        }

        $scope.annTypes = new AnnotationsUtil().annotationTypes;
        $scope.showKey = true;

        $scope.removeBubble = function(bubble){
            $scope.removeFilterBubble = bubble;
        }
    }
});


//scroll directive
app.directive("scroll", function ($window, $route, stateService) {
	return function(scope, element, attrs) {
		angular.element($window).bind("scroll", function() {

			if (stateService.getState('pinned') != false && (["allegations", "rules", "annotations", "documents"].indexOf($route.current.activeTab) != -1)) {

				
                var scrollTop = $window.pageYOffset;
                var panelHeight = $('#toppanel')[0].clientHeight;

				if(scrollTop > 20){
					var ftop = $('#toppanel').offset().top - $window.pageYOffset;
					$('#toppanel').css({position: 'fixed', top: '50px', width: 'calc(100% - 310px)', borderStyle: 'solid', borderWidth: '0px', overflow: 'hidden', borderTopWidth: '15px', borderBottomWidth: '1px', borderColor: 'white', borderBottomColor: '#bce8f1', marginBottom: '5px'});
                    $('#divider').css({marginTop: panelHeight});
                }
				if(scrollTop < 20){
					$('#toppanel').css({position: 'static', top: '115px', width: '100%', borderStyle: 'none'});
                    $('#divider').css({marginTop: '0px'});
				}
				scope.$apply();
			};
		});
	};
});
