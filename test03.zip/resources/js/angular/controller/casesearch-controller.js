app.config(function($routeProvider) {
    $routeProvider.when("/casesearch", {
        templateUrl: "casesearch",
        controller: "casesearchController",
        activeTab: "CaseSearch"
    });
});

app.controller('casesearchController', function($scope, $http, $location, pageService, DTOptionsBuilder, stateService) {


    $scope.initial = true;

    $scope.pageData = pageService.pageData;
    
    pageService.setPageTitle('Case Search');
    pageService.setPageTitleIcon("folder");

    if ($scope.initial)
    {
        $scope.dtOptions = DTOptionsBuilder.newOptions().withOption('order', [[5, 'desc'],[0, 'asc']]);
        
    }

    $('.search-input:first').focus();

    // This is the results from search button
    $scope._scases = [];

    $scope.search = {
        firstName: "",
        lastName:"",
        ssn:'',
        folderNum:"",
        caseNum:"",
        pageSize: 250
    };

    $scope.searching = false;
    $scope.showCountWarning = false;
    

    /**
     * Clear any search values
     */
    $scope.clearSearch = function() {
        $scope.search.firstName = "";
        $scope.search.lastName = "";
        $scope.search.ssn = "";
        $scope.search.folderNum = "";
        $scope.search.caseNum = "";                
        $('.search-input:first').focus();
        $scope.initial = true;
        $scope._scases = [];
    };

    /**
     * Tests whether the search is empty.
     */
    $scope.searchIsEmpty = function() {

        for (var fld in $scope.search)
        {
            if ($scope.search[fld] && fld != 'pageSize')
            {
                return false;
            }
        }

        return true;
    };

    /**
     * This calls the server
     */
   // $scope.customSearch [];
    $scope.searchcases=function () {

        if(!$scope.searching){
            //This conditional prevents the jquery DataTable Reinitialise error.
            if($scope._scases.length>0)
            {
                $('#resultsTable').DataTable().destroy();
            }

            if ($scope.searchIsEmpty())
            {
                alert("Please enter some search criteria (first name, last name, SSN, folder or case number)");
            }
            else
            {
                $scope.initial = false;
                $scope.searching = true;

                $http.post($('#virtualPath').val() + '/searchcases', $scope.search).then(function(response) {
                    $scope.count = response.data.count;
                    $scope._scases = response.data.docs;
                    $scope.searching = false;

                    if ($scope._scases && $scope.count > $scope.search.pageSize)
                    {
                        $scope.showCountWarning = true;
                    }
                    else
                    {
                        $scope.showCountWarning = false;
                    }

                    $('.search-input:first').focus();

                }, function(err) {

                    console.log(err)
                    alert("Error! " + err.data);

                    $scope.searching = false;

                    $('.search-input:first').focus();
                });
            }
        }
       // $scope.docCount = 

    };

    /**
     * Handles case selection
     */
    $scope.onCaseSelect = function(folderNum, caseNum) {
        pageService.setFolderNumber(folderNum);
        pageService.setCaseNumber(caseNum);
        stateService.resetState();
        $location.path('/patient');
    };

    $scope.setPageSize = function(num)
    {
        $scope.search.pageSize = num;
    }

    $scope.unavailableCasePopup = function(caseStatus){
        if (caseStatus == 'Bad') {
            alert('This case is currently unable to be processed. Please call or contact...')
        }
        if (caseStatus == 'Hold') {
            alert('This case is not currently ready for processing. Please check back later.')
        }
        if (caseStatus == 'ProcessingDocument' || caseStatus == 'ProcessingRules' || caseStatus == 'ReadyForRuleProcessing') {
            alert('This case is currently processing. Please check back later.')
        }
    }

});
