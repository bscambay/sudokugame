/**
 * The Document Service is responsible for tracking information about the
 * documents associated with a case.  It handles manipulating annotations
 * for the documents, and it handles caching, reading, and summarizing
 * document information.
 */
app.factory('documentService', function ($http, caseService, pageService) {

    var cache = {};

    var annotationsToDisplay = [];

    var getAnnotationsToDisplay = function () {
        return annotationsToDisplay;
    }

    var setAnnotationsToDisplay = function(annotations) {
        annotationsToDisplay = annotations;
    }

    const ERR_PREFIX = {
        BUILD_DOCUMENT_PAGING_INFORMATION: "Cannot build Document Paging Information: ",
        GET_DOCUMENT_HEADERS: "Cannot get Document Headers: ",
        GET_DOCUMENT_PAGING_INFORMATION: "Cannot get Document Paging Information: "
    };

    /* If not already in the cache, call to the server to get the
     * document headers for the selected case.
     */
    var getDocumentHeaders = function (disabilityCaseId, callback) {

        if (disabilityCaseId) {
            var key = disabilityCaseId + '.headers';

            if (cache[key]) {
                callback(null, cache[key]);
            }
            else {
                $http.post($('#virtualPath').val() + '/getDocumentHeaders', {
                    disabilityCaseId: disabilityCaseId
                }).then(
                    function (resp) {
                        cache[key] = resp.data;
                        callback(null, resp.data);
                    },
                    function (err) {
                        callback(new Error(ERR_PREFIX.GET_DOCUMENT_HEADERS + err));
                    }
                    );
            }
        }
        else {
            callback(new Error(ERR_PREFIX + "Disability Case ID is required."));
        }
    };

    /**
     * This method builds paging information for a document by parsing
     * its sections.
     * @params sections - document secions
     * @returns pagingInfo - data needed to build docuement paging
     */
    var buildPagingInfo = function (sections) {

        var pagingInfo = {
            sections: [],
            pages: [],
            index: 1,
            fileSize: 1,
            documentId: 1,
            title: 1
        };

        if (sections) {
            // build text
            var docText = "";
            var offset = 0;
            var sectionLength = 0;
            var docAnnotations = [];
            const tagRegEx = /\<pagebreak \/\>/ig;//some documents contain a page delimiter from the docuemnt conversion
            const pageSize = 2048; // characters per page if no pagebreak tags found

            caseService.getAnnotations(pageService.getFolderNumber(), pageService.getCaseNumber(), function (err, annotations) {
                if (!err) {
                    /* loop through viewer annotations, save those found in the document
                    for ( var i = 0; i < annotations.length; i++) {
                        if(sections[0].documentId === annotations[i].documentId) {
                            docAnnotations.push(annotations[i]);
                        }
                    }*/

                    // order sections by index
                    sections.sort(function (s1, s2) {
                        return s1.index - s2.index;
                    });

                    /* Loop through document sections and combine them into the
                     * docText Object. Also add any annotations found in sections to docAnnotations, updating their begin
                     * and end to adjust for compbined text. Set the total length of all sections to sectionLength object.
                     */
                    var tempAnn;

                    for (var i = 0; i < sections.length; i++) {
                        if (sections[i].text) {
                            //loop through viewer annotations, update and add to docAnnotations
                            for (var j = 0; j < annotations.length; j++) {
                                if (sections[i]._id === annotations[j].sectionId) {
                                    tempAnn = {};
                                    for(var a in annotations[j]){
                                        tempAnn[a] = annotations[j][a];
                                    }
                                    tempAnn.begin += offset;
                                    tempAnn.end += offset;
                                    docAnnotations.push(tempAnn);
                                }
                            }
                            //add section text to docText
                            docText += sections[i].text;
                            sectionLength = sections[i].text.length;
                        }
                        else {
                            sectionLength = 0;
                        }

                        // catalog section info
                        pagingInfo.sections.push({
                            title: sections[i].title,
                            index: sections[i].index,
                            fileSize: sections[i].fileSize,
                            documentId: sections[i].documentId,
                            offset: offset,
                            length: sectionLength
                        });

                        offset += sectionLength;
                    };

                    pagingInfo.docAnnotations = docAnnotations;

                    //Calculate total number of words in the section by dividing the length by 6.
                    pagingInfo.totalWordCount = Math.ceil(docText.length / 6);

                    // catalog page breaks
                    offset = 0;

                    var hasPageBreaks = docText.search(tagRegEx) != -1;//check to see if doecument contains page break tags

                    if (hasPageBreaks) {
                        splitOnTags();
                    } else {
                        splitOnCount();
                    }
                } else {
                    console.log(ERR_PREFIX.BUILD_DOCUMENT_PAGING_INFORMATION + "error getting viewer annotations. " + "err");
                }
            });


            //If the document had page break tags, use them to split the document into pages
            function splitOnTags() {
                var pages = docText.split(tagRegEx);
                var sectionOffset = 0;
                var sectionIndex = 0;

                //Check to see if last page of document is blank and if so remove it
                var size = pages.length-1;
                if(!pages[size]){
                    pages = pages.slice(0,size);
                }

                /* Loop through eash page and build pagingInfo with data needed to show
                 * the document text in paginated format.
                 */
                for (var i = 0; i < pages.length; i++) {
                    if (offset > pagingInfo.sections[sectionIndex].length + sectionOffset) {
                        sectionOffset += pagingInfo.sections[sectionIndex].length;
                        sectionIndex++;
                    }

                    //Build pages (If section from DB has pagebreak tags)
                    pagingInfo.pages.push({
                        startPos: offset,
                        endPos: offset + pages[i].length,
                        sectionTitle: pagingInfo.sections[sectionIndex].title,
                        text: pages[i],
                        annotations: assignAnnotationsToPage(pages[i].length, offset)
                    });

                    offset += 13 + pages[i].length;
                }
            }
            /* If the document does not have page break tags, manually break the document into
             * pages based on a character count, checking for any open table or paragraph tags
             */
            function splitOnCount() {
                /*
                //first strip away head and metadata if present
                var hasHeader = docText.search("<body>") != -1;
                var cleanText = [];

                //DEAL WITH A TAGS HERE LATER!!!!!!!!!!!!!!
                if (hasHeader) {
                    var parts = docText.split("<body>");
                    cleanText = parts[1];
                } else {
                    cleanText = docText;
                }
                */
                var cleanText = docText;//tamp workaround until annotation offsets can account for stripped data
                var docSize = cleanText.length;

                //second,  split document into sections using the pageSize character count
                while (offset < docSize) {
                    var pageLength = pageSize;
                    var exitBlock = "";

                    //If the document is less that the pageSize then set the pageLength to prevent displaying empty pages
                    if (docSize < (pageSize)) {
                        pageLength = docSize;
                    }

                    //Start with a basic split based on the pageLength
                    var simpleSplitText = cleanText.substring(offset, (offset + pageLength));

                    //If table or paragraph tags are present, cound opening and closing tags in the page
                    if (simpleSplitText.match(/\<table\>/ig) != undefined) {
                        var tableOpeningCount = simpleSplitText.match(/\<table\>/ig).length;
                    }
                    if (simpleSplitText.match(/\<\/table\>/ig) != undefined) {
                        var tableClosingCount = simpleSplitText.match(/\<\/table\>/ig).length;
                    }
                    if (simpleSplitText.match(/\<p\>/ig) != undefined) {
                        var pOpeningCount = simpleSplitText.match(/\<p\>/ig).length;
                    }
                    if (simpleSplitText.match(/\<\/p\>/ig) != undefined) {
                        var pClosingCount = simpleSplitText.match(/\<\/p\>/ig).length;
                    }

                    //If not splitting in the middle of a <table> or <p> tag then go ahead with simple split
                    if ((tableOpeningCount === tableClosingCount) && (pOpeningCount === pClosingCount)) {
                        pagingInfo.pages.push({
                            startPos: offset,
                            endPos: offset + pageLength,
                            sectionTitle: pagingInfo.sections[0].title,
                            text: cleanText.substring(offset, (offset + pageLength)),
                            tableopens: tableOpeningCount,
                            tableCloses: tableClosingCount,
                            pOpens: pOpeningCount,
                            pCloses: pClosingCount,
                            annotations: assignAnnotationsToPage(pageLength, offset)
                        });
                        exitBlock = "clean text";
                        //If trying to split in the middle of a table, first find closing table tag, then split
                    } else if (tableOpeningCount != tableClosingCount) {
                        if (cleanText.indexOf("</table>", (offset + pageLength)) > 0) {
                            var endPos = cleanText.indexOf("</table>", (offset + pageLength)) + 8;
                            pageLength = endPos - offset;
                        } else {
                            var endPos = pageLength;
                        }

                        pagingInfo.pages.push({
                            startPos: offset,
                            endPos: endPos,
                            sectionTitle: pagingInfo.sections[0].title,
                            text: cleanText.substring(offset, endPos),
                            tableopens: tableOpeningCount,
                            tableCloses: tableClosingCount,
                            pOpens: pOpeningCount,
                            pCloses: pClosingCount,
                            annotations: assignAnnotationsToPage(pageLength, offset)
                        })
                        exitBlock = "break in table";
                        //If trying to split in the middle of a paragraph, first find the closing p tag, then split
                    } else if (pOpeningCount != pClosingCount) {
                        var endPos = cleanText.indexOf("</p>", (offset + pageLength)) + 4;
                        pageLength = endPos - offset;
                        pagingInfo.pages.push({
                            startPos: offset,
                            endPos: endPos,
                            sectionTitle: pagingInfo.sections[0].title,
                            text: cleanText.substring(offset, endPos),
                            tableopens: tableOpeningCount,
                            tableCloses: tableClosingCount,
                            pOpens: pOpeningCount,
                            pCloses: pClosingCount,
                            annotations: assignAnnotationsToPage(pageLength, offset)
                        })
                        exitBlock = "break in paragraph";
                        //Some other issue occurred splitting document
                    } else {
                        console.log("Some other issue occurred splitting document html for pagination!");
                        pagingInfo.pages.push({
                            startPos: offset,
                            endPos: offset + pageLength,
                            sectionTitle: pagingInfo.sections[0].title,
                            text: cleanText.substring(offset, (offset + pageLength)),
                            tableopens: tableOpeningCount,
                            tableCloses: tableClosingCount,
                            pOpens: pOpeningCount,
                            pCloses: pClosingCount,
                            annotations: assignAnnotationsToPage(pageLength, offset)
                        });
                        exitBlock = "other";
                    }
                    //console.log({"Exit Block " :  exitBlock , "Page: " : pagingInfo.pages.length , " Beginning: " : offset , " End: " : (offset+pageLength) , " Total: " : docSize, "Object " : pagingInfo.pages[pagingInfo.pages.length-1]});
                    offset += pageLength;
                }
            }

            /* Find any annotations that occur within a page,
             * update their offsets and return array.
             * @param page object
             * @param offset where page starts in doc
             * @returns array of annotations
             */
            function assignAnnotationsToPage(pageLength, offset) {

                var pageAnnotations = [];
                for (var i = 0; i < docAnnotations.length; i++) {
                    if (docAnnotations[i].begin >= offset && docAnnotations[i].end <= (offset + pageLength)) {
                        docAnnotations[i].begin -= offset;
                        docAnnotations[i].end -= offset;
                        pageAnnotations.push(docAnnotations[i]);
                    }
                }
                return pageAnnotations;
            }

            return pagingInfo;
        }
        else {
            throw new Error(ERR_PREFIX.BUILD_DOCUMENT_PAGING_INFORMATION + "Section data is required");
        }
    };

    var getDocumentPagingInformation = function (documentId, callback) {

        if (documentId) {
            var key = documentId + ".pageInfo";

            if (cache[key]) {
                callback(null, cache[key]);
            }
            else {
                var sKey = documentId + ".sections";

                if (cache[sKey]) {
                    cache[key] = buildPagingInfo(cache[sKey]);
                    callback(null, cache[key]);
                }
                else {
                    $http.post($('#virtualPath').val() + '/getSections', {
                        documentId: documentId
                    }).then(function (resp) {
                        cache[sKey] = resp.data;
                        cache[key] = buildPagingInfo(resp.data);
                        callback(undefined, cache[key]);
                    }, function (err) {
                        callback(ERR_PREFIX.GET_DOCUMENT_PAGING_INFORMATION + err);
                    });
                }


            }
        }
        else {
            callback(new Error(ERR_PREFIX.GET_DOCUMENT_PAGING_INFORMATION + "Document ID is required"));
        }
    };


    return {
        getDocumentHeaders: getDocumentHeaders,
        getDocumentPagingInformation: getDocumentPagingInformation,
        getAnnotationsToDisplay: getAnnotationsToDisplay,
        setAnnotationsToDisplay: setAnnotationsToDisplay

    };
});