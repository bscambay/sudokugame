app.factory('stateService', function() {

    var stateValues = {
        chartType: 'pie',
        groupBy: "Body System",
        data: {},
        period: "",
        snippetName: "All Snippets",
        showCheckAll: true,
        pinned: true
    };

    var setState = function(name, value){
        stateValues[name] = value;
    };

    var getState = function(name){
        if(stateValues[name] != undefined){
            return stateValues[name];
        } else{//no state was saved yet
            return null
        }
    };

    var resetState = function(){
        stateValues = {
            chartType: 'Pie',
            groupBy: "Annotation Type",
            data: {},
            period: "",
            snippetName: "All Snippets",
            showCheckAll: true,
            pinned: true
        };
    };

    return {
        setState: setState,
        getState: getState,
        resetState: resetState
    }

});

