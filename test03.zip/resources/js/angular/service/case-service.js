/**
 * Case Service provides case information to the application.
 */
app.factory('caseService', function($http) {

    const KEY_SUFFIX_DOCUMENTS = "-documents";
    const KEY_SUFFIX_ANNOTATIONS = "-annotations";
    const KEY_SUFFIX_SECTIONS = '-sections';
    const KEY_SUFFIX_ANNOTATION_DICTIONARY = "-annotations-dictionary";

    /**
     * Cache of case data that was retrieved from the server.
     */
    var cache = {};

    /**
     * Attempting to check status of a case from here before creating a key
     * @param folderNumber
     * @param caseNumber
     * @returns boolean
     */
    var checkCaseStatus = function(folderNumber, caseNumber){
        if(_case.status=="RuleProcessingComplete"){
            console.log("I'm true");
            return true;
        }else{
            console.log("I'm false");
            return false;
        }
    };

    /**
     * Returns a key for the specified folder and case number for
     * accessing the case.
     * @param folderNumber
     * @param caseNumber
     * @returns String
     */
    var createCaseKey = function(folderNumber, caseNumber) {
        return "".concat(folderNumber, "|", caseNumber);
    };

    /**
     * Returns the case for the specified folder and case number.
     * @param folderNumber
     * @param caseNumber
     * @param callback(err, case)
     */
    var getCase = function(folderNumber, caseNumber, callback) {

        var key = createCaseKey(folderNumber, caseNumber);
    //
    //    <input type="hidden" ng-model="pageData.folderNumber" ng-init="pageData.folderNumber=||folderNumber||"/>

        if (!cache[key])
        {
            $http.post( $('#virtualPath').val() + '/getCase', {
                folderNumber: folderNumber,
                caseNumber: caseNumber
            }).then(function(resp) {
                cache[key] = resp.data;
                callback(undefined, resp.data);
            }, function(err) {
                callback(err);
            });
        }
        else
        {
            callback(undefined, cache[key]);
        }
    };

    /**
     * Returns the sections for the specified document.
     * @param documentId
     * @param folderNumber
     * @param caseNumber
     * @param callback function(err, sections)
     */
    var getDocumentSections = function(documentId, folderNumber, caseNumber, callback) {

        var key = createCaseKey(folderNumber, caseNumber) + documentId + KEY_SUFFIX_SECTIONS;

        if (!cache[key])
        {
            $http.post($('#virtualPath').val() + '/getSections', {
                documentId: documentId
            }).then(function(resp) {
                cache[key] = resp.data;
                callback(undefined, resp.data);
            }, function(err) {
                callback(err);
            });
        }
        else
        {
            callback(undefined, cache[key]);
        }
    };

    /**
     * Returns the document for the specified ID.
     * @param documentId
     * @param folderNumber
     * @param caseNumber
     * @returns callback(err, document)
     */
    var getDocument = function(folderNumber, caseNumber, documentId, callback) {

        getDocuments(folderNumber, caseNumber, function(err, docs) {

            if (err)
            {
                callback(err);
            }
            else
            {
                var doc = null;

                if (docs && docs.length)
                {
                    for (var i = 0; i < docs.length; i++)
                    {
                        if (docs[i]._id == documentId)
                        {
                            doc = docs[i];
                            break;
                        }
                    }
                }

                callback(null, doc);
            }
        });
    };

    /**
     * This method downloads and caches all the documents for the specified
     * case.
     * @param folderNumber
     * @param caseNumber
     * @param callback(err, documents)
     */
    var getDocuments = function(folderNumber, caseNumber, callback) {

        var key = createCaseKey(folderNumber, caseNumber) + KEY_SUFFIX_DOCUMENTS;

        if (!cache[key])
        {
            getCase(folderNumber, caseNumber, function(err, _case) {

                if (err)
                {
                    callback(err);
                }
                else
                {
                    var caseId = _case._id;

                    $http.post($('#virtualPath').val() + '/getDocuments', {
                        disabilityCaseId: caseId
                    }).then(function(resp) {
                        cache[key] = resp.data;
                        callback(undefined, resp.data);
                    }, function(err) {
                        callback(err);
                    });
                }
            });
        }
        else
        {
            callback(undefined, cache[key]);
        }
    };

    /**
     * This method will return the current case's annotations dictionary, creating
     * it if it doesn't already exist.  This method assumes annotations have already
     * been cached.
     */
    var getConceptAnnotationDictionary = function(folderNumber, caseNumber) {

        var key = createCaseKey(folderNumber, caseNumber) + KEY_SUFFIX_ANNOTATION_DICTIONARY;

        if (!cache[key])
        {

            var aKey = createCaseKey(folderNumber, caseNumber) + KEY_SUFFIX_ANNOTATIONS;

            if (!cache[aKey])
            {
                throw new Error("Annotations have either not been fetched, or there are no annotations " +
                    "for the case.  Ensure getAnnotations was called and completed before calling this method.");
            }

            return createConceptAnnotationDictionary(folderNumber, caseNumber, cache[aKey]);
        }
        else
        {
            return cache[key];
        }
    };

    /**
     * This method will create a dictionary of annotations by concepts for fast
     * matching.
     */
    var createConceptAnnotationDictionary = function(folderNumber, caseNumber, annotations) {

        var key = createCaseKey(folderNumber, caseNumber) + KEY_SUFFIX_ANNOTATION_DICTIONARY;

        var dict = {};
        var cKey = null;
        var concept = null;

        for (var i = 0; i < annotations.length; i++)
        {
            if (annotations[i].concepts)
            {
                for (var n = 0; n < annotations[i].concepts.length; n++)
                {
                    var concept = annotations[i].concepts[n];
                    var cKey = concept.codeSystem + '|' + concept.code;

                    if (dict[cKey])
                    {
                        if (!dict[cKey].find(function(ann) { return ann._id == annotations[i]._id; }))
                        {
                            dict[cKey].push(annotations[i]);
                        }
                    }
                    else
                    {
                        dict[cKey] = [annotations[i]];
                    }
                }
            }
        }

        cache[key] = dict;

        return cache[key];
    };

    /**
     * Returns the annotations for the set of concepts.  This method assumes the
     * annotations have already been downloaded and cached for the case.
     * @param folderNumber
     * @param caseNumber
     * @param concepts
     * @returns [Array] annotations array
     */
    var getAnnotationsForConcepts = function(folderNumber, caseNumber, concepts) {

        var matches = [];
        var dict = getConceptAnnotationDictionary(folderNumber, caseNumber);
        var cKey = null;

        for (var i = 0; i < concepts.length; i++)
        {
            cKey = concepts[i].codeSystem + '|' + concepts[i].code;

            if (dict[cKey])
            {
                matches.push.apply(dict[cKey]);
            }
        }
        
        return matches;
    };

    /**
     * Returns the disability case Id for the specified folder and case number.
     */
    var getDisabilityCaseId = function(folderNumber, caseNumber, callback) {

        getCase(folderNumber, caseNumber, function(err, _case) {

            if (err)
            {
                callback(err);
            }
            else
            {
                callback(null, _case._id);
            }
        });

    };

    /**
     * This method downloads and caches all the viewer annotations for the
     * case.
     * @param folderNumber
     * @param caseNumber
     * @param callback(err, annotations)
     */
    var getAnnotations = function(folderNumber, caseNumber, callback) {

        var key = createCaseKey(folderNumber, caseNumber) + KEY_SUFFIX_ANNOTATIONS;

        if (!cache[key])
        {
            getCase(folderNumber, caseNumber, function(err, _case) {

                if (err)
                {
                    callback(err);
                }
                else
                {
                    $http.post($('#virtualPath').val() + '/getAnnotations', {
                        disabilityCaseId: _case._id
                    }).then(function(resp) {
                        cache[key] = resp.data;
                        callback(undefined, resp.data);

                    },
                    function(err) {
                        callback(err);
                    });
                }
            });
        }
        else
        {
            // TODO Add filter by document
            callback(undefined, cache[key]);
        }
    };

    var getRulesForAllegation = function(allegation) {
        //Getting concepts for allegations
         var concepts = [];

        for (var i = 0; i < allegation.terms.length; i++){
            concepts.push.apply(concepts, allegation.terms[i].concepts);
        }

        var allegationAnnotations = findAnnotationsForConcepts(allegationConcepts);

        var ruleConcepts = [];
        var ruleAnnotations = [];

        for (var i = 0; i < rules.length; i++)
        {
            ruleConcepts = findConceptsForRule(rules[i]);
            ruleAnnotations = findAnnotationsForConcepts(ruleConcepts);

            // return true if any of the ruleAnnotations are also in the allegationAnnotations
        }

        return false;
    };

    return {
        getAnnotations: getAnnotations,
        getAnnotationsForConcepts: getAnnotationsForConcepts,
        getCase: getCase,
        getDisabilityCaseId: getDisabilityCaseId,
        getDocument: getDocument,
        getDocuments: getDocuments,
        getDocumentSections: getDocumentSections,
    };
});