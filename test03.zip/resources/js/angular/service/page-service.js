/**
 * The Page Service manages shared data between controllers and
 * provides the current application state.
 */
app.factory('pageService', function($location) {

	/*
	 * Message to display in the header when no case has been loaded.
	 */
	const LOADING_MESSAGE = "CAV Loading...";
	const TITLE_MESSAGE = "Clinical Analysis Viewer";
	
	/**
	 * Default (empty) breadcrumb
	 */
	var DEFAULT_BREADCRUMB = [{
		text: "Home", href: "#", active: true
	}];
	
	/**
	 * Page state
	 */
	//this is called pageData
	var data = {
        pageTitle: "[No Page Title]",
        pageTitleIcon: "certificate",
        breadcrumbData: DEFAULT_BREADCRUMB,
		folderNumber: 0,
		caseNumber: 0,
		firstName: "",
		lastName: "",
		ssn: "",
		resourceTable: ResourceTable.en,
		lastProcessed: null,
		groupedSnippets: []
	};
		
	/**
	 * Current case folder number
	 */
	var getFolderNumber = function() {
		return data.folderNumber;
	}

	/**
	 * Current case folder number
	 */
	var setFolderNumber = function(folderNumber)
	{
		data.folderNumber = folderNumber;
	}
	
	/**
	 * Current case case number
	 */
	var getCaseNumber = function() {
		return data.caseNumber;
	}

	/**
	 * Current case case number
	 */
	var setCaseNumber = function(caseNumber)
	{
		data.caseNumber = caseNumber;
	}

	/**
	 * Current page title
	 */
	var setPageTitle = function(pageTitle) {
		data.pageTitle = pageTitle;
	};
	
	/**
	 * Current page title icon
	 */
	var setPageTitleIcon = function(pageTitleIcon) {
		data.pageTitleIcon = pageTitleIcon;
	};
	
	/**
	 * Current claimant's first name
	 */
	var getFirstName = function() {
		return StringUtil.toTitleCase(data.firstName);
	}

	/**
	 * Current claimant's first name
	 */
	var setFirstName = function(firstName) {
		data.firstName = StringUtil.toTitleCase(firstName);
	}

	/**
	 * Current claimant's last name
	 */
	var getLastName = function() {
		return StringUtil.toTitleCase(data.lastName);
	}

	/**
	 * Current claimant's last name
	 */
	var setLastName = function(lastName) {
		data.lastName = StringUtil.toTitleCase(lastName);
	}

	/**
	 * Current claimant's ssn
	 */
	var getSSN = function() {
		return data.ssn;
	}

	/**
	 * Current claimant's ssn
	 */
	var setSSN = function(ssn) {
		data.ssn = ssn;
	}

	var setLastProcessed = function(lastProcessed) {
		data.lastProcessed = lastProcessed;
	};

	/**
	 * Method to set the current breadcrumb trail
	 */
	var setBreadcrumbData = function(breadcrumbData) {
		data.breadcrumbData = breadcrumbData;
	};
	
	var getTitle = function() {

		if (getLastName() && getFirstName()) {
			return (getLastName() + ", " + getFirstName());
		} else {
			return TITLE_MESSAGE;
		}
	};

	var getPatientInfoHeader = function() {

		if (getLastName() && getFirstName()) {
			return (getFirstName() + " " + getLastName() + " - " + SSN.format(getSSN()));
		} else {
			return ("Gathering Claimant Information...");

		}
	};

	/*
	 * Checks to see if a case has been loaded. If so, return a 
	 * formatted (concatenated) string, else return the
	 * LOADING_MESSAGE constant string.
	 */
	var getHeader = function() {

		if (getLastName() && getFirstName() && getSSN()) {
			return getFirstName() + " " + getLastName() + " - " + SSN.format(getSSN());
		} else if (data.folderNumber !== 0) {
			return "Clinical Analysis Viewer";
		} else {
			return LOADING_MESSAGE;

		}
	};

	/**
	 * Ensure that a case is selected or force the user to the case search screen.
	 */
	var ensureCaseSelected = function() {
		if (!data.folderNumber || !data.caseNumber)
		{
			$location.path('/casesearch');
			return false;
		}
		else
		{
			return true;
		}
	}

	var setGroupedSnippets = function(list){
		console.log(typeof(list))
		var arr = $.map(list, function(value, index){
			return [value]
		})

		console.log(typeof(arr))

		data.groupedSnippets = arr;
	}

	var getGroupedSnippetsCount = function(list){

		data.groupedSnippets.forEach(function(group){
			list.forEach(function(item){
				if(group.key === item.text)
				{
					item.count = group.snippets.length
				}
				else if(!item.count && group.key !== item.text){
					item.count = 0;
				}
			})
		})
	}

	return {
		DEFAULT_BREADCRUMB: DEFAULT_BREADCRUMB,
		setPageTitle: setPageTitle,
		setPageTitleIcon: setPageTitleIcon,
		setBreadcrumbData: setBreadcrumbData,
		getFolderNumber: getFolderNumber,
		setFolderNumber: setFolderNumber,
		getCaseNumber: getCaseNumber,
		setCaseNumber: setCaseNumber,
		getFirstName: getFirstName,
		setFirstName: setFirstName,
		getLastName: getLastName,
		setLastName: setLastName,
		getSSN: getSSN,
		setSSN: setSSN,
		setLastProcessed: setLastProcessed,
		pageData: data,
		getTitle: getTitle,
		getHeader: getHeader,
		getPatientInfoHeader: getPatientInfoHeader,
		ensureCaseSelected: ensureCaseSelected,
		setGroupedSnippets: setGroupedSnippets,
		getGroupedSnippetsCount: getGroupedSnippetsCount
	};
});