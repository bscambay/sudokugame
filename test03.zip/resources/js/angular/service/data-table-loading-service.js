app.run(initDT);
function initDT(DTDefaultOptions) {
    DTDefaultOptions.setLoadingTemplate('<div class="loading"><img src="' + $('#virtualPath').val() + '"/images/ajax-loader.gif" width="20" height="20" /></div>');
}