app.directive('allegationsSnippetProvider', function() {
    return {
        restrict: 'E',
        templateUrl: $('#virtualPath').val() + '/allegationsSnippetProvider',
        scope: {
            snippets: "=snippets"
        },
        controller: 'allegationsSnippetProviderController',
        controllerAs: "bc"
    };
});

app.controller('allegationsSnippetProviderController', function($scope, $routeParams, $sce, $route, pageService, caseService, stateService) {

    //condition so will only affect the allegations page
    if ($route.current.activeTab == "allegations") {

        var controller = this;

        controller.matchSnippets = function(selection) {

            var timing = new Timing("matchSnippets");
    
            controller.matchingSnippets = []

            selection.forEach(function(selected) {
                if (selected.selected) {

                    controller.formattedAnnotations.forEach(function(annotation) {
                        selected.terms.forEach(function(term) {
                            term.concepts.forEach(function(term_concept) {
                                annotation.concepts.forEach(function(annotation_concept) {
                                    if (Concept.equals(term_concept, annotation_concept)) {
											annotation.allegation = selected.text;
                                        controller.matchingSnippets.push(annotation)
                                    }
                                })
                            })
                        })
                    });
                }
            });

            //This method removes snippets from the matchingSnippets that are identical (in the case that concepts point to the same annotation)
            controller.deDupe(controller.matchingSnippets);

            $scope.snippets = controller.matchingSnippets;
            
            // stateService.resetSearch()
            stateService.setState('allSnippetsToDisplay', $scope.snippets.slice(0));

            stateService.setState('allegtionSelection', selection);

            timing.display();
        };


        controller.deDupe = function(list) {

            var timing = new Timing("deDupe");

            list.sort(function(a, b) {

                if(a._id > b._id){
                    return 1;
                } else {
                    return -1;
                }
            });

            for(var i = 0; i < list.length - 1; i++){

                if(list[i]._id == list[i+1]._id){
                    //there is a duplicate - remove one
                    list.splice(i,1);
                    i--;
                }
            }

            controller.matchingSnippets = list;

            timing.display();
        }

        //Find all Allegations
        if (!$routeParams.allegations) {
            caseService.getCase(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, _case) {
                if (!err) {

                    controller.case = _case;

                    pageService.setFirstName(controller.case.patient.firstName);
                    pageService.setLastName(controller.case.patient.lastName);
                    pageService.setSSN(controller.case.patient.identifier.extension);



                } else {
                    console.log(err);
                }
                caseService.getAnnotations(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, annotations) {
                   
                    if (!err) 
                    {
                        var timing = new Timing('Match Allegations to Rules');

                        var allegationsFromState = stateService.getState("allegationsWithMatchedRules");
                        if(allegationsFromState){
                            controller.allegations = allegationsFromState;
                        }
                        else if (controller.case.caseDetails.allegations) 
                        {
                            controller.allegations = Allegation.parseAllegations(_case);

                            if (controller.allegations && controller.allegations.length) {
                                
                                $scope.rules = Rule.parseRules(_case);
                                
                                if ($scope.rules && $scope.rules.length)
                                {
                                    for (var i = 0; i < controller.allegations.length; i++)
                                    {
                                        var aa = caseService.getAnnotationsForConcepts(pageService.getFolderNumber(), pageService.getCaseNumber(),
                                        controller.allegations[i].getConcepts());
                                    
                                        for (var n = 0; n < $scope.rules.length; n++)
                                        {

                                            var ra = caseService.getAnnotationsForConcepts(pageService.getFolderNumber(), pageService.getCaseNumber(),
                                            $scope.rules[n].getConcepts());

                                        
                                            var matches = ra.filter(function(ann) {
                                                
                                                for (var d = 0; d < aa.length; d++)
                                                {
                                                    if (ann._id === aa[d]._id)
                                                    {
                                                        return true;
                                                    }
                                                }

                                                return false;
                                            });
                                        
                                            if (matches && matches.length)
                                            {
                                                controller.allegations[i].matchingRules.push($scope.rules[n])
                                                controller.allegations[i].matchingRuleIndex = n;
                                                // add the rule to the allegation
                                            }
                                        }
                                        // for n
                                    }
                                    // for i
                                }
                                // if scope rules
                            }
 
                            // if parsed allegations
                        }
                        else
                        {
                            controller.allegations = [{
                                text: 'No Allegations'
                            }];
                        }
                        // if case allegations

                        timing.display();


                        //This will add our snippets to the Allegations object we get. They are differentiated by their annotation.
                        controller.formattedAnnotations = AnnotationFormatter.formatArrayOfAnnotations(annotations, annotations);

                        var checkList = [];

                        var savedAllegationState = stateService.getState('allegtionSelection');

                        if (controller.allegations) {

                            for(var i = 0; i < controller.allegations.length; i++){

                                temp_allegation = controller.allegations[i];
                                if(savedAllegationState != null && savedAllegationState[i].selected != undefined){
                                    temp_allegation.selected = savedAllegationState[i].selected;
                                } else {
                                    temp_allegation.selected = true;
                                }

                                checkList.push(temp_allegation)

                            }
                            controller.allegations = checkList;

                            controller.matchSnippets(controller.allegations);

                            setTimeout(function(){
                                pageService.getGroupedSnippetsCount(controller.allegations);
                            }, 50)
                        }
                    } else {
                        console.log(err);
                    }
                })
            });


        }
        //Select the entire list of allegations
        controller.SelectAll = function() {

            controller.allegations.forEach(function(allegation) {
                allegation.selected = true;

            })
            controller.matchSnippets(controller.allegations)

        };

        controller.Clear = function() {
            controller.allegations.forEach(function(allegation) {
                allegation.selected = false;

            })
            controller.matchSnippets(controller.allegations)
        }


        /*******************************************************************************************
         * View Individual Allegation
         *******************************************************************************************/
        if ($routeParams.allegation) {
            var checkList = [];
            controller.allegations.forEach(function(allegation) {
				//Check to see which allegation is in the $routeparams and set it do default.
                if (allegation.text === $routeParams.allegation) {
                    allegation.selected = true;
                } else {
                    allegation.selected = false;
                }
                checkList.push(allegation)
            })
            controller.allegations = checkList
            controller.matchSnippets(checkList)
            
        }



        angular.element('document').ready(function() {
            // popover demo
            $("[data-toggle=popover]")
                .popover()

        })


    }
});