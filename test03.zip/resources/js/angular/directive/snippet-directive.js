app.directive("snippetDirective", function() {
    return {
        restrict: 'E',
        scope: {
            snippetsToDisplay: "=snippetsToDisplay",
			//filterValue: "="
			groupBy: "=groupBy"
        },
        templateUrl: $('#virtualPath').val() + '/snippetsTemplate',
        controller: 'snippetController'
    };
});

app.controller('snippetController', function($scope, $route, $routeParams, pageService, caseService, documentService) {

	if (pageService.ensureCaseSelected())
    { 
		/**
		 * Finds the header for the specified document Id
		 */
		$scope.getHeader = function(documentId) {

			if ($scope.headers && $scope.headers.length)
			{
				return $scope.headers.find(function(header) {
					return header.documentId == documentId;
				});
			}

			return null;
		};

		//for testing
		$scope.searchText = $scope.filterValue;

		// Toggle for showing info
		$scope.showInfo = false;

		$scope.toggleInfo = function(snippet) {

			if(!$scope.showInfo && snippet) {
				$scope.showInfo = true;
				var str = snippet.snippet.text.substring(snippet.snippet.offset, snippet.snippet.offset + snippet.end - snippet.begin )
				$scope.displayed_snippet = snippet
				$scope.displayed_snippet.name = str;
				$scope.displayType = new AnnotationsUtil().getText(snippet.type); 

				if(snippet.bodyPart && snippet.bodySystem)
				{
					$scope.displayed_snippet.bodyInfo = {
						bodyPart : snippet.bodyPart,
						bodySystem : snippet.bodySystem
					}
				}

			}
			else
			{
				$scope.showInfo = false;
			}
		};

		$scope.headers = [];

		/**
		 * Iterates through the collection of snippets and adds the document header
		 */
		$scope.addHeadersToSnippets = function(snippets) {

			if (snippets && snippets.length)
			{
				snippets.forEach(function(snippet, index) {
					snippet.documentHeader = $scope.getHeader(snippet.documentId);
				});
			}
		};

		//convert groupedSnippets from an object to an array so it can be limited - currently not used
		$scope.convertObjectToArray = function(obj){
			var temp = []
			for(i in obj){
				temp.push(obj[i]);
			}
			return temp;
		};

		/**
		 * Updates the groupings
		 */
		$scope.updateGroupList = function() {
			//check if there are any snippets to display
			if($scope.snippetsToDisplay != undefined){
				groupBy = $scope.groupBy;
				var indexCounter = 0;
				$scope.groupedSnippets = {};
				for(var i = 0; i < $scope.snippetsToDisplay.length; i++){
					var snip = $scope.snippetsToDisplay[i];
					if((groupBy == "year" || groupBy == "month" || groupBy == "quarter") && snip.date != undefined){
						var range = DateRange.getRangeForDate(snip.date, groupBy);
						if(!$scope.groupedSnippets[range.label]){
							//range was not yet added
							$scope.groupedSnippets[range.label] = {
								snippets: [],
								key: range.label,
								index: indexCounter++
							};
						}
						//add the snippet to the range
						$scope.groupedSnippets[range.label].snippets.push(snip);

						// snip.date = new Date(snip.date);

						// //just grouping by date for now
						// //var formattedDate = (snip.date.getMonth() + 1) + "/" + snip.date.getDate() + "/" + snip.date.getFullYear();
						// //changing to group by year for performance
						// var formattedDate = snip.date.getFullYear();

						// if(!$scope.groupedSnippets[formattedDate]){
						// 	//date was not yet added
						// 	$scope.groupedSnippets[formattedDate] = {
						// 		snippets: [],
						// 		key: formattedDate,
						// 		index: indexCounter++
						// 	};
						// }
						// //and the snippet to the correct grouping
						// $scope.groupedSnippets[formattedDate].snippets.push(snip);

					}else if(groupBy == "bodySystem"){
						//console.log($routeParams.key);
						for(var b = 0; b < snip.bodySystems.length; b++){
							if(!$scope.groupedSnippets[snip.bodySystems[b]]){
								//group doesn't exist yet - need to add it
								$scope.groupedSnippets[snip.bodySystems[b]] = {
									snippets: [], 
									key: snip.bodySystems[b],
									index: indexCounter++
								}
							}
							$scope.groupedSnippets[snip.bodySystems[b]].snippets.push(snip);
						}
					} else if(snip[groupBy] != undefined && !$scope.groupedSnippets[snip[groupBy]]){
						//if that grouping was not yet added then add it and then add the snippet to it
						$scope.groupedSnippets[snip[groupBy]] = {
							snippets : [],
							key : snip[groupBy],
							index: indexCounter++
						};
						$scope.groupedSnippets[snip[groupBy]].snippets.push(snip);
						pageService.setGroupedSnippets($scope.groupedSnippets)
					} else if(snip[groupBy] != undefined && $scope.groupedSnippets[snip[groupBy]]) {
						//if the group was already added, add the snippet to it
						$scope.groupedSnippets[snip[groupBy]].snippets.push(snip);
					} else {
						//documents to not group snippets by design
						if($route.current.activeTab != "documents"){
							//snippet has no value for the groupBy field - not sure what to do
							//console.log("Undefined value, not displaying the snippet");
							//console.log(snip);
						}
					}
				}

				if(groupBy == "type"){
					var annUtil = new AnnotationsUtil();
					for(g in $scope.groupedSnippets){
						$scope.groupedSnippets[g].key = annUtil.getText(g);
					}
				}

				//TODO - figure out what order the snippets should display in

			} else {
				//there are no snippets to display
				$scope.groupedSnippets = {};
			}

		};

		/**
		 * Load case headers 1st
		 */
		caseService.getDisabilityCaseId(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, caseId) {
			if (err)
			{
				console.error(err);
			}
			else
			{
				$scope.caseId = caseId;
				documentService.getDocumentHeaders($scope.caseId, function(err, headers) {

					if (err)
					{
						console.error(err);
					}
					else
					{
						$scope.headers = headers;
					}
				});
			}
		});


		$scope.$watch('snippetsToDisplay', function(newValue, oldValue){
			$scope.addHeadersToSnippets($scope.snippetsToDisplay);
			$scope.updateGroupList();
		})

		$scope.$watch('groupBy', function(newValue, oldValue){
			// $scope.addHeadersToSnippets($scope.snippetsToDisplay);
			$scope.updateGroupList();
		})

	}
});