app.directive('tooltip', function(){
    return {
        restrict: 'A',
        link: function(scope, element, attrs){
            element.tooltip({
                trigger:"hover",
                delay: {show: 1000, hide: 0}
            });
        }
    };
});         