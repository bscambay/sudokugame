// configure new 'compile' directive by passing a directive
// factory function. The factory function injects the '$compile'
app.directive('compile', function ($compile, documentService) {
  // directive factory creates a link function
  return function (scope, element, attrs) {
    scope.$watch(
      function (scope) {
        //scope.snippet
        // watch the 'compile' expression for changes
        return scope.$eval(attrs.compile);
      },
      function (value) {

        //if dealing with a viewer annotation
        if (value && value.snippet && value.snippet.text) {
          value = highlightSnippet(value);
        }
        //if dealing with a page
        else if (value && value.text) {
          var filteredAnnotations = documentService.getAnnotationsToDisplay();
          value = highlightDocText(value, filteredAnnotations);
        }
        else {
          // TODO: Why is there no snippet associated with this value?
          //       Should we pull the value from the section text, instead?
          value = "<b>No text available</b>";
        }

        // when the 'compile' expression changes
        // assign it into the current DOM
        element.html(value);

        // compile the new DOM and link it to the current
        // scope.
        // NOTE: we only compile .childNodes so that
        // we don't get into infinite loop compiling ourselves
        $compile(element.contents())(scope);
      }
    ,true);
  };
})

//eventually move these to annotationsUtil, rename this directive to compile directive
highlightSnippet = function (value) {
  var displayName = value.snippet.text.substring(value.snippet.offset, value.snippet.offset + value.end - value.begin)

  var annotation = {
    offset: value.snippet.offset,
    type: value.type,
    name: displayName
  }

  if (!value.snippet.offset) {
    value = value.snippet.text;
  }
  else {
    var begin_string = value.snippet.text.substring(0, value.snippet.offset)

    var annUtil = new AnnotationsUtil();
    var annType = annUtil.getAnnotationProps(value.type);
    var highlightColor = annType.color;
    var annotation = '<button type="button" class="btn btn-xs" data-original-title="Click for Details" data-placement="bottom" tooltip style="background-color: '
      + highlightColor + ';" ng-click="toggleInfo(snippet)"> ' + displayName + ' </button>';

    var end_string = value.snippet.text.substring(value.snippet.offset + value.end - value.begin)

    value = begin_string + annotation + end_string;
  }
  return value;
}

highlightDocText = function (value, filteredAnnotations) {
  var page = value;

  var annUtil = new AnnotationsUtil();

  annUtil.resetHighlights(page, filteredAnnotations);

  var pageAnnotations = page.annotations;

  /* Runs the method to combine annotations with overlapping offsets
 * until there are no longer any overlapping.
 */
  while (annUtil.checkForOverlap(pageAnnotations)) {
    pageAnnotations = annUtil.processAnnotations(pageAnnotations);
  }

  //sort the processed annotations by their end offset
  pageAnnotations.sort(function (a1, a2) {
    return a1.end - a2.end;
  });

  //after combining and sorting, reset the original object
  page.annotations = pageAnnotations;

  /* Loop through each annotation on the page, starting at the end. Add tags to highlight the
   * text containing the annotation.
   */
  for (var i = (pageAnnotations.length - 1); i >= 0; i--) {
    var annotation = pageAnnotations[i];
    var annProps = annUtil.getAnnotationProps(annotation.type);
    var originalPage = page.text;
    var tempPage = "";
    var newPage = "";


    if (annotation.hasOwnProperty("moreAnnotations")) {
      var allAnnotations = annotation.moreAnnotations;
      while (annUtil.containsMultiples(allAnnotations)) {
        allAnnotations = annUtil.getAllAnnotations(allAnnotations);
      }
      var annCount = allAnnotations.length;
      var listItems = annUtil.populateDropdown(annotation.moreAnnotations);

      //annotation.text = annUtil.buildText(annotation.moreAnnotations); => may not need this after html gets combiled to match snippet highlighting
      tempPage = originalPage.slice(0, annotation.end) + ' <span class="badge">' + annCount + '</span> <span class="caret"></span></button>'
        + '<ul class="dropdown-menu" role="menu">'
        //populate dropdown with moreAnnotations
        + listItems
        + '</ul></div>' + originalPage.slice(annotation.end, originalPage.length);
      newPage = tempPage.slice(0, annotation.begin) +
        '<div class="dropdown inlineDiv"><button class="btn btn-xs dropdown-toggle" type="button" data-toggle="dropdown" style="background-color : ' + annProps.color + ';">'
        + tempPage.slice(annotation.begin, tempPage.length);
    } else {
      tempPage = originalPage.slice(0, annotation.end) + '</button>' + originalPage.slice(annotation.end, originalPage.length);
      newPage = tempPage.slice(0, annotation.begin) +
        '<button type="button" class="btn btn-xs" data-toggle="tooltip" title="Type: ' + annProps.text + ' Display Name: ' + annotation.displayName + '" data-placement="bottom" style="background-color : '
        + annProps.color + ';" ng-click="toggleInfo(\'' + annotation._id + '\')">' + tempPage.slice(annotation.begin, tempPage.length);
    }
    page.text = newPage;
  }
  return page.text;
}
