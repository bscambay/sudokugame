app.directive('annotationLabel', function() {
    return {
        restrict: 'E',
        templateUrl:  $('#virtualPath').val() + '/annotationLabel',
        scope: {
            annotationType: "=",
            count: "="
        },
        controller: 'annotationLabelController'
    };
});


app.controller('annotationLabelController', function($scope, $element) {

    var annUtil = new AnnotationsUtil();
    $scope.icon = annUtil.getIcon($element.attr('annotationType'));
    $scope.highlightColor = annUtil.getColor($element.attr('annotationType'));
    $scope.color = annUtil.getHighlightColor($element.attr('annotationType'));

});