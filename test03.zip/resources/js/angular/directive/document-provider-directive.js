app.directive('documentProvider', function() {
    return {
        restrict: 'E',
            templateUrl:$('#virtualPath').val() + '/documentProvider',
        scope: {
            pagingInfo: "=pagingInfo",
            header: "=header",
            snippets: "=snippets",
            annotationType: "=annotationType"
        },
        controller: 'documentProviderController'
    };
});

app.controller('documentProviderController', function($scope, $routeParams, $sce, $timeout, pageService, caseService, documentService) {

    if (pageService.ensureCaseSelected())
    {
        pageService.ensureCaseSelected();

        $scope.caseId = null;
        $scope.headers = [];
        $scope.loadingDocumentList = true;
        $scope.pagingInfo = {};

        $scope.header = null;

        $scope.selectDocument = function(documentId, annotationType) {
            //console.log("selecting doc");

            $scope.annotationType = annotationType;
            if (!annotationType)
            {
                annotationType = "all";
            }

            for (var i = 0; i < $scope.headers.length; i++)
            {
                if ($scope.headers[i].documentId == documentId)
                {
                    $scope.header = $scope.headers[i];
                    break;
                }
            }

            /*
            if(!$scope.header){
                console.log($scope.header);
            }
            */

            documentService.getDocumentPagingInformation(documentId, function(err, pagingInfo) {

                if (err)
                {
                    alert(err);
                }
                else
                {
                    $scope.pagingInfo = pagingInfo;

                    //this is needed for the filtering
                    $scope.snippets = $scope.pagingInfo.docAnnotations;
                }

            });
        };


        caseService.getDisabilityCaseId(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, caseId) {
            if (err)
            {
                alert("There was a problem getting document headers: " + err);
                console.error(err);
            }
            else
            {
                $scope.caseId = caseId;
                documentService.getDocumentHeaders($scope.caseId, function(err, headers) {

                    if (err)
                    {
                        alert("There was a problem getting document headers: " + err);
                        console.error(err);
                    }
                    else
                    {
                        $scope.headers = headers;
                    }

                    $scope.loadingDocumentList = false;
                });
            }
        });

        $scope.document = null;
        $scope.sections = [];

        if ($routeParams.documentId)
        {
            $timeout(function () {$scope.selectDocument($routeParams.documentId)}, 40);
        }
    }
});