app.directive('search', function() {
    return {
        restrict: 'E',
        templateUrl:  $('#virtualPath').val() + '/sideSearch',
        scope: {
            concept: "=concept",
        },
        controller: 'sideSearchController'
    };
});


app.controller('sideSearchController', function($scope, $location, $http, stateService) {

    $scope.concept = "";

    $scope.selected = undefined;
    $scope.getSearchTerms = function(val){
        return $http.get($('#virtualPath').val() + "/search", {
            params: {
                term : val
            }
        }).then(function(resp) {
                return resp.data;
            }, function(err) {
            console.log(err);
          });
    }

    $scope.search = function(val){
        stateService.setState('searchTitle', "");
        stateService.setState('searchConcepts', [val]);
        console.log(stateService.getState('searchConcepts'));
        $location.path("searchResults/" + stateService.getState('searchConcepts'));
    }

  


});