app.directive('rulesSnippetProvider', function() {
    return {
        restrict: 'E',
            templateUrl:$('#virtualPath').val() + '/rulesSnippetProvider',
        scope: {
            snippets: "=snippets"
        },
        controller: 'rulesSnippetProviderController',
        controllerAs: 'rspc'
    };
});

app.controller('rulesSnippetProviderController', function($scope, $route, $routeParams, pageService, caseService, stateService) {

    if (pageService.ensureCaseSelected())
    {
        //condition so it will only run on the Rules page
        if($route.current.activeTab == "rules"){

            //Initialize variables
            $scope.rulesFired = [];
            $scope.rulesCount;
            $scope.rulesFiredSnippets = [];
            $scope.tempSnippets = [];
            $scope.snippetsCount;

            if($routeParams.ruleIndex){

            }

            var controller = this;

            // Deselects all rules
            controller.Clear = function (){
                $scope.rulesFired.forEach(function(ruleFired) {
                    ruleFired.selected = false;
                });
                $scope.snippets = [];
                $scope.snippetsCount = $scope.snippets.length;
            }

            // Selects all rules
            controller.SelectAll = function() {
                $scope.rulesFired.forEach(function(ruleFired) {
                    ruleFired.selected = true;
                });
                $scope.snippets = $scope.rulesFiredSnippets;
                $scope.snippetsCount = $scope.snippets.length;
            }

            // Matches rules to selected snippets
            controller.matchRule = function (){
                controller.list = [];
                $scope.rulesFired.forEach(function(selected)
                {
                    if(selected.selected){
                        $scope.rulesFired.forEach(function(ruleFired){
                            if(selected.ruleName === ruleFired.ruleName){
                                controller.list.push(ruleFired)
                            }
                        })
                        $scope.snippets = $scope.rulesFiredSnippets;
                        $scope.tempSnippets = [];

                        controller.list.forEach(function(ruleSelected) {
                            $scope.snippets.forEach(function(snippet) {
                                if (snippet != null) {
                                    if (snippet.ruleName == ruleSelected.ruleName) {
                                        $scope.tempSnippets.push(snippet);
                                    }
                                }
                            })
                        })
                            $scope.snippets = [];
                            $scope.snippets = $scope.tempSnippets;
                    }
                    $scope.snippetsCount = $scope.snippets.length;
                    if (controller.list.length == 0) {
                        $scope.snippets = [];
                    }
                });
            };




            //Lookup rules fired and partial rules by case, place in appropriate variables
            caseService.getCase(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, doc) {
                if(!err){
                    if (doc.analysisResults != undefined) {
                        $scope.rulesFired = doc.analysisResults.ruleResultsList;

            

                        if($routeParams.ruleIndex){


                            $scope.rulesFired.forEach(function(ruleFired) {
                                ruleFired.selected = false;
                            });
                            $scope.rulesFired[$routeParams.ruleIndex].selected = true;
                        } else {


                            $scope.rulesFired.forEach(function(ruleFired) {
                                //only set checkboxes to true when load page for the first time
                                if(ruleFired.selected == undefined){
                                    ruleFired.selected = true;
                                }
                            });

                        }

                        $scope.rulesCount = $scope.rulesFired.length;
                        processDoc(doc);
                    } else {
                        console.log("No results found for this case " + pageService.getCaseNumber());
                    }
                } else {
                    console.log(err);
                }

            });

            //Loop throuugh analysis results and place code snippet objects in an array
            function processDoc(doc) {
                var list = doc.analysisResults.ruleResultsList;
                list.forEach(function(item) {
                    item.impairmentGroupingLevelList.forEach(function(levelItem) {
                        levelItem.medicalEvidenceStatementList.forEach(function(statementList) {

                            //testing--------------- was set to {}
                            var snippet = statementList.additionalInfo;

                            // if(statementList.additionalInfo.sectionTitle != undefined) {
                            //     snippet.heading = statementList.additionalInfo.sectionTitle;
                            // } else {
                            //     snippet.heading = "Document Section Title not found";
                            // }
                            // if(statementList.additionalInfo.snippet != undefined) {
                            //     snippet.text = "statementList.additionalInfo.snippet.text";
                            // } else {
                            //     snippet.text = "Snippet not found.";
                            // }
                            // if (statementList.conceptDescriptor.codeSystem != undefined) {
                            // snippet.codeSystem = statementList.conceptDescriptor.codeSystem;
                            // } else {
                            //     snippet.codeSystem = "Code System not found";
                            // }
                            // if (statementList.conceptDescriptor.displayName != undefined) {
                            //     snippet.code = statementList.conceptDescriptor.displayName;
                            // } else {
                            //     snippet.code = "Code not found";
                            // }

                            // snippet.displayName = snippet.heading + " (" + snippet.code + ", " + snippet.codeSystem + ")";
                            snippet.ruleName = item.ruleName;

                            $scope.rulesFiredSnippets.push(snippet);

                        })
                    })
                });


                caseService.getAnnotations(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, annotations) {
                    if (!err)
                    {
                        $scope.snippets = AnnotationFormatter.formatArrayOfAnnotations($scope.rulesFiredSnippets, annotations);
                        $scope.snippetsCount = $scope.snippets.length;
                        console.log("Snippets after formatting");
                        console.log($scope.snippets);
                        
                    } else {
                        console.log(err);
                    }

                });
            }

            console.log("snippets from rules:");
            console.log($scope.snippets);

            if($routeParams.ruleIndex){
            $scope.rulesFired.forEach(function(rule){
                rule.selected = false;
            })
                $scope.tempSnippets = []
                $scope.snippets.forEach(function(snippet){
                    if (snippet) {
                        if ($scope.rulesFired[$routeParams.ruleIndex].ruleName == snippet.ruleName) {
                            $scope.rulesFired[$routeParams.ruleIndex].selected = true;
                            $scope.tempSnippets.push(snippet)
                            $scope.snippets = $scope.tempSnippets;
                            $scope.$emit('emitSnippets', $scope.snippets)
                    }
                    }
                })
                $scope.snippetsCount = $scope.snippets.length;
        }

        }
    }
});