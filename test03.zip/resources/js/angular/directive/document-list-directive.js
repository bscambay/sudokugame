/**
 * This directive displays medical evidence documents
 */
app.directive('documentList', function() {
    return {
        restrict: 'E',
        templateUrl:  $('#virtualPath').val() + '/documentList',
        scope: {
            headers: "=headers",
            select: '&onSelect'
        },
        controller: 'documentListController'
    };
});


app.controller('documentListController', function($scope, DTOptionsBuilder) {

    $scope.dtOptions = DTOptionsBuilder.newOptions().withDisplayLength(5).
        withOption('lengthMenu', [5, 10, 25, 50, 100]).withOption('order', [4, 'desc']);

    $scope.openDmaLink = function(dmaDocumentId, displayName) {
        dmaViewer.open(dmaDocumentId, displayName);
    };

});