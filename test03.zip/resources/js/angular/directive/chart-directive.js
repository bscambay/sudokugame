//Creates the directive for the charts
app.directive('chart', function() {
    return {
        //require: '^ngModel',
        restrict: 'E',
        transclude: true,
        templateUrl: $('#virtualPath').val() + '/chartDirective',

        controller: 'chartController',
        //scope :{}

        scope: {
            chartType: '=',
            chartData: '=',
            chartconfig: '=',
            groupByLabel: '=groupByLabel'
        }

    };
});



app.controller('chartController', function($scope, $location, $filter, $routeParams, $route, pageService, caseService, DTOptionsBuilder, stateService) {

    if (pageService.ensureCaseSelected()) {
        $scope.annUtil = new AnnotationsUtil();
        $scope.pageData = pageService.pageData;
        
        

        // ********************************* Angular chart Bubble Timeline *********************************************

        $scope.colors = [];

        const CT_YR_LABEL = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        const CT_MTH_LABEL28 = ["", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28"];
        const CT_MTH_LABEL29 = ["", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29"];
        const CT_MTH_LABEL30 = ["", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"];
        const CT_MTH_LABEL31 = ["", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
        // const CT_YR_LABEL_LINE = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        // const CT_MTH_LABEL28_LINE = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28"];
        // const CT_MTH_LABEL29_LINE = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29"];
        // const CT_MTH_LABEL30_LINE = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"];
        // const CT_MTH_LABEL31_LINE = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
        const CT_QTR_LABEL = ["", "Jan-Mar", "Apr-Jun", "Jul-Sept", "Oct-Dec"];
        const ANNOTATION_DB_NAMES = $scope.annUtil.getAnnotationTypesDBValues();

        // Get the number of days in the Month of $scope.period when Charting on Months. Note: This is not 0 based but 1 based.
        $scope.daysInMonthOfPeriod = function() {
            return new Date($scope.period.substr(0, 4),
                $scope.period.substr(5, 2), // For 1 based date months
                //$scope.period.substr(5,2)+1, // For 0 based date months
                0).getDate();
        }

        // Gets the timeline X axis labels
        $scope.getTimelineXAxisLabels = function() {
            if ($scope.chartDataSource === "Year") {
                return CT_YR_LABEL;
            }

            if ($scope.chartDataSource === "Month") {
                switch ($scope.daysInMonthOfPeriod()) {
                    case 28:
                        return CT_MTH_LABEL28;
                    case 29:
                        return CT_MTH_LABEL29;
                    case 30:
                        return CT_MTH_LABEL30;
                    case 31:
                        return CT_MTH_LABEL31;
                    default:
                        console.log("Error: Invalid months returned on Period month value");
                }
            }

             //Quarter labels should be the names of the three months in the selected quarter
        if ($scope.chartDataSource === "Quarter") {
            var splitLabel = $scope.period.split(" ");
            var quarter = splitLabel[0];
            switch (quarter) {
                case "January":
                    return ["", "January", "Febuary", "March"];
                case "April":
                    return ["", "April", "May", "June"];
                case "July":
                    return ["", "July", "August", "September"];
                case "October":
                    return ["", "October", "November", "December"];
                default:
                    console.log("invalid quarter - can't get labels");
            }
        } else return [""];
        }

        // Gets the maximum number of ticks.
        $scope.getMaxTicks = function() {
            return $scope.getTimelineXAxisLabels().length;
        }


        // Updates timeline chart data
        $scope.updateTimelineChart = function(data) {
            //r is size of bubble
            $scope.series = ['Series A', 'Series B'];

            $scope.data = data

            $scope.onClick = function(points, evt) {
                // console.log("data: ");
                // console.log(data);
                // console.log(points, evt);
                // console.log("index of data[] is: ", + points[0]._index);

/*                console.log("Month reference point is: " + data[points[0]._index].x);
                console.log("Annotation reference point is: " + data[points[0]._index].y);
                console.log("Annotation reference is: " + data[points[0]._index].y + " " + (ANNOTATION_DB_NAMES[data[points[0]._index].y - 1]));*/
                var urlSuffix = $scope.labels[data[points[0]._index].x] + "/" + (ANNOTATION_DB_NAMES[data[points[0]._index].y - 1]);
                $scope.openFindingsLink(urlSuffix);
                //$scope.openFindingsLink($scope.labels[data[points[0]._index].x] );
                $scope.$apply();
            };

            //Don't need to completely reset options each time, most will remain the same
            $scope.options = {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            min: 0,
                            max: $scope.annUtil.getAnnotationTypes().length + 1, //should be the length of the labels array
                            stepSize: 1,
                            userCallback: function(numericalTick, index, ticks) {
                                var labels = $scope.annUtil.getAnnotationTypes(); //don't hard code
                                labels.unshift("");
                                return labels[numericalTick];
                            }
                        }
                    }],
                    xAxes: [{
                        ticks: {
                            beginAtZero: true,
                            min: 0,
                            max: $scope.getMaxTicks(),
                            stepSize: 1,
                            //stepSize: getStepSize(),
                            userCallback: function(numericalTick, index, ticks) {
                                $scope.labels = $scope.getTimelineXAxisLabels();
                                return $scope.labels[numericalTick];
                            }
                        }
                    }]
                }
            };
        }

        // ********************************* END ANGULAR CHART BUBBLE TIMELINE *********************************************


        // Get the number of days in the Month of $scope.period when Charting on Months. Note: This is not 0 based but 1 based.
        $scope.daysInMonthOfPeriod = function() {

            //TODO - rewrite this function to acturately calculate the days in a given month
            // return new Date($scope.period.substr(0,4),
            //                 $scope.period.substr(5,2), // For 1 based date months
            //                 //$scope.period.substr(5,2)+1, // For 0 based date months
            //                 0).getDate();

            return 31;
        }

        // Translate data to Line chart format
        $scope.translateDataToLineChartFormat = function(data) {
            $scope.formattedData = [
                []
            ];
            for (i = 0; i < data.length; i++) {
                $scope.formattedData[0][i] = data[i].y[0];
            }
            return $scope.formattedData;
        }



    $scope.updateLineChart = function(data) {

        $scope.labels = $scope.getTimelineXAxisLabels();
        $scope.series = ['Count'];
        // $scope.data = [[10,20,30,40,50,60,70,80,90,100,110,120]]; // must be in double array format
        $scope.data = $scope.translateDataToLineChartFormat(data);

        $scope.onClick = function(points, evt) {
            // console.log(points, evt);
            // console.log("index of data is: ", + points[0]._index);
            $scope.openFindingsLink(data[(points[0]._index)].x); // Navigate via Month string
            // console.log("navigate to open findings: " + data[points[0]._index].x);

            $scope.$apply();
        };

        $scope.onHover = function(points) {
            if (points.length > 0) {
                console.log('Point', points[0].value);
            } else {
                console.log('No point');
            }
        };

        $scope.options = {
            scales: {
                yAxes: [{
                    type: 'linear',
                    display: true,
                    position: 'left'
                }]
            }
        };

    };

    // ********************************* END ANGULAR LINE CHART *********************************************

    // ********************************* ANGULAR BAR CHART **************************************************
    $scope.updateBarChart = function(data) {


        $scope.getBarXAxisLabels = function(data) {
            var labels = [];
            for (i = 0; i < data.data.length; i++) {
                labels.push(data.data[i].x);
            }
            return labels;
        }

        $scope.translateDataToBarChart = function(data) {
            var barData = [
                []
            ];
            for (i = 0; i < data.data.length; i++) {
                barData[0].push(data.data[i].y[0]);
            }
            return barData;
        }

        $scope.onClick = function(points, evt) {
            //console.log(points, evt);
            //console.log("index of data is: ", + points[0]._index);
            $scope.openFindingsLink(data.data[(points[0]._index)].x);
            $scope.$apply();
        };

        //console.log("Data being passed to bar chart: " + JSON.stringify(data));

        //$scope.labels = ['2001', '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009'];
        $scope.labels = $scope.getBarXAxisLabels(data);
        $scope.series = ['Count'];

        //$scope.data = [[1,2,3,40,5,6,17,18,9]];
        $scope.data = $scope.translateDataToBarChart(data);




        var getMaxTicksBar = function(array) {
            var maxNum = Math.max.apply(Math, array);
            return maxNum;
        }

        $scope.options = {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                        min: 0,
                        //max: getMaxTicksBar($scope.data[0])
                        //stepSize: 1,
                    }
                }]
            }

        }

    };
    // ********************************* END ANGULAR BAR CHART **********************************************

    // ********************************* ANGULAR PIE CHART **************************************************

    $scope.colors = [
        "#4AD6C2", //light blue green
        "#4DC2DD", //light blue
        "#CC5571", //pink
        "#FEC86F", //buttery yellow
        "#DF6D5D", //salmon
        "#A0436F", //fushia/plum
        "#70D7A6", //light green
        "#F59A4D", //orange
        "#89598A", //purple
        "#2C749A" //darker blue
    ]

    $scope.updatePieChart = function(data) {

        $scope.onClick = function(points, evt) {
/*            console.log(points, evt);
            console.log("index of data is: ", +points[0]._index);
            console.log("Pie Data is: " + JSON.stringify(data));
            console.log("What is this? " + data.data[(points[0]._index)].x);*/
            $scope.openFindingsLink(data.data[(points[0]._index)].x);
            $scope.$apply();
        };

        $scope.getPieLabels = function(data) {
            var labels = [];
            for (i = 0; i < data.data.length; i++) {
                labels.push(data.data[i].x);
            }
            return labels;
        }

        $scope.translateDataToPieChart = function(data) {
            var pieData = [];
            for (i = 0; i < data.data.length; i++) {
                pieData.push(data.data[i].y[0]);
            }
            return pieData;
        }

        $scope.labels = $scope.getPieLabels(data);
        $scope.data = $scope.translateDataToPieChart(data);

        $scope.options = {
            legend: {
                display: true,
                position: 'left',
                htmlEnabled: true
            },
            //cutoutPercentage: 50 //to quickly demo the donut chart
        };

    };
    // ********************************* END ANGULAR PIE CHART **********************************************

    // ********************************* ANGULAR DOUGHNUT CHART *********************************************
    $scope.colors = [
        "#4AD6C2", //light blue green
        "#4DC2DD", //light blue
        "#CC5571", //pink
        "#FEC86F", //buttery yellow
        "#DF6D5D", //salmon
        "#A0436F", //fushia/plum
        "#70D7A6", //light green
        "#F59A4D", //orange
        "#89598A", //purple
        "#2C749A" //darker blue
    ]

    $scope.updateDoughnutChart = function(data) {

        $scope.onClick = function(points, evt) {
            console.log(points, evt);
            console.log("index of data is: ", +points[0]._index);
            console.log("Doughnut Data is: " + JSON.stringify(data));
            console.log("What is this? " + data.data[(points[0]._index)].x);
            $scope.openFindingsLink(data.data[(points[0]._index)].x);
            $scope.$apply();
        };

        $scope.getDoughnutLabels = function(data) {
            var labels = [];
            for (i = 0; i < data.data.length; i++) {
                labels.push(data.data[i].x);
            }
            return labels;
        }

        $scope.translateDataToDoughnutChart = function(data) {
            var doughnutData = [];
            for (i = 0; i < data.data.length; i++) {
                doughnutData.push(data.data[i].y[0]);
            }
            return doughnutData;
        }

        $scope.labels = $scope.getDoughnutLabels(data);
        $scope.data = $scope.translateDataToDoughnutChart(data);

        $scope.options = {
            legend: {
                display: true,
                position: 'left',
                htmlEnabled: true
            }
        };

    };

    // ********************************* END ANGULAR DOUGHNUT CHART *****************************************

    // ********************************* BEGIN ANGULAR DATA TABLE *******************************************

        $scope.dtOptions = DTOptionsBuilder.newOptions().withDisplayLength(5).
            withOption('lengthMenu', [5, 10, 25, 50, 100]).withOption('order', [1, 'desc']);

    // ********************************* END ANGULAR DATA TABLE *********************************************

    // ********************************* START MAIN CHART LOGIC *********************************************

    /**
     * "Data Source" constants
     */
    const DS_BODY_SYSTEM = "Body System";
    // const DS_BODY_PART = "Body Part";
    const DS_TYPE = "Annotation Type";
    const DS_YEAR = "Year";
    const DS_MONTH = "Month";
    const DS_QUARTER = "Quarter";
    const DS_DEFAULT = DS_TYPE;

    /**
     * Chart Type constants
     */
    const CT_PIE = "Pie";
    const CT_DOUGHNUT = "Doughnut";
    const CT_BAR = "Bar";
    const CT_LINE = 'Line';
    const CT_DATA = "Data";
    const CT_TIMELINE = "Timeline";
    const CT_DEFAULT = CT_PIE;

    $scope.annotations = [];

    //Use this to formulate logic for data from Mongo
    $scope.period = stateService.getState('period');
    $scope.periods = [];

    //Populates Group By and Chart Type in Options:
    $scope.chartDataSources = [/*DS_BODY_PART,*/ DS_TYPE, DS_BODY_SYSTEM, DS_YEAR, DS_MONTH, DS_QUARTER];
    $scope.chartTypes = [CT_PIE, CT_DOUGHNUT, CT_BAR, CT_LINE, CT_DATA, CT_TIMELINE];

    $scope.chartTypeEx = stateService.getState('chartType');

    

    const CS_chartDataSourcesTypeA = [/*DS_BODY_PART,*/ DS_TYPE, DS_BODY_SYSTEM];
    const CS_chartDataSourcesTypeB = [DS_YEAR, DS_MONTH, DS_QUARTER];
    const CS_chartTypeSubTypeA = ["Pie", "Doughnut", "Bar", "Data"];
    const CS_chartTypeSubTypeB = ["Line", "Data", "Timeline"];
    const CS_chartTypeSubDefault = CS_chartTypeSubTypeA;

    $scope.chartTypesExpanded = CS_chartTypeSubDefault;

    //Sets default to Annotation Type pie chart in Options:
    $scope.chartDataSource = DS_DEFAULT;
    $scope.chartDataSource = stateService.getState('groupBy');

    $scope.chartType = CT_DEFAULT;

    // toggle for showing the chart versus showing data table
    $scope.showChart = 1;
    $scope.showPeriod = false;

    var datasource;
    var dataCamelCase;
    $scope.data = {};
    var data = [];
    $scope.snippet = {};

    // Translate selected expandedChartType to regular type chart and effectuate(ie show)
    $scope.selectChartType = function(aChartType) {
        switch (aChartType) {
            case "Pie":
                $scope.chartType = CT_PIE;
                $scope.showChart = 1;
                break;
            case "Doughnut":
                $scope.chartType = CT_DOUGHNUT;
                $scope.showChart = 6;
                break;
            case "Bar":
                $scope.chartType = CT_BAR;
                $scope.showChart = 5;
                break;
            case "Line":
                $scope.chartType = CT_LINE;
                $scope.showChart = 4;
                break;
            case "Data":
                $scope.chartType = CT_DATA;
                $scope.showChart = 2;
                break;
            case "Timeline":
                $scope.chartType = CT_TIMELINE;
                $scope.showChart = 3;
                break;
        }

    };

    $scope.displayPieAndBarAndDoughnutChart = true;
    // TODO Filter by documents?



    $scope.setFindingsChartState = function() {
        stateService.setState('groupBy', $scope.chartDataSource);
        $scope.groupByLabel = $scope.chartDataSource;
        stateService.setState('chartType', $scope.chartTypeEx);
        stateService.setState('period', $scope.period);
    }

    $scope.updateChart = function() {

        $scope.setFindingsChartState();

        datasource = $scope.chartDataSource;
        if (datasource === "Annotation Type") {
            var annotationType = datasource.split(/(\s+)/);
            dataCamelCase = annotationType[2].toLowerCase();
        } else {
            dataCamelCase = convertCamelCase(datasource);
        }

        for (var i = 0; i < $scope.annotations.length; i++) {
            ann = $scope.annotations[i];

            if (ann[dataCamelCase] != undefined) {
                data.push(ann)
            } else if (["year", "month", "quarter"].indexOf(dataCamelCase) != -1 && ann.date != undefined) {
                data.push(ann);
            } else if(dataCamelCase == "bodySystem" && ann.bodySystems != undefined && ann.bodySystems.length > 0){
                data.push(ann);
            }
        };

        stateService.setState('snippets', data);

        // Select Sublist of options available after selecting Grouping Type
        switch ($scope.chartDataSource) {
            case DS_BODY_SYSTEM:
            // case DS_BODY_PART:
            case DS_TYPE:
                $scope.chartTypesExpanded = CS_chartTypeSubTypeA;
                if (CS_chartTypeSubTypeA.indexOf($scope.chartTypeEx) < 0) {
                    $scope.chartTypeEx = CT_PIE;
                    //$scope.chartTypeEx = CT_DOUGHNUT;
                }
                $scope.showPeriod = false;
                break;
            case DS_YEAR:
            case DS_QUARTER:
            case DS_MONTH:

                $scope.chartTypesExpanded = CS_chartTypeSubTypeB;
                if (CS_chartTypeSubTypeB.indexOf($scope.chartTypeEx) < 0) {
                    $scope.chartTypeEx = CT_TIMELINE;
                }
                break;
            default:
                console.log("Why did we get here?");
        }

        // toggle and display relevant chart type
        //Thinking logic for ng-hide should go here
        $scope.selectChartType($scope.chartTypeEx);

        // Select relevant annotations based on data source
        var relevant = $scope.annotations.filter(function(value) {

            switch ($scope.chartDataSource) {
                case DS_BODY_SYSTEM:
                    $scope.displayPieAndBarAndDoughnutChart = true;
                    return value.bodySystems.length > 0;
/*                    if (value.bodySystems.length > 0) {
                        return value.bodySystem;*/

                // case DS_BODY_PART:
                //     $scope.displayPieAndBarAndDoughnutChart = true;
                //     return value.bodyPart;

                case DS_TYPE:
                    $scope.displayPieAndBarAndDoughnutChart = true;
                    return value.type;


                case DS_YEAR:
                case DS_MONTH:
                case DS_QUARTER:
                    if (value.date == null) {
                        return false;
                    } else {
                        return value.date;
                    }

                default:
                    // TODO Handle this scenario
                    console.log("We shouldn't be here.");
                    return false;
            }
        });

        // Create chart data from relevant annotations
        var cd = {
            series: [],
            data: []
        };

        // This is just an object to roll up data
        var dict = {};

        var aggregateDataPoint = function(ann, fieldName) {
            if (dict[ann[fieldName]]) {
                dict[ann[fieldName]]++;
            } else {
                dict[ann[fieldName]] = 1;
            }
        };

        // Object to roll up bodySystem data
        var bodyDict = {};

        // Creates collection for body system data
        var aggregateBodySys = function (ann) {
            for (i=0; i < ann.bodySystems.length; i++) {
                if (bodyDict[ann.bodySystems[i]]) {
                    bodyDict[ann.bodySystems[i]]++;
                } else {
                    bodyDict[ann.bodySystems[i]] = 1;
                }
            }
        };




        //Object to roll up dates
        var dateDict = {};

        //Creates collection
        var aggregateDate = function(ann) {

            if (dateDict[ann.date]) {
                if (dateDict[ann.date][ann.type]) {
                    dateDict[ann.date][ann.type]++;
                } else {
                    dateDict[ann.date][ann.type] = 1;
                }
            } else {
                dateDict[ann.date] = {};
                dateDict[ann.date][ann.type] = 1;
            }
        };


        relevant.forEach(function(ann) {

            // if ($scope.chartDataSource === DS_BODY_PART) {
            //     aggregateDataPoint(ann, "bodyPart");
            // } else
             if ($scope.chartDataSource === DS_BODY_SYSTEM) {
                //aggregateDataPoint(ann, "bodySystem");
                aggregateBodySys(ann);
            } else if ($scope.chartDataSource === DS_TYPE) {
                aggregateDataPoint(ann, "type");
            } else if ([DS_YEAR, DS_MONTH, DS_QUARTER].indexOf($scope.chartDataSource) != -1 && $scope.chartTypeEx == CT_TIMELINE) {
                aggregateDate(ann);
            } else if ([DS_YEAR, DS_MONTH, DS_QUARTER].indexOf($scope.chartDataSource) != -1) {
                aggregateDataPoint(ann, "date");
                aggregateDate(ann);
            } else {
                // TODO Handle unsupported value
            }
        });

        if (relevant.length == 0) {
            $scope.noChartData = true;
        }

        cd.series.push("");
        //roll up data into dictionary to display in chart
        if ([/*DS_BODY_PART,*/ DS_BODY_SYSTEM, DS_TYPE].indexOf($scope.chartDataSource) != -1) {
            $scope.showPeriod = false;

            if ($scope.chartDataSource == DS_BODY_SYSTEM) {
                for (var dp in bodyDict) {

                    cd.data.push({
                        x: dp,
                        y: [bodyDict[dp]],
                        tooltip: dp + ": " + [bodyDict[dp]] + " found"
                    });
                }
                console.log(cd.data);
            }


            if ($scope.chartDataSource == DS_TYPE) {
                for (var dp in dict) {

                    cd.data.push({
                        x: $scope.annUtil.getText(dp),
                        y: [dict[dp]],
                        tooltip: dp + ": " + [dict[dp]] + " found",
                        annotationType: dp
                    });
                }
            }

            //don't rollup data for data table
            if ($scope.chartTypeEx != CT_DATA) {

                //sort the data so largest value is first
                cd.data.sort(function(a, b) {
                    return b.y - a.y;
                });

                //if there are more than 10 values need to roll up data
                if (cd.data.length > 10) {
                    var other = {
                        x: "Other",
                        y: [0],
                        tooltip: "Other: "
                    };
                    var combinedInOther = [];
                    while (cd.data.length > 9) {
                        var lastElement = cd.data.pop();
                        other.y[0] += lastElement.y[0];
                        other.tooltip += " " + lastElement.x + " - " + lastElement.y;
                        combinedInOther.push(lastElement.x);
                    }
                    cd.data.push(other);
                    stateService.setState('combinedInOther', combinedInOther);
                }
            }

        } else if ([DS_YEAR, DS_MONTH, DS_QUARTER].indexOf($scope.chartDataSource) != -1) // &&  $scope.chartTypeEx == CT_TIMELINE)
        {
            var ranges = {}; //start with empty ranges
            var dt = null;
            $scope.periods = [];

            //finding date ranges based on Group By selection and what dates there is data for
            for (var dp in dateDict) {
                dt = new Date(dp);
               
                switch ($scope.chartDataSource) {
                    case DS_YEAR:
                        if (!ranges[DateRange.getNameForYear(dt)]) { //if didn't alreday have a date in that range, add the range
                            //$scope.periods.push(DateRange.getNameForYear(dt));//add the range to Periods dropdown
                            ranges[DateRange.getNameForYear(dt)] = DateRange.getRangeForYear(dt);
                        }
                        break;
                    case DS_MONTH:
                        if (!ranges[DateRange.getNameForMonth(dt)]) {
                            //$scope.periods.push(DateRange.getNameForMonth(dt));
                            ranges[DateRange.getNameForMonth(dt)] = DateRange.getRangeForMonth(dt);                        

                        }
                        break;
                    case DS_QUARTER:
                        if (!ranges[DateRange.getNameForQuarter(dt)]) {
                            // $scope.periods.push(DateRange.getNameForQuarter(dt));

                            ranges[DateRange.getNameForQuarter(dt)] = DateRange.getRangeForQuarter(dt)
                        }
                        break;
                    default:
                        console.log("Something went wrong.");
                }
            }

            //sort ranges chronologically
            var sortableRanges = [];
            for (i in ranges) {
                sortableRanges.push(ranges[i]);
            }
            sortableRanges.sort(function(a, b) {
                return b.start.getTime() - a.start.getTime();
            });

            //fill periods
           for (var i = 0; i < sortableRanges.length; i++) {
                $scope.periods.push(sortableRanges[i].label);
         }
        /*   
            var futureYear = new Date().getFullYear()+1;            
            for (var i = 0; i < sortableRanges.length; i++) {
                    var year = sortableRanges[i].label;
                    var yearTxt;
                    var idx = String(year).indexOf(' ');
                    if (idx === -1) {
                        yearTxt = year;
                        }else{                  
                            var value = year.split(/[ -]+/);
                            var lastIndex = value[value.length -1];
                                yearTxt = lastIndex;                            
                        }                 
                     if (yearTxt  <= futureYear){
                        $scope.periods.push(sortableRanges[i].label);                       
                  }
                }
          */  
            if ($scope.periods.length == 0) {
                //$scope.periods.push(' ');
                //TODO - handle if there are no dates and therefore no periods
            }
            $scope.showPeriod = true;
         
            //sort periods so they display in order with most recent on top
            //TODO - sorting is only working for Year, not for Month or Quarter
            //$scope.periods.sort(function(a,b){return b-a;});

            //if no period was selected or the selected on is not valid, default to the first one in the list
            if ($scope.period == null || $scope.periods.indexOf($scope.period) < 0) {         
                $scope.period = $scope.periods[0];               
            }

            function elementExists(array, x, y) {
                var item = null;
                for (var index in array) {
                    item = array[index];
                    if (item.x == x && item.y == y) {
                        return index;
                    }
                }
                return -1;
            };

            function elementExistsOnlyXValue(array, x) { //this is BAD
                var item = null;
                for (var index in array) {
                    item = array[index];
                    if (item.x == x) {
                        return index;
                    }
                }
                return -1;
            };

            cd.data = [];
            $scope.colors = [];
            var exists = false;
            var xValue = null;

            var selectedRange = DateRange.getRangeFromLabel($scope.chartDataSource, $scope.period);           
            if(selectedRange != undefined){
            if ($scope.chartTypeEx == CT_TIMELINE) {
                //Add points to chart data(cd)
                for (var dp in dateDict) {
                    dt = new Date(dp);
                    dataItem = dateDict[dp];

                    //is the date within the period selected
                    //if(dt >= ranges[$scope.period].start && (dt < ranges[$scope.period].end)){
                    if (DateRange.isDateWithinRange(dt, selectedRange)) {

                        //determine the xAxis placement
                        switch ($scope.chartDataSource) {
                            case DS_YEAR:
                                xValue = dt.getMonth() + 1;
                                break;
                            case DS_MONTH:
                                xValue = dt.getDate();
                                break;
                            case DS_QUARTER:
                                xValue = (dt.getMonth() + 1) - ((dt.getQuarter() - 1) * 3);
                                break;
                            default:
                                console.log("This is not giving you any info.");
                        }

                        //Add the points
                        for (var i = 0; i < ANNOTATION_DB_NAMES.length; i++) {
                            if (dataItem[ANNOTATION_DB_NAMES[i]]) {
                                exists = elementExists(cd.data, xValue, i + 1); //Was the point already added?
                                if (exists != -1) {
                                    //If it was, make it bigger
                                    //TODO - dots get to big and look strange when increase indefinitly, need to set some sort of range
                                    cd.data[exists].tooltip += dataItem[ANNOTATION_DB_NAMES[i]];
                                } else {
                                    //if is wasn't, create it
                                    cd.data.push({
                                        x: xValue,
                                        y: i + 1,
                                        r: 10, //size of the dot (radius)
                                        tooltip: dataItem[ANNOTATION_DB_NAMES[i]]
                                    });
                                    $scope.colors.push($scope.annUtil.getColor(ANNOTATION_DB_NAMES[i]));

                                }
                                //backgroundColor: "rgba(248, 226, 176, 1)"
                            }
                        }
                    }
                }
            }
            else if ($scope.chartTypeEx == CT_LINE || $scope.chartTypeEx == CT_DATA) { //inside if checking that grouping by year/month/quarter

                //create the chart data with xAxis lables all set to 0
                var xAxisLabels = $scope.getTimelineXAxisLabels();
                for (i in xAxisLabels) {
                    cd.data.push({
                        x: xAxisLabels[i],
                        y: [0],
                        tooltip: "Need to add text for the tooltip" //TODO - what whould be in the tooltip - the count (r) ?
                    });
                }

                //Add points to chart data(cd)
                for (var dp in dateDict) {
                    dt = new Date(dp);
                    dataItem = dateDict[dp];

                    //is the date within the period selected
                    if (DateRange.isDateWithinRange(dt, selectedRange)) {

                        //determine the xAxis placement
                        switch ($scope.chartDataSource) {
                            case DS_YEAR:
                                xValue = dt.getMonth() + 1;
                                break;
                            case DS_MONTH:
                                xValue = dt.getDate();
                                break;
                            case DS_QUARTER:
                                xValue = (dt.getMonth() + 1) - ((dt.getQuarter() - 1) * 3);
                                break;
                            default:
                                console.log("This is not giving you any info.");
                        }

                        //Add the points
                        for (var i = 0; i < ANNOTATION_DB_NAMES.length; i++) {
                            if (dataItem[ANNOTATION_DB_NAMES[i]]) {
                                exists = elementExistsOnlyXValue(cd.data, xAxisLabels[xValue]); //Was the point already added?
                                if (exists != -1) { //element was not found
                                    //If it was, make it bigger
                                    //TODO - dots get to big and look strange when increase indefinitly, need to set some sort of range
                                    cd.data[exists].y[0] += dataItem[ANNOTATION_DB_NAMES[i]];
                                } else {
                                    //if is wasn't, create it
                                    cd.data.push({
                                        x: xValue,
                                        y: [dataItem[ANNOTATION_DB_NAMES[i]]],

                                    });

                                }
                            }
                        }
                    }
                }

                //for data table remove empty data points
                if ($scope.chartTypeEx == CT_DATA) {
                    cd.data = cd.data.filter(function(dp) {
                        return dp.y[0] != 0;
                    }); //if the y value is 0 it is empty
                }
            }
            }
            if ($scope.chartTypeEx == CT_TIMELINE) {
                $scope.updateTimelineChart(cd.data);
            } else if ($scope.chartTypeEx == CT_LINE) {
                // cd.data.sort(function(a,b){ return a.x-b.x; }); // Doesn't work and not necessary
                $scope.updateLineChart(cd.data);
            }

            //changes bar graph tool tip to display count
        }


        if ($scope.chartTypeEx == CT_BAR) {
            $scope.updateBarChart(cd);
        }

        if ($scope.chartTypeEx == CT_PIE) {
            $scope.updatePieChart(cd);
        }


        if ($scope.chartTypeEx == CT_DOUGHNUT) {
            $scope.updateDoughnutChart(cd);
        }


        //For pie chart and bar, if they group by annotation type use annotation colors
        if ($scope.chartDataSource == DS_TYPE && $scope.chartTypeEx == CT_PIE) {
            $scope.colors = [];
            for (index in cd.data) {
                $scope.colors.push(new AnnotationsUtil().getColor(cd.data[index].annotationType));
            }
        } else if ($scope.chartDataSource == DS_TYPE && $scope.chartTypeEx == CT_DOUGHNUT) {
            $scope.colors = [];
            for (index in cd.data) {
                $scope.colors.push(new AnnotationsUtil().getColor(cd.data[index].annotationType));
            }
        } else if ($scope.chartTypeEx != CT_TIMELINE) {
            $scope.colors = [
                "#4AD6C2", //light blue green
                "#4DC2DD", //light blue
                "#CC5571", //pink
                "#FEC86F", //buttery yellow
                "#DF6D5D", //salmon
                "#A0436F", //fushia/plum
                "#70D7A6", //light green
                "#F59A4D", //orange
                "#89598A", //purple
                "#2C749A" //darker blue
            ]
        }


        $scope.chartData = cd;
        // Set data used for chart data in datatable view
        $scope.tableData = cd.data;
        data = []; // initializing the snippet list. Need to test more.

    };

    $scope.chartData = {
        series: [],
        data: []
    };


    var getMonth = function(date) {
        return date.substr(5, 2);
    };

    var getTextMonth = function(month) {
        var months = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        return months[parseInt(month)];
    }
    var convertCamelCase = function camelize(datasource) {
        return datasource.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
            return index == 0 ? letter.toLowerCase() : letter.toUpperCase();
        }).replace(/\s+/g, '');

    }

    caseService.getAnnotations(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, annotations) {
        if (!err) {
            $scope.annotations = annotations;
            $scope.updateChart();

        } else {
            console.log(err);
        }
    });

    $scope.showPieAndBarAndDoughnutChart = function(chartDataSource) {
        // if (chartDataSource === DS_BODY_PART) {
        //     return true;
        // } else 
        if (chartDataSource === DS_BODY_SYSTEM) {
            return true;
        } else if (chartDataSource === DS_TYPE) {
            return true;
        } else {
            return false;
        }

    };

    // Navigate to the findings page for chart datatables
    $scope.openFindingsLink = function(data) {

        var urlSuffix = data;

        if (($scope.chartDataSource === "Year") || ($scope.chartDataSource === "Month") || ($scope.chartDataSource === "Quarter")) {
            //urlSuffix = "Date-" + $scope.chartDataSource + "-" + $scope.period + "-" + data;

            $scope.setFindingsChartState();
            $location.path('/annotations/' + urlSuffix);

        }else if($scope.chartDataSource == DS_TYPE){
            //need to remove any space of / from the type  - hack unless I add a function the AnnotationsUtil to convere text back to dbName
            urlSuffix = $scope.annUtil.getDBNameFromDisplayText(urlSuffix);
            $location.path('/annotations/' + urlSuffix);

        } else {
            urlSuffix = urlSuffix.replace(/\s+/g, '');
            $location.path('/annotations/' + urlSuffix);
        }

        if (($scope.chartDataSource === "Year") || ($scope.chartDataSource === "Month")) {
            stateService.setState('snippetName', $scope.period + "-" + data);
        } else {
            stateService.setState('snippetName', $scope.chartDataSource.toString() + " - " + data);
        }
        //forcing reload in case url doesn't change
        $route.reload();
    }

    $scope.openFindings = function() {
        $location.path('/annotations');
    }
}
});