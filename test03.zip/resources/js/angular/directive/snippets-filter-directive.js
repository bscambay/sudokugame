app.directive('snippetsFilterDirective', ['$timeout', function ($timeout) {
    return {
        restrict: 'E',
        templateUrl: $('#virtualPath').val() + '/snippetsFilterTemplate',
        scope: {
            ac: "=ac",
            snippets: "=snippets",
            snippetsToDisplay: "=snippetsToDisplay",
            advancedsearch: '@',
            collapsed: "=collapsed",
            annotationType: "=annotationType",
            filterBubbles: "=filterBubbles",
            removeFilterBubble: "=removeFilterBubble"
        },
        controller: 'snippetsFilterController',
        controllerAs: "spc",
        link: function($scope){
            $scope.$on('searchedText', function(){
                $timeout(function(){
                        //when search value changes - search for all the added spans and remove them
                        $('.search-text-highlight').each(function () {
                            $(this).replaceWith($(this).text());
                        });
                        //highlight the searched for text
                        if ($scope.searchText != "" && $scope.searchText != undefined) {
                            $('.snippet-text span, .snippet-text button').each(function () {
                                var snippetText = $(this).text();
                                var regEx = new RegExp($scope.searchText, "ig")
                                var textWithHighlight = "";
                                var locationOfFoundText;

                                //test if it contains the searched text
                                while (snippetText.search(regEx) != -1) {
                                    //if it does - find the location of the text in the span
                                    locationOfFoundText = snippetText.search(regEx);
                                    //take the text before it + begin span + searched text + end span
                                    textWithHighlight += snippetText.slice(0, locationOfFoundText)
                                        + "<span class='search-text-highlight' style='background-color: yellow; font-weight:bold'>"
                                        + snippetText.substr(locationOfFoundText, $scope.searchText.length)
                                        + "</span>";
                                    //update snippetText so can search the rest of the text for another ocurance
                                    snippetText = snippetText.slice(locationOfFoundText + $scope.searchText.length);
                                }

                                //add any remaining text
                                textWithHighlight += snippetText;
                                $(this).html(textWithHighlight);
                            });
                        }
                })
            })
        }
    };
}]);

app.controller('snippetsFilterController', function ($scope, $route, pageService, caseService, stateService, documentService) {

    if (pageService.ensureCaseSelected())
    {
        $scope.activeTab = $route.current.activeTab;

        $scope.searchText;
        $scope.annotationTypes = new AnnotationsUtil().annotationTypes;
        //start with all annotation types displayed
        for (i in $scope.annotationTypes) {
            $scope.annotationTypes[i].selected = true;
        }
        $scope.annTypes = {}

        //used for document filter
        $scope.documents = {};
        $scope.blueBookChapters = {};
        $scope.bodySystems = {};
        $scope.logicals = {};
        $scope.possibleLogicals = {
            negative: {name: "Negative", selected: true},
            conditinal: {name: "Conditional", selected: true},
            uncertain: {name: "Uncertain", selected: true},
            subjective: {name: "Subjective", selected: true},
            generic: {name: "Generic", selected: true},
            history: {name: "History", selected: true}
        };

        $scope.filteringDone = false;

        $scope.datesOn = false;

        // $scope.highlightDates = function() {

        //     if($scope.datesOn == true){
        //         //highlight any dates
        //         $('.snippet-text span').each(function(){
        //             var snippetText = $(this).text();
        //             var regEx = /(\d+)(-|\/)(\d+)(?:-|\/)(?:(\d+)\s+(\d+):(\d+)(?::(\d+))?(?:\.(\d+))?)?/;
        //             var textWithHighlight = "";
        //             var locationOfFoundText;

        //             //test if it contains a date
        //             while(snippetText.search(regEx) != -1){
        //                 //if it does - find the location
        //                 locationOfFoundText = snippetText.search(regEx);
        //                 //take the text before it + begin span + date + end span
        //                 textWithHighlight += snippetText.slice(0, locationOfFoundText)
        //                             + "<span class='date-highlight' style='background-color: yellow; font-weight:bold'>"
        //                             + snippetText.substr(locationOfFoundText, 8)
        //                             + "</span>";
        //                 //update snippetText so can search the rest of the text for another date
        //                 snippetText = snippetText.slice(locationOfFoundText + 8);
        //             }

        //             //add any remaining text
        //             textWithHighlight += snippetText;
        //             $(this).html(textWithHighlight);
        //         });
        //     } else {
        //         //remove any date highlights
        //         $('.date-highlight').each(function(){
        //             $(this).replaceWith($(this).text());
        //         });
        //     }
        // }
        $scope.highlightDates = function () {

            if ($scope.datesOn == true) {
                //highlight any dates
                $('.snippet-text span').each(function () {
                    var snippetText = $(this).text();
                    var regEx = /(\d+)(-|\/)(\d+)(?:-|\/)(?:(\d+)\s+(\d+):(\d+)(?::(\d+))?(?:\.(\d+))?)?/;
                    var textWithHighlight = "";
                    var locationOfFoundText;

                    //test if it contains a date
                    while (snippetText.search(regEx) != -1) {
                        //if it does - find the location
                        locationOfFoundText = snippetText.search(regEx);
                        //take the text before it + begin span + date + end span
                        textWithHighlight += snippetText.slice(0, locationOfFoundText)
                            + "<span class='date-highlight' style='background-color: yellow; font-weight:bold'>"
                            + snippetText.substr(locationOfFoundText, 8)
                            + "</span>";
                        //update snippetText so can search the rest of the text for another date
                        snippetText = snippetText.slice(locationOfFoundText + 8);
                    }

                    //add any remaining text
                    textWithHighlight += snippetText;
                    $(this).html(textWithHighlight);
                });
            } else {
                //remove any date highlights
                $('.date-highlight').each(function () {
                    $(this).replaceWith($(this).text());
                });
            }
        }


        $scope.displayAllAnnotationTypes = true;
        $scope.displayAllDocuments = true;
        $scope.displayAllBlueBookSections = true;
        $scope.displayAllBodySystems = true;
        $scope.displayAllLogicals = true;

        //filters snippets based on search text
        $scope.filterSnippets = function () {
            $scope.filterBubbles = {
                totalMatches: "",
                filters: []
            };

            //reset the snippets
            if ($scope.snippets != undefined && $scope.snippets instanceof Array) {
                $scope.snippetsToDisplay = $scope.snippets.slice(0);
            } else {
                $scope.snippetsToDisplay = $scope.snippets;//not sure if this is correct
            }

            if ($scope.snippetsToDisplay != undefined) {

                //filter snippets displayed based on searched text
                if ($scope.searchText != "" && $scope.searchText != undefined) {
                    $scope.snippetsToDisplay = $scope.snippetsToDisplay.filter(function (snip) {
                        if (snip != null && snip.snippet != undefined && snip != undefined) {
                            return snip.snippet.text.toLowerCase().indexOf($scope.searchText.toLowerCase()) != -1
                        }
                    });

                    $scope.filterBubbles.filters.push({
                        type: 'searchText',
                        id: 'searchText',
                        value: $scope.searchText
                    });
                }

                //filter snippets displayed based on annotation types
                for (var i = 0; i < $scope.snippetsToDisplay.length; i++) {
                    var item = $scope.snippetsToDisplay[i];

                    if ($scope.annTypes[item.type].selected == false) {
                        $scope.snippetsToDisplay.splice(i, 1);
                        i--;
                    }
                }

                //filter snippets to display based on document
                for (var i = 0; i < $scope.snippetsToDisplay.length; i++) {
                    var snip = $scope.snippetsToDisplay[i];
                    if ($scope.documents[snip.documentId].selected == false) {
                        $scope.snippetsToDisplay.splice(i, 1);
                        i--;
                    }
                }

                //filter snippets to display based on blue book blueBookChapters
                for (var i = 0; i < $scope.snippetsToDisplay.length; i++) {
                    var snip = $scope.snippetsToDisplay[i];
                    var hasChapter = false;
                    if (snip.blueBookLocations != undefined) {
                        for (var j = 0; j < snip.blueBookLocations.length; j++) {
                            var location = snip.blueBookLocations[j];
                            if ($scope.blueBookChapters[location.chapter + "-" + location.section].selected == true) {
                                hasChapter = true;
                            }
                        }
                    } else {
                        //has no specified bluebook locations
                        hasChapter = $scope.blueBookChapters[undefined].selected;
                    }
                    if (!hasChapter) {
                        $scope.snippetsToDisplay.splice(i, 1);
                        i--;
                    }
                }

                //filter snippets to display based on body system
                for (var i = 0; i < $scope.snippetsToDisplay.length; i++) {
                    var snip = $scope.snippetsToDisplay[i];
                    var hasBodySystem = false;
                    if (snip.bodySystems.length != 0) {
                        for (var j = 0; j < snip.bodySystems.length; j++) {
                            var system = snip.bodySystems[j];
                            if ($scope.bodySystems[system].selected == true) {
                                hasBodySystem = true;
                            }
                        }
                    } else {
                        //has no specified bluebook locations
                        hasBodySystem = $scope.bodySystems[undefined].selected;
                    }
                    if (!hasBodySystem) {
                        $scope.snippetsToDisplay.splice(i, 1);
                        i--;
                    }
                }

                //filter by logicals
                for (var i = 0; i < $scope.snippetsToDisplay.length; i++) {
                    var snip = $scope.snippetsToDisplay[i];
                    for(j in $scope.logicals){
                        if ($scope.logicals[j].selected == false && snip[j] == true) {//not sure of this logic
                            $scope.snippetsToDisplay.splice(i, 1);
                            i--;
                            break;
                        }
                    }
                }
            }

            // //when search value changes - search for all the added spans and remove them
            // $('.search-text-highlight').each(function () {
            //     $(this).replaceWith($(this).text());
            // });
            // //highlight the searched for text
            // if ($scope.searchText != "" && $scope.searchText != undefined) {
            //     $('.snippet-text span, .snippet-text button').each(function () {
            //         var snippetText = $(this).text();
            //         var regEx = new RegExp($scope.searchText, "ig")
            //         var textWithHighlight = "";
            //         var locationOfFoundText;

            //         //test if it contains the searched text
            //         while (snippetText.search(regEx) != -1) {
            //             //if it does - find the location of the text in the span
            //             locationOfFoundText = snippetText.search(regEx);
            //             //take the text before it + begin span + searched text + end span
            //             textWithHighlight += snippetText.slice(0, locationOfFoundText)
            //                 + "<span class='search-text-highlight' style='background-color: yellow; font-weight:bold'>"
            //                 + snippetText.substr(locationOfFoundText, $scope.searchText.length)
            //                 + "</span>";
            //             //update snippetText so can search the rest of the text for another ocurance
            //             snippetText = snippetText.slice(locationOfFoundText + $scope.searchText.length);
            //         }

            //         //add any remaining text
            //         textWithHighlight += snippetText;
            //         $(this).html(textWithHighlight);
            //     });
            // }

            $scope.$broadcast('searchedText');

            var tempFilterBubbles = []

            //update the select All checkboxes
            var allSelected = true
            for (i in $scope.annTypes) {
                if ($scope.annTypes[i].selected == false) {
                    allSelected = false;
                } else {
                    tempFilterBubbles.push({
                        type: 'annTypes',
                        id: i,
                        value: $scope.annTypes[i].text
                    });
                }
            }
            $scope.displayAllAnnotationTypes = allSelected;
            if (!allSelected) {
                $scope.filterBubbles.filters = $scope.filterBubbles.filters.concat(tempFilterBubbles);
            }

            tempFilterBubbles = []
            allSelected = true;
            for (i in $scope.documents) {
                if ($scope.documents[i].selected == false) {
                    allSelected = false;
                } else {
                    tempFilterBubbles.push({
                        type: 'documents',
                        id: i,
                        value: $scope.documents[i].name
                    });
                }
            }
            $scope.displayAllDocuments = allSelected;
            if (!allSelected) {
                $scope.filterBubbles.filters = $scope.filterBubbles.filters.concat(tempFilterBubbles);
            }

            tempFilterBubbles = []
            allSelected = true;
            for (i in $scope.blueBookChapters) {
                if ($scope.blueBookChapters[i].selected == false) {
                    allSelected = false;
                } else {
                    tempFilterBubbles.push({
                        type: 'blueBookChapters',
                        id: i,
                        value: $scope.blueBookChapters[i].name
                    });
                }
            }
            $scope.displayAllBlueBookSections = allSelected
            if (!allSelected) {
                $scope.filterBubbles.filters = $scope.filterBubbles.filters.concat(tempFilterBubbles);
            }

            
            allSelected = true;
            for (i in $scope.bodySystems) {
                if ($scope.bodySystems[i].selected == false) {
                    allSelected = false;
                }
            }
            $scope.displayAllBodySystems = allSelected;

            allSelected = true;
            for(i in $scope.logicals){
                if($scope.logicals[i].selected == false){
                    allSelected = false;
                }
            }
            $scope.displayAllLogicals = allSelected;
        };

        // $scope.removeFilterBubble = function(bubble){
        //     $scope[bubble.type][bubble.id].selected = false;
        //     $scope.filterSnippets();
        // }

        $scope.$watch('removeFilterBubble', function (bubble, ov) {
            if (bubble != undefined) {
                if (bubble.type == 'searchText') {
                    $scope.searchText = ""
                } else {
                    $scope[bubble.type][bubble.id].selected = false;

                }
                //refilter
                $scope.filterSnippets();
            }
        })


        $scope.updateDocList = function () {
            if ($scope.headers != undefined) {
                //check if there are any snippets to display
                if ($scope.snippets != undefined) {
                    for (var i = 0; i < $scope.snippets.length; i++) {
                        if ($scope.snippets[i] != null) {
                            var docId = $scope.snippets[i].documentId;
                            //if doc is not in the list of document, add it.
                            if (!$scope.documents[docId]) {
                                var docName;
                                if (docId == undefined) {
                                    docName = "Unspecified";
                                } else {
                                    for (var j = 0; j < $scope.headers.length; j++) {
                                        if ($scope.headers[j].documentId == docId) {
                                            docName = $scope.headers[j].shortDisplayName;
                                            break;
                                        }
                                    }
                                }
                                $scope.documents[docId] = {
                                    name: docName,
                                    selected: true
                                };
                            }
                        } else {
                            console.log($scope.snippets[i]);
                        }
                    }
                } else {
                    //there are no snippets to display
                    $scope.documents = {};
                }
            }
        };

        $scope.updateBlueBookChapters = function () {
            //check if there are any snippets to display
            if ($scope.snippets != undefined) {
                for (var i = 0; i < $scope.snippets.length; i++) {
                    if ($scope.snippets[i] != null && $scope.snippets[i].blueBookLocations != undefined) {
                        //loop thru all blue blook bluebook locations
                        for (var j = 0; j < $scope.snippets[i].blueBookLocations.length; j++) {
                            var location = $scope.snippets[i].blueBookLocations[j];
                            if (!$scope.blueBookChapters[location.chapter + "-" + location.section]) {
                                $scope.blueBookChapters[location.chapter + "-" + location.section] = {
                                    name: "Chapter:" + location.chapter + " " + "Section:" + location.section,
                                    selected: true
                                };
                            }
                        }
                    } else if ($scope.snippets[i] != null && $scope.snippets[i].blueBookLocations == undefined) {
                        $scope.blueBookChapters[undefined] = {
                            name: "Unspecified",
                            selected: true
                        };
                    }
                }
            } else {
                //there are no snippets to display
                $scope.blueBookChapters = {};
            }
        };

        $scope.updateBodySystems = function () {
            //check if there are any snippets to display
            if ($scope.snippets != undefined) {
                for (var i = 0; i < $scope.snippets.length; i++) {
                    if ($scope.snippets[i] != null && $scope.snippets[i].bodySystems != undefined && $scope.snippets[i].bodySystems.length > 0) {
                        //loop thru all body systems for the annotation
                        for (var j = 0; j < $scope.snippets[i].bodySystems.length; j++) {
                            var system = $scope.snippets[i].bodySystems[j];
                            if (!$scope.bodySystems[system]) {
                                $scope.bodySystems[system] = {
                                    name: system,
                                    selected: true
                                };
                            }
                        }
                    } else if ($scope.snippets[i] != null && $scope.snippets[i].bodySystems.length == 0) {
                        $scope.bodySystems[undefined] = {
                            name: "Unspecified",
                            selected: true
                        };
                    }
                }
            } else {
                //there are no snippets to display
                $scope.bodySystems = {};
            }
        };

        $scope.updateLogicalsList = function () {
            //start fresh each time
            $scope.logicals = {};

            //check if there are any snippets to display
            if ($scope.snippets != undefined) {
                for (var i = 0; i < $scope.snippets.length; i++) {
                    for(logical in $scope.possibleLogicals){
                        if($scope.snippets[i][logical]){
                            //if that logical value for the snippet is true
                            $scope.logicals[logical] = $scope.possibleLogicals[logical];
                        }
                    }
                }
            }
        };

        $scope.updateAnnTypes = function () {
            //start fresh each time
            $scope.annTypes = {};

            //check if there are any snippets to display
            if ($scope.snippets != undefined) {
                for (var i = 0; i < $scope.snippets.length; i++) {
                    if($scope.snippets[i].type != undefined){
                        if(!$scope.annTypes[$scope.snippets[i].type]){
                            //if that logical value for the snippet is true
                            $scope.annTypes[$scope.snippets[i].type] = $scope.annotationTypes[$scope.snippets[i].type];
                        }
                    }
                }
            }
        };

        $scope.updateCounts = function () {
            //reset counts to 0
            for (i in $scope.annTypes) {
                $scope.annTypes[i].count = 0;
            }
            for (i in $scope.documents) {
                $scope.documents[i].count = 0;
            }
            for (i in $scope.blueBookChapters) {
                $scope.blueBookChapters[i].count = 0;
            }
            for (i in $scope.bodySystems) {
                $scope.bodySystems[i].count = 0;
            }
            for(i in $scope.logicals){
                $scope.logicals[i].count = 0;
            }

            //check if there are any snippets to display
            if ($scope.snippets != undefined) {
                //if there are update counts based on current list of snippets provided
                for (var i = 0; i < $scope.snippets.length; i++) {
                    if ($scope.annTypes[$scope.snippets[i].type]) {
                        $scope.annTypes[$scope.snippets[i].type].count++;
                    } else {
                        if (!$scope.annTypes[undefined]) {
                            //first annotation without a annotation type - need to add the checkbox
                            $scope.annTypes[undefined] = {
                                color: "white",
                                text: "Unspecified",
                                selected: true,
                                count: 1
                            };
                        } else {
                            //checkbox was already added, just need to update the count
                            $scope.annTypes[undefined].count++;
                        }
                        console.log("Unknow annotation type - " + $scope.snippets[i].type);
                    }

                    $scope.documents[$scope.snippets[i].documentId].count++;

                    //need to loop thru each bluebook location for the annotation
                    if ($scope.snippets[i].blueBookLocations != undefined) {
                        for (var j = 0; j < $scope.snippets[i].blueBookLocations.length; j++) {
                            var location = $scope.snippets[i].blueBookLocations[j]
                            if ($scope.blueBookChapters[location.chapter + "-" + location.section]) {
                                $scope.blueBookChapters[location.chapter + "-" + location.section].count++;
                                //need to prevent it from updating the count more than once per annotation
                            } else {
                                console.log("Unkown bluebook chapter - " + scope.snippets[i].blueBookLocations[j].chapter);
                            }
                        }
                    } else if ($scope.snippets[i].blueBookLocations == undefined) {
                        $scope.blueBookChapters[undefined].count++;
                    }

                    //loop thru each body system on each annotation and update body system counts
                    if ($scope.snippets[i].bodySystems != undefined && $scope.snippets[i].bodySystems.length > 0) {
                        for (var j = 0; j < $scope.snippets[i].bodySystems.length; j++) {
                            var system = $scope.snippets[i].bodySystems[j]
                            if ($scope.bodySystems[system]) {
                                $scope.bodySystems[system].count++;
                                //need to prevent it from updating the count more than once per annotation
                            } else {
                                console.log("Unkown body system - " + scope.snippets[i].bodySystems[j]);
                            }
                        }
                    } else if ($scope.snippets[i].bodySystems.length == 0) {
                        $scope.bodySystems[undefined].count++;
                    }

                    for(logical in $scope.logicals){
                        if($scope.snippets[i][logical]){
                            $scope.logicals[logical].count++;
                        }
                    }
                }
            }
        };

        caseService.getDisabilityCaseId(pageService.getFolderNumber(), pageService.getCaseNumber(), function (err, caseId) {
            if (err) {
                console.error(err);
            }
            else {
                $scope.caseId = caseId;
                documentService.getDocumentHeaders($scope.caseId, function (err, headers) {

                    if (err) {
                        console.error(err);
                    }
                    else {
                        $scope.headers = headers;
                    }
                    $scope.loadingDocumentList = false;
                    $scope.updateDocList();
                });
            }
        });

        $scope.$watch('snippets', function (nv, ov) {
            $scope.updateDocList();
            $scope.updateAnnTypes();
            $scope.updateBlueBookChapters();
            $scope.updateBodySystems();
            $scope.updateLogicalsList();
            $scope.updateCounts();
            //if the snippets have changed refilter
            $scope.filterSnippets();
        })

        $scope.$watch('annotationType', function (nv, ov) {
            //need to check if the new value is a valid annotation type and if it is filter to that type
            var annTypeArray = new AnnotationsUtil().getAnnotationTypesDBValues();
            if ($scope.annotationType != undefined && annTypeArray.indexOf[$scope.annotationType] != -1) {
                for (i in $scope.annTypes) {
                    if (i == $scope.annotationType) {
                        $scope.annTypes[i].selected = true;
                    } else {
                        $scope.annTypes[i].selected = false;
                    }
                }
            }

            //if the snippets have changed refilter
            $scope.filterSnippets();
        });

        $scope.collapseDoc = function () {
            if ($('#docarrow').hasClass("fa fa-angle-double-down")) {
                $('#docarrow').attr("class", "fa fa-angle-double-right")
            }
            else {
                $('#docarrow').attr("class", "fa fa-angle-double-down")
            }
        }

        $scope.collapseType = function () {
            if ($('#typearrow').hasClass("fa fa-angle-double-down")) {
                $('#typearrow').attr("class", "fa fa-angle-double-right")
            }
            else {
                $('#typearrow').attr("class", "fa fa-angle-double-down")
            }
        }

        $scope.applyFilters = function () {
            $scope.showDocs = false;
        }

        $scope.showDocs = false;

        $scope.showMoreDocs = function () {
            $scope.showDocs = !$scope.showDocs;
        }

        //used to determine which filter set to display
        $scope.showSearchFilter = true;
        $scope.showAnnotationTypeFilter = false;
        $scope.showHighlightOptions = false;
        $scope.showDocumentFilter = false;
        $scope.showBluebookFilter = false;
        $scope.showBodySystemsFilter = false;
        $scope.showLogicalsFilter = false;

        //if the filter should be displayed or collapsed
        $scope.collapsed = false;

        $scope.selectFilter = function (filterSelection) {
            var alreadySelected = $scope[filterSelection];

            //set all to false and then will select the correct one
            $scope.showSearchFilter = false;
            $scope.showAnnotationTypeFilter = false;
            $scope.showHighlightOptions = false;
            $scope.showDocumentFilter = false;
            $scope.showBluebookFilter = false;
            $scope.showBodySystemsFilter = false;
            $scope.showLogicalsFilter = false;

            if (!alreadySelected) {
                //only show if it was not already selected
                $scope[filterSelection] = true;
                $scope.collapsed = false;
            } else {
                $scope.collapsed = true;
            }
        }

        $scope.showAll = function ($event, filterName) {
            if ($event.target.checked == true) {
                //they checked the show all option
                for (index in $scope[filterName]) {
                    $scope[filterName][index].selected = true;
                }
            }
            if ($event.target.checked == false) {
                //they uncheck the show all option - need to uncheck all checkboxes
                for (index in $scope[filterName]) {
                    $scope[filterName][index].selected = false;
                }
            }
            $scope.filterSnippets();
        }
    }
});
