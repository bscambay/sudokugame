app.directive('documentView', function () {
    return {
        restrict: 'E',
        templateUrl: $('#virtualPath').val() + '/documentView',
        scope: {
            pagingInfo: "=pagingInfo",
            header: "=header",
            snippetsToDisplay: "=snippetsToDisplay"
        },
        controller: 'documentViewController'
    };
});

app.controller('documentViewController', function ($scope,$route, $routeParams, $sce, $timeout, pageService, caseService, documentService) {

    if (pageService.ensureCaseSelected() && $route.current.activeTab == "documents")
    {
        $scope.loadingDocument = false;
        $scope.showInfo = false;
        //$scope.pageBeingDisplayed;
        $scope.thePage;
        var pageNumber;

        /*
        * Use the page number from the Angular Paging Directive to
        * select which document page to display.
        * @params pageNumber
        * @returns document page formatted as html
        */
        // $scope.getPageToDisplay = function(pageNumber) {
        //     if(pageNumber >= 0) {
        //         if($scope.pagingInfo.pages[pageNumber] != undefined) {
        //             $scope.pageBeingDisplayed = pageNumber;
        //             $scope.thePage = $scope.pagingInfo.pages[pageNumber]
        //             return $scope.thePage;
        //         }
        //     }
        // }

        $scope.setPageToDisplay = function (page) {
            if (page >= 0) {
                if ($scope.pagingInfo.pages[page] != undefined) {
                    $scope.thePage = $scope.pagingInfo.pages[page];
                    pageNumber = page;
                }
            }
        }

        $scope.toggleInfo = function (annotationId) {

            //use id to find an annotation, call it snippet to work in modal
            var snippet;

            var allAnnotations = $scope.thePage.annotations;

            var annUtil = new AnnotationsUtil();

            while (annUtil.containsMultiples(allAnnotations)) {
                allAnnotations = annUtil.getAllAnnotations(allAnnotations);
            }

            for (var i = 0; i < allAnnotations.length; i++) {
                if (allAnnotations[i]._id === annotationId) {
                    snippet = allAnnotations[i];
                    break;
                }
            }

            //needed to add bluebook links
            snippet = AnnotationFormatter.convertToStandardFormat(snippet);

            if (!$scope.showInfo && snippet) {
                $scope.showInfo = true;
                var str = snippet.snippet.text.substring(snippet.snippet.offset, snippet.snippet.offset + snippet.end - snippet.begin)
                $scope.displayed_snippet = snippet
                $scope.displayed_snippet.name = str;

                if (snippet.bodyPart && snippet.bodySystem) {
                    $scope.displayed_snippet.bodyInfo = {
                        bodyPart: snippet.bodyPart,
                        bodySystem: snippet.bodySystem
                    }
                }
            }
            else {
                $scope.showInfo = false;
            }

        }

        refresh = function(){
            if($scope.thePage.hasOwnProperty("change")){
                            if($scope.thePage.change === false) {
                                $scope.thePage.change = true;
                            } else {
                                $scope.thePage.change = false;
                            }
                        } else {
                            $scope.thePage.change = false;
                        }
        }

        $scope.$watch('pagingInfo', function(newValue, oldValue){
            if($scope.pagingInfo && $scope.pagingInfo.hasOwnProperty("index")) {
                $scope.thePage = $scope.pagingInfo.pages[pageNumber];
            }
        })

        $scope.$watch('snippetsToDisplay', function (newValue, oldValue) {
                if ($scope.snippetsToDisplay) {
                    documentService.setAnnotationsToDisplay($scope.snippetsToDisplay);

                    if (!$scope.thePage) {
                        $scope.thePage = $scope.pagingInfo.pages[0];
                    } else {
                        refresh();
                    }
                }
        })
    }
});