app.directive('findingsSnippetProvider', function() {
    return {
        restrict: 'E',
            templateUrl: $('#virtualPath').val() + '/findingsSnippetProvider',
        scope: {
            snippets: "=snippets",
            snippetsTitle: "=snippetsTitle",
            groupBy: "=groupBy"
        },
        controller: 'findingsSnippetProviderController'
    };
});


app.controller('findingsSnippetProviderController', function($scope, $route, $routeParams, stateService, pageService, caseService, DTOptionsBuilder) {

     if (pageService.ensureCaseSelected())
    {

        //condition so will only affect findings page, since ng-show is loading all the directives
        if($route.current.activeTab == "annotations"){

            $scope.snippets=[];

            var type = $routeParams.key;
            var annotationType = $routeParams.annotationType; // parse secondary key for bubble timeline
        
            var convertCamelCase =  function(datasource) {
                return datasource.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
                return index == 0 ? letter.toLowerCase() : letter.toUpperCase();
                }).replace(/\s+/g, '');

            }

            //variables for toggling showAll / none checkboxes
            $scope.showCheckAll = stateService.getState('showCheckAll');

            //hiding/showing the checkbox
             
           // $scope.showCheckNone = false;

            $scope.getGroupByValue = function(){
                var fromState = stateService.getState('groupBy');

                if(fromState == "Annotation Type"){
                    return "type";
                } else if(fromState != undefined){
                    return convertCamelCase(fromState);
                } else {
                    return "bodySystem";
                }
            };

            $scope.groupBy = $scope.getGroupByValue();

            caseService.getAnnotations(pageService.getFolderNumber(), pageService.getCaseNumber(), function(err, annotations) {

                        if (!err)
                        {
                            $scope.snippetsTitle = stateService.getState('snippetName');

                            //changing to use AnnotationFormatter
                            $scope.annotations = AnnotationFormatter.formatArrayOfAnnotations(annotations, annotations);


                            $scope.snippets =[]; 

                            if(type == undefined){
                                
                                //if come to the findings page not thru a charts link
                                $scope.snippets = stateService.getState('snippets');
                                $scope.showCheckbox = false;

                            } else if (type != undefined){
                                //came to findings using a charts link                            
                                //uncheck both the show all and none checkboxes
                                $scope.showCheckAll = false;
                                //$scope.showCheckNone = false;
                                $scope.showCheckbox = true;
                                //used for date groupings
                                var range;
                                var selectedData = type;
                                var test;

                                if(['year', 'month', 'quarter'].indexOf($scope.groupBy) != -1){
                                    var period = stateService.getState('period');
                                    range = DateRange.getRangeFromName($scope.groupBy, period);

                                    if($scope.groupBy == "year" || $scope.groupBy == "quarter"){
                                        test = function(dt, selectedData){
                                            dt = new Date(dt);
                                            var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                                            return dt.getMonth() == months.indexOf(selectedData);
                                        }
                                    } else if ($scope.groupBy == "month"){
                                        test = function(dt, selectedData){
                                            dt = new Date(dt);
                                            return dt.getDate() == selectedData;
                                        }
                                    } //else if($scope.groupBy == "quarter"){
                                    //     //need to figure out this logic
                                    // }
                                }

                                //used when body parts or body systems were rolled up into an 'Other' category
                                var combinedInOther = stateService.getState('combinedInOther');
                                
                                for (var i=0; i < $scope.annotations.length;i++){

                                    var matches = false;
                                    var ann = $scope.annotations[i];
                                    
                                    if( (['year', 'month', 'quarter'].indexOf($scope.groupBy) != -1) && (annotationType != null ) ){
                                        //Date & annotation type grouping for Bubble timeline
                                        if( (ann.date != undefined) && (ann.type != undefined) ){
                                            var annDate = new Date(ann.date);
                                            if(DateRange.isDateWithinRange(annDate, range) && ann.type === annotationType){
                                                matches = test(annDate, selectedData);
                                                //console.log("Matched annotation is: " + JSON.stringify(ann));
                                            }                                        
                                        }
                                    } else 
                                    if(['year', 'month', 'quarter'].indexOf($scope.groupBy) != -1){
                                        //Date grouping
                                        if(ann.date != undefined){
                                            var annDate = new Date(ann.date);
                                            if(DateRange.isDateWithinRange(annDate, range)){
                                                matches = test(annDate, selectedData);
                                            }
                                        }
                                    } else if(type == "Other"){
                                        //Other 
                                        if(groupBy == "bodySystem"){
                                            if(ann.bodySystems){
                                                for(var b = 0; b < ann.bodySystems.length; b++){
                                                    if(combinedInOther.indexOf(ann.bodySystems[b]) != -1){
                                                        matches = true;
                                                        break;
                                                    }
                                                }
                                            }
                                        }else if(ann[$scope.groupBy] != undefined){
                                            if(combinedInOther.indexOf(ann[$scope.groupBy]) != -1){
                                                matches = true;
                                            }
                                        }
                                    
                                    } else if($scope.groupBy == "bodySystem"){

                                        //Body Systems
                                        if (ann.bodySystems.length > 0){
                                            // console.log("What is the bodySystems? : " + ann.bodySystems + " with a count length of " + ann.bodySystems.length);

                                            for (j=0; j < ann.bodySystems.length; j++){
                                                // console.log("matching: " + type + " with " + ann.bodySystems[j].replace(/ /g, ''));

                                                if(ann.bodySystems[j].replace(/ /g, '') == type){
                                                    matches = true;

                                                }      

                                            }

                                        }
                                    } else{
                                        //everything else
                                        if(ann[$scope.groupBy] != undefined){
                                            if(ann[$scope.groupBy].replace(/ /g, '') === type){
                                                matches = true;
                                            }
                                        }
                                    }

                                    if(matches){
                                        //annotation matches selection add to snippets list
                                        if(ann.snippet !== undefined){
                                            $scope.snippets.push(ann);
                                        }
                                    }                                                        
                                }
                            }   // End for loop on snippet processing annotations

                        } else  // Output retrieving annotations error
                        {
                            console.log(err);
                        }

            }); // End getAnnotations

            $scope.processCheckAll = function() {
                 $scope.snippets = stateService.getState('snippets');
                if ($scope.showCheckAll) {
                    $scope.snippets = stateService.getState('snippets');
                   // $scope.showCheckNone = false;
                     $scope.showCheckbox = false;
                    $scope.snippetsTitle = "All Snippets";
                } 
                /*
                else {
                    if ($scope.showCheckNone) {
                        $scope.showCheckNone = false;
                    }
                }*/
            };
            /*
            $scope.processCheckNone = function() {
                if ($scope.showCheckNone) {
                    $scope.showCheckAll = false;
                    $scope.snippets = [];
                } else {
                    if ($scope.showCheckAll) {
                        $scope.showCheckAll = false;
                    }
                }
            };
        */
            $scope.$watch('groupByLabel', function(newValue, oldValue){
                if(newValue != undefined){
                    if(newValue == "Annotation Type"){
                        $scope.groupBy = "type";
                    } else if(newValue != undefined){
                        $scope.groupBy = convertCamelCase(newValue);
                    }
                }
            })
        }
    }
});


