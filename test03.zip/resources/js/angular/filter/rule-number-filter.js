app.filter('ruleNumber', function() {

    return function(input) {

        var output = input;

        // Get the parts
		var parts = input.match(/\[(.*?)\]/g);

		// Get out if we couldn't successfully parse it...
		if (parts && parts.length == 4)
        {
    		for (var i = 0; i < 3; i++)
            {
                // Strip off brackets
                parts[i] = parts[i].substring(1, parts[i].length - 1);
            }
			
            // Create the result object
		    output = parts[0] + " " + parts[1] + " " + parts[2];
        }

        return output;
    };
});