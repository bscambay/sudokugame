app.filter('ruleName', function() {

    return function(input) {

        var output = input;

		var parts = input.match(/\[(.*?)\]/g);

		if (parts && parts.length == 4)
        {
    		output = parts[3].substring(1, parts[3].length - 1);
        }

        return output;
    };
});