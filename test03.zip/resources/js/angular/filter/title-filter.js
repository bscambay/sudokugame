app.filter('title', function() {

    return function(str) {

        return StringUtil.toTitleCase(str);
    };
});