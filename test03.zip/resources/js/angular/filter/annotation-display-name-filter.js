app.filter('annotationDisplayName', function() {

    return function(value) {
        return Annotation.getDisplayName(value);
    };

});