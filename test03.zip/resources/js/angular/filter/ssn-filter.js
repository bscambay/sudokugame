app.filter('ssn', function() {

    return function(value) {
        return SSN.format(value);
    };

});