
var app = angular.module('cavApp', ["ngRoute", "angularCharts", "datatables", "chart.js", "treeControl", "bw.paging", "ui.bootstrap"]);


app.config(function($routeProvider) {

    /*
     * anything not recognized by the routeProvider will redirect
     * to the client summary view
     */
    $routeProvider.otherwise({
        redirectTo: '/patient'
    });

});