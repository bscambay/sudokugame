/**
 * Class responsible for accessing DMA
 * @author Chris Vaughan
 */
var dmaViewer = {
     
    DMA_URL: "http://CMWASPRD.ba.ssa.gov", // "http://DMA-DEV-VENDOR-CNT.ba.ssa.gov",

    /**
     * Open the DMA viewer for the specified document
     * @param docId required DMA document ID
     * @param title optional title to display in window
     */
    open:  function(docId, title) {
	
        if (docId)
        {
            var url = this.DMA_URL + '/DMAeClient/DMAInit?action=view&jurcntrl=yes&docid=' + docId;
            
            if (title)
            {
                url += '&tab=' + escape(title);
            }
            
            try
            {
                window.open(url);
            }
            catch (e)
            {
                console.log('dmaViewer - ' + (new Date()).toUTCString() + 
                        ' - could not open DMA Viewer: ' + e);
            }
        }
        else
        {
            console.log('dmaViewer - ' + (new Date()).toUTCString() + 
                    ' - Could not open DMA Viewer because no document ID was provided.');
        }
    }
};