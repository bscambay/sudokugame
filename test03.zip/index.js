var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var caseDb = require('./data/case-db.js');
var userDb = require('./data/user-db.js');
var search = require('./data/search.js')
var fs = require('fs');

var app = express();

// Add body parser to handle posts
app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());

var url_prefix = process.env.lifeCycle
var port = process.env.PORT;

if (!port) {
    port = 8090;
}

if (!url_prefix) {
    url_prefix = '/cav';
}

app.use(url_prefix, express.static('resources'))

/**
 * Function to retrieve user's PIN from the request
 */
var getPinFromRequest = function(req) {

    if (req && req.headers) {

        var pin = req.headers['x-iisnode-auth_user'];

        if (pin)
        {
            if (pin.length > 6)
            {
                // Strip domain
                pin = pin.substring(pin.length - 6);
            }
            
            if (pin.length < 6)
            {
                console.error("Unexpected value found for user's PIN: " + pin);
            }
            else
            {
                return pin;
            }
        }
    }

    console.error("Unable to retrieve user's PIN from request.");
    return "000000";
};

/**
 * Application entry point
 */
app.post(url_prefix, function(req, res) {

    fs.readFile(path.join(__dirname, 'index.html'), 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            res.status(500).send(err);
        } else {

            data = data.replace('||folderNumber||', req.body.folderNum);
            data = data.replace('||caseNumber||', req.body.caseNum);
            data = data.replace('||virtualPath||', url_prefix)

            res.send(data);
        }
    });
});

/**
 * Application entry point
 * Note that gets can't set folder number or case number to avoid sending this data in
 * the query text
 */
app.get(url_prefix, function(req, res) {
    // read file index.html, then callback (arrow function)
    fs.readFile(path.join(__dirname, 'index.html'), 'utf8', (err, data) => {
            /*
             * if error occured, log error and send response with 500 status (internal server error) and
             * error message as response
             */
            if (err) {
                console.error(err);
                res.status(500).send(err);
            /*
             * else fs was successful at reading the file index.html, replace ||virtualPath|| in the
             * index.html file with value of the url_prefix constant and send response.
             */
            } else {

				data = data.replace('||folderNumber||', null);
				data = data.replace('||caseNumber||', null);
                
                data = data.replace('||virtualPath||', url_prefix)

                res.send(data);
            }
        });
});

app.get(url_prefix + '/patientInfo', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "patient-info.html"));
});

app.get(url_prefix + '/allegations', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "allegations/allegations.html"));
});

app.get(url_prefix + '/blank', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "blank.html"));
});

app.get(url_prefix + '/rules', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "rules", "rules.html"));
});

app.get(url_prefix + '/rulesSnippetProvider', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "rules", "rules-snippet-provider.html"));
});

app.get(url_prefix + '/documents', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "document", "documents.html"));
});

app.get(url_prefix + '/documentList', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "document", "document-list.html"));
});

app.get(url_prefix + '/documentView', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "document", "documentView.html"));
});

app.get(url_prefix + '/documentProvider', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "document", "documentProvider.html"));
});

app.get(url_prefix + '/snippetsTemplate', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "snippetsTemplate.html"));
});

app.get(url_prefix + '/annotationLabel', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "labels", "annotation-label.html"));
});

app.get(url_prefix + '/annotations', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "findings.html"));
});

app.get(url_prefix + '/snippetsFilterTemplate', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "snippetsFilterTemplate.html"));
});

app.get(url_prefix + '/allegationsSnippetProvider', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "allegations", "allegations-snippet-provider.html"));
});

app.get(url_prefix + '/findingsSnippetProvider', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "findings-snippet-provider.html"));
});

app.get(url_prefix + '/annotationLabel', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "labels", "annotation-label.html"));
});

app.get(url_prefix + '/snippetsPage', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "snippets-page.html"));
});

app.get(url_prefix + '/case-timeline', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "case-timeline.html"));
});

app.get(url_prefix + '/caseTree', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "case-tree.html"));
});

app.get(url_prefix + '/chartDirective', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "charts", "chart.html"));
});

app.get(url_prefix +'/casesearch', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "case", "casesearch.html"));
});

app.get(url_prefix + '/advancedSearch', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "search", "advanced-search.html"));
});

app.get(url_prefix + '/sideSearch', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "search", "side-search.html"));
});

app.get(url_prefix + '/searchResults', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "search", "search-results.html"));
});

app.get(url_prefix + '/logout', function(req, res) {
    res.sendFile(path.join(__dirname, "templates", "logout.html"));
});

/**
 * Handles saving new issues
 */
app.post(url_prefix + '/saveNewIssue', function(req, res) {

    var issue = req.body.issue;
    var errPfx = "Unable to save new issue: ";

    if (issue)
    {
        issue.pin = getPinFromRequest(req);;

        userDb.saveIssue(issue, function(err) {
            if (err)
            {
                console.error(errPfx + err);
                res.status(500).send(err);
            }
            else
            {
                res.send({
                    status: 'success'
                });
            }
        });
    }
    else
    {
        console.error(errPfx + "Issue required");
        res.status(500).send("Issue required");
    }
});

/**
 * Retrieve user's saved searches
 */
app.post(url_prefix + '/getSavedSearches', function(req, res) {

    userDb.getSavedSearches("", function(err, savedSearches) {

        if (err) {
            console.error(err);
            res.status(500).send(err);
        } else {
            res.send(savedSearches);
        }
    });

});

app.post(url_prefix + '/getDocumentHeaders', function(req, res) {

    caseDb.getDocumentHeaders(req.body.disabilityCaseId, function(err, headers) {

        if (err)
        {
            console.error(err);
            res.status(500).send(err);
        }
        else
        {
            res.send(headers);
        }
    });

});

app.post(url_prefix + '/getCase', function(req, res) {

    caseDb.getDisabilityCase(req.body.folderNumber, req.body.caseNumber, function(err, doc) {

        if (err) {
            console.error(err);
            res.status(500).send(err);
        } else {
            res.send(doc);
        }
    });

});

app.post(url_prefix + '/getDocuments', function(req, res) {

    caseDb.getMedicalEvidenceDocuments(req.body.disabilityCaseId, function(err, docs) {
        if (err) {
            console.error(err);
            res.status(500).send(err);
        } else {
            res.send(docs);
        }
    });

});

app.post(url_prefix + '/getSections', function(req, res) {

    caseDb.getMedicalEvidenceSections(req.body.documentId, function(err, docs) {
        if (err) {
            console.error(err);
            res.status(500).send(err);
        } else {
            res.send(docs);
        }
    })

});

app.post(url_prefix + '/getAnnotations', function(req, res) {

    caseDb.getViewerAnnotations(req.body.disabilityCaseId, function(err, docs) {
        if (err) {
            console.error(err);
            res.status(500).send(err);
        } else {
            res.send(docs);
        }
    });
});

/**
 * Search case method
 */
app.post(url_prefix + '/searchcases', function(req, res) {

    caseDb.getCasesByCriteria(req.body.firstName, req.body.lastName,
        req.body.ssn, req.body.folderNum, req.body.caseNum, req.body.pageSize,
        function(err, docs) {

            if (err) {
                console.error(err);
                res.status(500).send(err);
            } else {
                res.send(docs);
            }
        });
});


/**
 * Check if Mongo is up
 */
app.post(url_prefix + '/checkMongo', function(req, res) {

    caseDb.connect(function(err, db) {

            if (err) {
                //Mongo is responding
                res.send({status: "unavailable"});

            } else {
                //if Mongo is down
                res.send({status: "available"});
            }
        });
});

app.get(url_prefix + '/search', function(req, res){
    search.typeAhead(req.query.term, function(err, terms)
    {
        if(err){
            console.error(err)
            res.status(500).send(err);
        }
        else{
            res.send(terms);
        }

    })

})

app.get(url_prefix + '/search-results', function(req, res){
    search.getConcepts(req.query.term, function(err, concepts)
    {
        if(err){
            console.error(err)
            res.status(500).send(err);
        }
        else{
            res.send(concepts);
        }

    })

})

var server = app.listen(port, function() {
    console.log("Clinical Analysis Viewer listening on port " + port);
});