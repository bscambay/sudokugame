var caseDb = require('../data/case-db.js');
const ERRP = { 'GETCASE' : 'Unable to get case: ' };

describe('Testing disabilityCase function', function() {
        //Happy Path
        it('Should return disability case document for specified folder and case number', function(done) {
            // Test implementation goes here

            caseDb.getDisabilityCase('14715326','45208', function(err, res) {
            
                    if (err) return done(err);
                    console.dir(res);
                    done();
                });
            

        });

        it('Should return required argument error with invalid folder and case number', function(done) {
            // Test implementation goes here

            caseDb.getDisabilityCase('1','2', function(err, res) {
                    
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETCASE + "Folder number and case number are required.")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });
            

        });

        it('Should return required argument error with unexpected character', function(done) {
            // Test implementation goes here

            caseDb.getDisabilityCase('A','45208', function(err, res) {
                    
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETCASE + "Folder number and case number are required.")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                });
            

        });

        it('Should return required argument error with null argument', function(done) {
            // Test implementation goes here

            caseDb.getDisabilityCase(null,'45208', function(err, res) {
                    


                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETCASE + "Folder number and case number are required.")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });
            

        });

        it('Should return required argument error with null argument', function(done) {
            // Test implementation goes here

            caseDb.getDisabilityCase(undefined,'45208', function(err, res) {
                    


                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETCASE + "Folder number and case number are required.")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });
            

        });

        it('Should return required argument error with unexpected character', function(done) {
            // Test implementation goes here

            caseDb.getDisabilityCase('&','45208', function(err, res) {
                    
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETCASE + "Folder number and case number are required.")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });
            

        });

        it('Should return required argument error with unexpected character', function(done) {
            // Test implementation goes here

            caseDb.getDisabilityCase('14715326','B', function(err, res) {
                    
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETCASE + "Folder number and case number are required.")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });
            

        });

        it('Should return required argument error with null argument', function(done) {
                    // Test implementation goes here

                    caseDb.getDisabilityCase('14715326', null, function(err, res) {
                            
                            if (err) 
                                {
                                    if(err.message.indexOf(ERRP.GETCASE + "Folder number and case number are required.")!= -1)
                                    {
                                        done();
                                    }
                                    else{
                                        done(new Error("Error was not expected: " + err.message));
                                    }
                                }
                                else
                                done(new Error("No error returned."));
                            });

                        
        });

        it('Should return required argument error with null argument', function(done) {
                    // Test implementation goes here

                    caseDb.getDisabilityCase('14715326', undefined, function(err, res) {
                            
                            if (err) 
                                {
                                    if(err.message.indexOf(ERRP.GETCASE + "Folder number and case number are required.")!= -1)
                                    {
                                        done();
                                    }
                                    else{
                                        done(new Error("Error was not expected: " + err.message));
                                    }
                                }
                                else
                                done(new Error("No error returned."));
                            });

                        
        });

        it('Should return required argument error with unexpected character', function(done) {
                    // Test implementation goes here

                    caseDb.getDisabilityCase('14715326','&', function(err, res) {
                            
                            if (err) 
                                {
                                    if(err.message.indexOf(ERRP.GETCASE + "Folder number and case number are required.")!= -1)
                                    {
                                        done();
                                    }
                                    else{
                                        done(new Error("Error was not expected: " + err.message));
                                    }
                                }
                                else
                                done(new Error("No error returned."));
                            });

                        
        });

        it('Should return required argument error', function(done) {
                    // Test implementation goes here

                    caseDb.getDisabilityCase('','', function(err, res) {
                            
                            if (err) 
                                {
                                    if(err.message.indexOf(ERRP.GETCASE + "Folder number and case number are required.")!= -1)
                                    {
                                        done();
                                    }
                                    else{
                                        done(new Error("Error was not expected: " + err.message));
                                    }
                                }
                                else
                                done(new Error("No error returned."));
                            });

                        
        });
    
});