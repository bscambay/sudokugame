var caseDb = require('../data/case-db.js');
const ERRP = { 'GETSECTIONS' : 'Unable to get sections: ' };

describe('Testing medicalEvidenceSections function', function() {
        //Happy Path
        it('Should get sections of specified document based on documentId', function(done) {
            // Test implementation goes here 
            
            caseDb.getMedicalEvidenceSections('56f40afbe4b0cbed7e2d8aec', function(err, res) {
                    if (err) return done(err);
                    console.dir(res);
                    done();
                })

        });

        it('Should return required argument error with invalid documentId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceSections('1', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETSECTIONS + "Document ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid documentId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceSections('A', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETSECTIONS + "Document ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid documentId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceSections(' ', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETSECTIONS + "Document ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid documentId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceSections(null, function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETSECTIONS + "Document ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid documentId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceSections('&', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETSECTIONS + "Document ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid documentId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceSections(undefined, function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETSECTIONS + "Document ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

});