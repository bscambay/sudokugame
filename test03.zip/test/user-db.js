var userDb = require('../data/user-db.js');

describe('Testing User Database (Postgres)', function() {

    it('Should save new issue', function(done) {

        userDb.saveIssue({ pin: '466115', viewName: null, caseId: null, description: 'This is a test issue.' }, function(err) {
            done(err);
        });
    });
});
