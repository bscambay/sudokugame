var caseDb = require('../data/case-db.js');

describe('Testing getSdr', function() {
        
    it('Should return SDR info', function(done) {
        
        caseDb._getSdr(4, 4, "ERRPREFIX", function(err, data) {

            if (err)
            {
                done(err);
            }
            else
            {
                done();
            }
        });

    });

});