var caseDb = require('../data/case-db.js');
const ERRP = { 'GETDOCUMENTS' : 'Unable to get documents: ' };

describe('Testing medicalEvidenceDocuments function', function() {
        //Happy Path
        it('should return documents for the specified disabilityCaseId', function(done) {

                caseDb.getMedicalEvidenceDocuments('580a62b220b556f43bd62773', function(err, res) {
                    if (err) return done(err);
                    console.dir(res); 
                    done();
                });
            });

        it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceDocuments('1', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETDOCUMENTS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceDocuments('A', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETDOCUMENTS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceDocuments(' ', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETDOCUMENTS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceDocuments(null, function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETDOCUMENTS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceDocuments('&', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETDOCUMENTS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getMedicalEvidenceDocuments(undefined, function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETDOCUMENTS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

});

