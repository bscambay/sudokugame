var caseDb = require('../data/case-db.js');
const ERRP = { 'GETANNOTATIONS' : 'Unable to get annotations: ' };

describe('Testing viewAnnotations function', function() {
        //Happy Path
        it('Should get viewer annotations for the specified disabilityCaseId', function(done) {
                //Test implementation goes here 
                caseDb.getViewerAnnotations('580a62b220b556f43bd62773', function(err, res) {
                        if (err) return done(err);
                        console.dir(res);
                        done();
                })

        });

         it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getViewerAnnotations('1', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETANNOTATIONS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getViewerAnnotations('A', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETANNOTATIONS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getViewerAnnotations(' ', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETANNOTATIONS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getViewerAnnotations(null, function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETANNOTATIONS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

        it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getViewerAnnotations('&', function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETANNOTATIONS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

         it('Should return required argument error with invalid disabilityCaseId', function(done) {
                // Test implementation goes here

                caseDb.getViewerAnnotations(undefined, function(err, res) {
                        
                    if (err) 
                        {
                            if(err.message.indexOf(ERRP.GETANNOTATIONS + "Disability Case ID is required")!= -1)
                            {
                                done();
                            }
                            else{
                                done(new Error("Error was not expected: " + err.message));
                            }
                        }
                        else
                        done(new Error("No error returned."));
                    });

        });

});