//Some code here to grab the development data
var typeAheadData = require('./medterms.json');
var solrResponse = require('./solrResponse.json');

const words = typeAheadData;


const response = solrResponse;



module.exports = {

        typeAhead : function(term, callback)
        {
           var results = [];
           var pattern = new RegExp("\\b" + term, "gi")
           var maxMatches = 5;

           for(var i = 0, matches = 0; i < words.length && matches < maxMatches; i++)
           {
                 if (pattern.test(words[i]))
                 {
                    results.push(words[i]);
                    matches++;
                 }
           }

           callback(undefined, results)
        },


        getConcepts: function(term, callback){

            callback(undefined,solrResponse)
        }


};
