var mongoClient = require("mongodb").MongoClient;
var RestClient = require('node-rest-client').Client;
var refDb = require('./ref-db.js');
var TimedCache = require('../util/timed-cache.js');

const MONGO_URL = process.env.mongo || 'mongodb://med-user:Secret1$@hq-rhv-2054.esef.addev.ssa.gov:27017/MEDAnalyzer';
const SDR_URL = process.env.restUrl || "http://S1FF450:8186/DeCodeRequest/sdr/claimant";

// NOTE: This data should be pulled from GRT GCDOCTYP
const DOC_TYPES = {
    /**
     * Return the doc type for the specified code
     */
    getByCode: function (code) {

        switch (code) {
            case '0001':
                return this.MER;
            case '0002':
                return this.CE;
            case '0003':
                return this.CERSPOND;
            case '0017':
                return this.HITMER;
            default:
                return this.UNKNOWN;
        }
    },
    'MER': {
        abbrv: 'MER',
        name: 'Medical Evidence of Record',
        shortName: 'MER',
        code: '0001'
    },
    'CE': {
        abbrv: 'CE',
        name: 'Consultative Examination Report',
        shortName: 'CE Rprt',
        code: '0002'
    },
    'CERSPOND': {
        abbrv: 'CERSPOND',
        name: 'CE Acknowledgement',
        shortName: 'CE Acknowledge',
        code: '0003'
    },
    'HITMER': {
        abbrv: 'HITMER',
        name: 'HIT MER',
        shortName: 'HIT MER',
        code: '0017'
    },
    'UNKNOWN': {
        abbrv: 'UNK',
        name: "Medical Record (Type Unknown)",
        shortName: 'UNK',
        code: '0000'
    }
}

const COLLECTIONS = {
    'VIEWER_ANNOTATIONS': 'viewerAnnotation',
    'MEDICAL_EVIDENCE_DOCUMENT_SECTIONS': 'medicalEvidenceSection',
    'MEDICAL_EVIDENCE_DOCUMENTS': 'medicalEvidenceDocument',
    'DISABILITY_CASE': "disabilityCase"
}

const ERRP = {
    'CONNECT': 'Unable to connect to Mongo database: ',
    'GET_ANNOTATIONS': 'Unable to get annotations: ',
    'GET_CASE': 'Unable to get case: ',
    'GET_DOCUMENT_HEADERS': 'Unable to get document headers: ',
    'GET_DOCUMENTS': 'Unable to get documents: ',
    'GET_SECTIONS': 'Unable to get sections: ',
    SEARCH_CASE: 'Unable to search for cases: '
}

var timedCache = new TimedCache();

/**
 * This is the case database interface for reading documents from
 * the MEDAnalyzer database.
 */
module.exports = {

    db: null,

    /**
     * Connect to the mongo database
     * @param callback(err, database)
     */
    connect: function (callback) {

        if (!this.db) {
            mongoClient.connect(MONGO_URL, function (err, database) {
                if (err) {
                    callback(new Error(ERRP.CONNECT + err));
                }
                else {
                    this.db = database;
                    callback(undefined, database);
                }
            });
        }
        else {
            callback(this.db);
        }
    },

    /**
     * Returns the document headers for the documents associated with the specified
     * disability case Id. Note that this will need to be modified when the database collections change.
     * (sections are going to be rolled up into the documents colection)
     * @param disabilityCaseId
     * @param callback(err, headers)
     */
    getDocumentHeaders: function (disabilityCaseId, callback) {

        if (disabilityCaseId) {
            var self = this;

            /* First query the Medical Evidence Documents collection,
             * if successful the query will return docs
             */
            self._query(COLLECTIONS.MEDICAL_EVIDENCE_DOCUMENTS, {
                disabilityCaseId: disabilityCaseId
            }, {
                    type: 1,
                    name: 1,
                    dmaDocumentDetails: 1,
                    origin: 1,
                    fileSize: 1,
                    labels: 1,
                    dmaDocumentId: 1,
                    dmaDocumentType: 1
                }, ERRP.GET_DOCUMENT_HEADERS, function (err, docs) {

                    if (err) {
                        callback(err);
                    }
                    else {

                        /* If first query is successful, then aggregate the Viewer Annotions
                         * matching the Disability Case ID and group by Document ID, if successful
                         * the aggregation will return agg
                         */
                        self._aggregate(COLLECTIONS.VIEWER_ANNOTATIONS, [{
                            $match: {
                                disabilityCaseId: disabilityCaseId
                            }
                        }, {
                            $group: {
                                _id: {
                                    'documentId': '$documentId',
                                    'type': '$type'
                                },
                                total: {
                                    $sum: 1
                                }
                            }
                        }], ERRP.GETDOCUMENTS, function (err, agg) {

                            if (err) {
                                callback(err);
                            }
                            // If aggregation was successful, start the process of building the headers
                            else {
                                var headerDict = {};
                                var headers = [];
                                var header = null;
                                var i = 0;

                                /* Loop through each document, instantiating a header object. Next add relevant
                                    * data to the header object from the document collection,
                                    * then add header object to the headerDict, indexing by documentId.
                                    */
                                for (i = 0; i < docs.length; i++) {
                                    header = {
                                        documentId: docs[i]._id.toString(),
                                        type: docs[i].type,
                                        fileName: docs[i].name,
                                        provider: "",
                                        origin: docs[i].origin,
                                        fileSize: docs[i].fileSize,
                                        labels: docs[i].labels,
                                        dmaDocumentId: docs[i].dmaDocumentId,
                                        dmaDocumentType: docs[i].dmaDocumentType,
                                        totalAnnotations: 0
                                    };

                                    if (docs[i].dmaDocumentDetails)
                                    {
                                        header.provider = docs[i].dmaDocumentDetails.treatmentSourceName;
                                    }

                                    //if upload date is present, format from millliseconds to Date
                                    if (docs[i].dmaDocumentDetails &&
                                        docs[i].dmaDocumentDetails.dmaDocumentReceivedDate) 
                                    {
                                        header.dateReceived = new Date(docs[i].dmaDocumentDetails.dmaDocumentReceivedDate);
                                    }

                                    /* If origin is from DMA and it has a docType we can use the code
                                     * do convert to a doc type description to display using the docTypeDictionary.
                                     * Otherwise display the generic medical document, type unknown message.
                                    */
                                    var docType = null;

                                    if (docs[i].origin === "DMA" && docs[i].dmaDocumentType) {
                                        docType = DOC_TYPES.getByCode(docs[i].dmaDocumentType);
                                    }
                                    else {
                                        docType = DOC_TYPES.UNKNOWN;
                                    }

                                    header.displayName = docType.name + ' (' + docType.abbrv + ')'; // eView format
                                    header.shortDisplayName = docType.abbrv; // DMA format

                                    if (header.provider) {
                                        header.displayName += ' - ' + header.provider;
                                        header.shortDisplayName += ' - ' + header.provider;
                                    }

                                    headerDict[header.documentId] = header;
                                }


                                /* Loop through the Viewer Annotation aggregation, set header object to reference
                                    * headerDict by the documentId of the aggregation object. Add data regarding annotations
                                    * found in the docuement to the header object.
                                    */
                                for (i = 0; i < agg.length; i++) {
                                    header = headerDict[agg[i]._id.documentId];

                                    if (header) {
                                        header.totalAnnotations += agg[i].total;
                                        header[agg[i]._id.type + "Total"] = agg[i].total;
                                    }

                                }

                                // Loop through the headerDict and add each element to the headers object.
                                for (var hdrId in headerDict) {
                                    headers.push(headerDict[hdrId]);
                                }

                                // Callback with fully built headers object.
                                callback(null, headers);
                            }
                        });
                    }
                });
        }
        else {
            callback(new Error(ERRP.GET_DOCUMENT_HEADERS + "Disability Case ID is required"));
        }
    },

    /**
     * Returns the viewer annotations for the specified disability
     * case.
     * @param disabilityCaseId
     * @param callback(err, annotations)
     */
    getViewerAnnotations: function (disabilityCaseId, callback) {

        if (disabilityCaseId) 
        {
            this._query(COLLECTIONS.VIEWER_ANNOTATIONS, { disabilityCaseId: disabilityCaseId }, ERRP.GET_ANNOTATIONS, function(err, annotations) {

                if (!err) 
                {
                    refDb.getBodySystem(function(err, systems) {
                        
                        if (!err) 
                        {
                            // This code modifies the annotation, adding a bodySystems array property and
                            // adding bodySystem to the blue book location
                            for (var i = 0; i < annotations.length; i++)
                            {
                               var futureYear = new Date().getFullYear()+1;                                  
                             
                                 if (annotations[i].date !== undefined){
                                     var year = new Date(annotations[i].date).getFullYear();
                                     if(year >= futureYear){
                                           annotations[i].date = undefined;
                                       }
                                    }
                                      
                                    annotations[i].bodySystems = [];

                                    if (annotations[i].blueBookLocations && annotations[i].blueBookLocations.length)
                                    {
                                        for (var n = 0; n < annotations[i].blueBookLocations.length; n++)
                                        {
                                            for (var d = 0; d < systems.length; d++)
                                            {
                                                if (annotations[i].blueBookLocations[n].chapter == systems[d].bodysys_cd)
                                                {
                                                    if (!annotations[i].bodySystems.includes(systems[d].bodysys_cdesc)) {
                                                        annotations[i].bodySystems.push(systems[d].bodysys_cdesc);
                                                    }
                                                
                                                    annotations[i].blueBookLocations[n].bodySystem = systems[d].bodysys_cdesc;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }

                                callback(undefined, annotations);
                            } 
                        else 
                        {
                            callback(err);
                        }
                    });                    
                }
                else 
                {
                    callback(err);
                }
            }
            );
        }
        
        else {
            callback(new Error(ERRP.GET_ANNOTATIONS + "Disability Case ID is required"));
        }

    },
    /**
     * Returns the sections of the specified document
     * @param documentId
     * @param callback function(err, sections)
     */
    getMedicalEvidenceSections: function (documentId, callback) {

        if (documentId) {
            this._query(COLLECTIONS.MEDICAL_EVIDENCE_DOCUMENT_SECTIONS, { documentId: documentId }, ERRP.GET_SECTIONS, callback);
        }
        else {
            callback(new Error(ERRP.GET_SECTIONS + "Document ID is required"));
        }
    },

    /*
     * Abstraction of queries
     * This is not meant to be used directly by clients
     * @param collectionName Name of the Mongo collection to queryObject
     * @param queryObject Query object to use in the queryObject
     * @param projection Project object to limit fields returned from a query
     * @param errPrefix Text to preprend to error messages
     * @param callback function(err, documents)
     */
    _query: function (collectionName, queryObject, projection, errPrefix, callback) {

        if (typeof (projection) == "string" && typeof (errPrefix) == "function" && !callback) {
            callback = errPrefix;
            errPrefix = projection;
            projection = {};
        }

        this.connect(function (err, database) {

            if (!err) {
                database.collection(collectionName).find(queryObject, projection).toArray(function (err, docs) {
                    if (!err) {
                        callback(undefined, docs);
                    }
                    else {
                        callback(new Error(errPrefix + err));
                    }
                });
            }
            else {
                callback(new Error(errPrefix + err));
            }
        });
    },

    /**
     * This method calls the SDR service for the specified case and returns the 
     * associated information
     * @param folderNumber
     * @param caseNumber
     * @param errPrefix
     * @param callback(err, sdr)
     */
    _getSdr: function(folderNumber, caseNumber, errPrefix, callback) {

        var key = "" + folderNumber + '|' + caseNumber;
        var value = timedCache.value(key);

        if (!value)
        {
            var restClient = new RestClient();

            var args = {
                data: { 
                    folderNumber: folderNumber, 
                    caseNumber: caseNumber 
                },
                headers: {
                    "Content-Type": "application/json"
                }
            };

            restClient.post(SDR_URL, args, function(data, response) {

                if (response.statusCode == 200)
                {
                    if (data.folderNumber == folderNumber &&
                        data.caseNumber == caseNumber)
                    {
                        timedCache.put(key, data);
                        callback(undefined, data);
                    }
                    else
                    {
                        callback(new Error(errPrefix + "SDR service did not find case"));
                    }
                }
                else
                {
                    callback(new Error(errPrefix + "Unable to connect to SDR service: " + 
                        response.statusCode + " - " + response.statusMessage));
                }
            });
        }
        else
        {
            callback(undefined, value);
        }
    },

    _searchQuery: function (collectionName, pageSize, queryObject, projection, errPrefix, callback) {

        if (typeof (projection) == "string" && typeof (errPrefix) == "function" && !callback) {
            callback = errPrefix;
            errPrefix = projection;
            projection = { "patient.firstName": 1, "patient.lastName": 1, "caseDetails.ssn": 1, "caseDetails.folderNum": 1, "caseDetails.caseNum": 1, "status": 1 };
        }

        this.connect(function (err, database) {

            if (!err) {
                database.collection(collectionName).count(queryObject, function (err, count) {

                    if (!err) {
                        database.collection(collectionName).find(queryObject, projection).limit(pageSize).toArray(function (err, docs) {
                            if (!err) {
                                var searchInfo = {
                                    count: count, // this is the total number of matches in the collection, not the number returned
                                    docs: docs
                                }

                                callback(undefined, searchInfo);
                            }
                            else {
                                callback(new Error(errPrefix + err));
                            }
                        });
                    }
                    else {
                        callback(new Error(errPrefix + err));
                    }
                });
            }
            else {
                callback(new Error(errPrefix + err));
            }
        });
    },

    _aggregate: function (collectionName, pipeline, errPrefix, callback) {

        this.connect(function (err, database) {

            if (!err) {
                database.collection(collectionName).aggregate(pipeline).toArray(function (err, docs) {
                    if (!err) {
                        callback(undefined, docs);
                    }
                    else {
                        callback(new Error(errPrefix + err));
                    }
                });
            }
            else {
                callback(new Error(errPrefix + err));
            }
        });
    },

    /**
     * Returns the documents for the specified disability case
     * ID.  Get the disability case first using folder number and
     * case number.
     * @param disabilityCaseId
     * @param callback(err, documents)
     */
    getMedicalEvidenceDocuments: function (disabilityCaseId, callback) {

        if (disabilityCaseId) {
            this._query(COLLECTIONS.MEDICAL_EVIDENCE_DOCUMENTS, {
                disabilityCaseId: disabilityCaseId
            }, ERRP.GET_DOCUMENTS, callback);
        }
        else {
            callback(new Error(ERRP.GET_DOCUMENTS + "Disability Case ID is required"));
        }
    },

    /**
     * Returns the disabilityCase document for the specified
     * folder number and case number.
     * @param folderNum
     * @param caseNum
     * @param callback(err, case)
     */
    getDisabilityCase: function (folderNum, caseNum, callback) {

        var self = this;

        if (folderNum && caseNum) {
            this.connect(function (err, database) {

                if (err) {
                    callback(new Error(ERRP.GET_CASE + err));
                }
                else {
                    database.collection(COLLECTIONS.DISABILITY_CASE).find({
                        "caseDetails.folderNum": parseInt(folderNum),
                        "caseDetails.caseNum": parseInt(caseNum),
                        status: "RuleProcessingComplete"
                    }).toArray(function (err, docs) {

                        if (err) {
                            callback(new Error(ERRP.GET_CASE + err));
                        }
                        else {
                            if (docs.length > 1) {
                                callback(new Error(ERRP.GET_CASE + "Multiple cases found for folder number " +
                                    folderNum + " and case number " + caseNum));
                            }
                            else {

                                self._getSdr(folderNum, caseNum, ERRP.GET_CASE, function(err, sdr) {

                                    if (!err)
                                    {
                                        docs[0].allegedOnsetDate = new Date(sdr.clientAOD);
                                        docs[0].stoppedWorkDate = new Date(sdr.clientSWD);
                                    }
                                    else
                                    {
                                        console.error(err);
                                    }

                                    callback(undefined, docs[0]);
                                });
                            }
                        }
                    });
                }
            });
        }
        else {
            callback(new Error(ERRP.GET_CASE + "Folder number and case number are required."));
        }
    },

    /**
    * Returns the Cases for the specified
    * search criteria for Case Search Page.
    * @param firstName
    * @param lastName
    * @param ssn
    * @param folderNum
    * @param caseNum
    * @param callback(err, document)
    */
    //getCasesByCriteria
    ////firstName,lastName,ssn,folderNum,caseNum
    getCasesByCriteria: function (firstName, lastName, ssn, folderNum, caseNum, pageSize, callback) {

        var queryObj = {};
        var queryClause = false;

        if (firstName) {
            var fname = new RegExp('^' + firstName, 'i');

            queryObj['patient.firstName'] = {
                $regex: fname
            };

            queryClause = true;
        }

        if (lastName) {
            var lname = new RegExp('^' + lastName, 'i');

            queryObj['patient.lastName'] = {
                $regex: lname
            };

            queryClause = true;
        }

        if (ssn) {
            ssn = ("" + ssn).replace(/-/g, '');

            var re = new RegExp('^' + ssn.substr(0, 3) + '-?' +
                ssn.substr(3, 2) + '-?' + ssn.substr(5) + '$');

            queryObj['caseDetails.ssn'] = {
                $regex: re
            }

            queryClause = true;
        }

        if (folderNum) {
            queryObj['caseDetails.folderNum'] = parseInt(folderNum);
            queryClause = true;
        }

        if (caseNum) {
            queryObj['caseDetails.caseNum'] = parseInt(caseNum);
            queryClause = true;
        }

        queryObj.caseLabels = "Gold";

        if (queryClause) 
        {
            // Create pointer to "this" for callbacks to reference
            var self = this;

            this._searchQuery('disabilityCase', pageSize, queryObj, ERRP.SEARCH_CASE, function (err, cases) {
               
                if (!err) 
                {
                    var caseIDs = [];
                    
                    // iterate through cases and build array of case Ids
                    for (var i = 0; i < cases.docs.length; i++) 
                    {
                        caseIDs.push(cases.docs[i]._id.toString())
                    };

                    self._aggregate(COLLECTIONS.MEDICAL_EVIDENCE_DOCUMENTS, [{
                            $match: {
                                disabilityCaseId: { $in: caseIDs }
                            }
                        }, {
                            $group: {
                                _id: {
                                    'disabilityCaseId': '$disabilityCaseId'
                                },
                                total: {
                                    $sum: 1
                                }
                        }}], ERRP.SEARCH_CASE, function (err, results) {

                            if (!err) 
                            {
                                for (var i = 0; i < cases.docs.length; i++)
                                {
                                    for (var n = 0; n < results.length; n++)
                                    {
                                        if (results[n]._id.disabilityCaseId == cases.docs[i]._id)
                                        {
                                            cases.docs[i].documentCount = results[n].total;
                                            break;
                                        }
                                    }
                                }
                                
                                callback(null, cases);
                            }
                            else
                            {
                                callback(err);
                            }
                        });
                }
                else
                {
                     callback(err);   
                }    
            });
        }
    }
}