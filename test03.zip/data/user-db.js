const pg = require('pg');

var pgUser = process.env.PG_USER || 'postgres';
var pgDatabase = process.env.PG_DATABASE || 'NLPViewer';
var pgPassword = process.env.PG_PASSWORD || 'DmbGo1dTe@m';
var pgHost = process.env.PG_HOST || 'S1FF406.ba.ad.ssa.gov';
var pgPort = process.env.PG_PORT || 5432;
var pgSchema = process.env.PG_NLPVIEWER_SCHEMA || "nlpviewer1";

var config = {
    user: pgUser,
    database: pgDatabase,
    password: pgPassword,
    host: pgHost,
    port: pgPort,
    max: 10,
    idleTimeoutMillis: 30000
};

const pool = new pg.Pool(config);

/**
 * Handle idle client errors (in the connection pool)
 */
pool.on('error', function(err, client) {
    console.error('Idle client error', err.message, err.stack);
});

const INSERT_ISSUE_ERR = "Unable to insert issue: ";

const INSERT_ISSUE_SQL = `INSERT INTO %schema%.issue
                          (pin, view_name, case_id, description)
                          VALUES ($1::CHAR(6), $2::VARCHAR(32), $3::CHAR(24), $4::TEXT);`;

module.exports = {

    /**
     * Saves a new issue to the database
     */
    saveIssue: function(issue, callback) {

        if (issue)
        {
            pool.query(INSERT_ISSUE_SQL.replace('%schema%', pgSchema), [issue.pin, issue.viewName, issue.caseId, issue.description], function(err, res) {

                if (err)
                {
                    callback(new Error(INSERT_ISSUE_ERR + err));
                }
                else
                {
                    callback();
                }
            });
        }
        else
        {
            callback(new Error(INSERT_ISSUE_ERR + 'Issue to save is required'));
        }
    },

    /**
     * Returns user's saved search definitions
     * @param userName
     * @param callback(err, savedSearches)
     */
    getSavedSearches: function(userName, callback) {

        callback(null, [{
            id: 1,
            name: 'Cancer Concepts',
            concepts: [
                "Tumor",
                "Oncologist",
                "Lump",
                "Abracadoma"
            ]
        }, {
            id: 2,
            name: 'Schizophrenia and Other Mental Illness',
            concepts: [
                "Split Personality Disorder",
                "Schizophrenia",
                "Delusions"
            ]
        },
        {
        id: 3,
        name: "Davis Search",
        concepts: [
            "Arthrodesis",
            "Self Care for Pain",
            "Morbid obesity",
            "Disc",
            "Disk",
            "Gait",
            "Spinal",
            "Back",
            "Walking"


        ]},
        {
            id: 4,
            name: "Disk",
            concepts:[
                "Disk",
                "Disc",
                "Spinal",
                "Back"

            ]
        },
        {
            id:5,
            name: "Walking",
            concepts:[
                "Walking",
                "Gait"
                
            ]}
        ]);
    }

};
