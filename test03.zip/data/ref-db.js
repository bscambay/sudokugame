const pg = require('pg');

var pgUser = process.env.PG_USER || 'postgres';
var pgDatabase = process.env.PG_DATABASE || 'NLPViewer';
var pgPassword = process.env.PG_PASSWORD || 'DmbGo1dTe@m';
var pgHost = process.env.PG_HOST || 'S1FF406.ba.ad.ssa.gov';
var pgPort = process.env.PG_PORT || 5432;
var pgSchema = process.env.PG_NLPVIEWER_SCHEMA || "nlpviewer1";

var config = {
    user: pgUser,
    database: pgDatabase,
    password: pgPassword,
    host: pgHost,
    port: pgPort,
    max: 10,
    idleTimeoutMillis: 30000
};

const pool = new pg.Pool(config);

const SQL = {
    SELECT_BODY_SYSTEMS: "SELECT * FROM " + pgSchema + ".gcbdsys"
};

/**
 * Handle idle client errors (in the connection pool)
 */

pool.on('error', function(err, client) {
    console.error('Idle client error', err.message, err.stack);
});

module.exports = {

    /**
     * Returns the body systems table
     * @param callback(err, bodySystems)
     */
    getBodySystem : function(callback){       

        pool.query(SQL.SELECT_BODY_SYSTEMS, function(err, res) {
        
            if (err)
            {
                callback(err);
            }
            else
            {
                callback(undefined, res.rows);
            }
        }); 
    }
};