For this exercise, you need to be sure 
exercise05 database has been created.

For simple usage that is all that is needed.

For /advanced-examples execute this inside that folder:
knex migrate:latest