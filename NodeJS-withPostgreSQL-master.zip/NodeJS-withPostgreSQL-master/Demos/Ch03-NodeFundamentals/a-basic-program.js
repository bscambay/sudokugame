console.log("one");
setTimeout(function(){console.log("two");},1000);
console.log("three");
setTimeout(function(){console.log("four");},0);


