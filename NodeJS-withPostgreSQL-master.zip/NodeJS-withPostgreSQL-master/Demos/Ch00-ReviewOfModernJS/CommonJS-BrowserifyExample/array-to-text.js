'use strict';

module.exports = function arrayToText(array) {
	return array.join(", ");
}
