### Install json-server

Before starting the host, install json-server package

    npm install -g json-server

### Start Host

To start the host & database: Open a terminal, navigate to json-server directory and run the following command.

    json-server db.json
