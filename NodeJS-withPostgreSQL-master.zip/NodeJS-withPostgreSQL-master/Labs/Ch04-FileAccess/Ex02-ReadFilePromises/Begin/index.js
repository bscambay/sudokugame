const Promise = require("bluebird");
const fs = Promise.promisifyAll(require("fs"));

// Write your code here
