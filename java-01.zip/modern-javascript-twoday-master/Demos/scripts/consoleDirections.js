const body = document.getElementsByTagName("body")[0];
var elemDiv = document.createElement('div');
//elemDiv.style.cssText = 'position:absolute;width:100%;height:100%;opacity:0.3;z-index:100;background:#000;';

body.appendChild
elemDiv.innerHTML
 = `    <p>Open the console in order to see the output</p>
        <p>Ctrl-Shift-I is oneshortcut to open the console</p>

        <p>F12 is used by most browers as a shortcut</p>
`;

document.body.appendChild(elemDiv);